package com.example.data.repository

import com.example.data.model.Product

object EcommerceCatalog {
    val items: List<Product> = listOf(
        // --- ELECTRONICS & AUDIO ---
        Product(
            id = "ecom_1",
            title = "Wireless Bluetooth Earbuds (TWS)",
            hindiName = "वायरलेस ब्लूटूथ ईयरबड्स",
            price = 799.0,
            originalPrice = 1499.0,
            unit = "1 Unit",
            subcategory = "Earbuds",
            category = "Electronics & Audio",
            description = "True wireless stereo earbuds with immersive deep bass, environmental noise cancellation and 30-hour playback.",
            imageUrl = "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            isFeatured = true
        ),
        Product(
            id = "ecom_2",
            title = "Bluetooth Magnetic Neckband",
            hindiName = "ब्लूटूथ मैग्नेटिक नेकबैंड",
            price = 499.0,
            originalPrice = 999.0,
            unit = "1 Unit",
            subcategory = "Neckband",
            category = "Electronics & Audio",
            description = "Flexible ergonomic neckband with fast charging, IPX5 water resistance, clear call mic and 24 hours battery life.",
            imageUrl = "https://images.unsplash.com/photo-1577174881658-0f30ed549adc?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),
        Product(
            id = "ecom_3",
            title = "Smart Fitness Watch 1.83\" HD",
            hindiName = "स्मार्ट फिटनेस वॉच",
            price = 1299.0,
            originalPrice = 2499.0,
            unit = "1 Unit",
            subcategory = "Smartwatches",
            category = "Electronics & Audio",
            description = "Large 1.83 inch vibrant HD display with Bluetooth calling, 100+ sports modes, SpO2 & 24x7 heart rate tracker.",
            imageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            isFeatured = true
        ),

        // --- MOBILE ACCESSORIES ---
        Product(
            id = "ecom_4",
            title = "10000mAh Fast Charging Power Bank",
            hindiName = "१०,००० mAh पावर बैंक",
            price = 699.0,
            originalPrice = 1199.0,
            unit = "1 Unit",
            subcategory = "Power Banks",
            category = "Mobile Accessories",
            description = "Compact lightweight high-density lithium polymer power bank with dual USB ports and Type-C 18W bidirectional fast charge.",
            imageUrl = "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            isFeatured = true
        ),
        Product(
            id = "ecom_5",
            title = "20W Type-C Fast Charger & Cable",
            hindiName = "२०W टाइप-सी फास्ट चार्जर",
            price = 349.0,
            originalPrice = 699.0,
            unit = "1 Set",
            subcategory = "Chargers",
            category = "Mobile Accessories",
            description = "High-speed 20W Power Delivery adapter with durable 1-meter braided Type-C cable. Compatible with Android and iOS.",
            imageUrl = "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),
        Product(
            id = "ecom_6",
            title = "Foldable Mobile & Tablet Stand",
            hindiName = "एडजस्टेबल मोबाइल स्टैंड",
            price = 129.0,
            originalPrice = 249.0,
            unit = "1 PC",
            subcategory = "Stands",
            category = "Mobile Accessories",
            description = "Multi-angle adjustable desktop phone holder with anti-slip rubber pads. Foldable and pocket friendly.",
            imageUrl = "https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),

        // --- FASHION & APPAREL ---
        Product(
            id = "ecom_7",
            title = "Men's Solid Pure Cotton T-Shirt",
            hindiName = "मेंस कॉटन टी-शर्ट",
            price = 349.0,
            originalPrice = 699.0,
            unit = "1 PC",
            subcategory = "T-Shirts",
            category = "Fashion & Apparel",
            description = "100% combed bio-washed breathable cotton t-shirt with ribbed crew neck. Comfortable for all-day daily wear.",
            imageUrl = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            sizes = listOf("M", "L", "XL"),
            isFeatured = true
        ),
        Product(
            id = "ecom_8",
            title = "Men's Slim Fit Stretchable Jeans",
            hindiName = "मेंस स्लिम फिट जींस",
            price = 799.0,
            originalPrice = 1499.0,
            unit = "1 PC",
            subcategory = "Jeans",
            category = "Fashion & Apparel",
            description = "Classic dark wash denim trousers woven with stretch elastane for ultimate flexibility, style and durability.",
            imageUrl = "https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            sizes = listOf("30", "32", "34", "36")
        ),
        Product(
            id = "ecom_9",
            title = "Waterproof Laptop College Backpack",
            hindiName = "वाटरप्रूफ लैपटॉप बैग",
            price = 649.0,
            originalPrice = 1299.0,
            unit = "1 PC",
            subcategory = "Bags",
            category = "Fashion & Apparel",
            description = "Spacious 30-litre backpack with padded 15.6-inch laptop sleeve, water-resistant oxford fabric and breathable shoulder straps.",
            imageUrl = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),

        // --- HOME & KITCHEN ---
        Product(
            id = "ecom_10",
            title = "Stainless Steel Water Bottle 1L",
            hindiName = "स्टेनलेस स्टील पानी की बोतल",
            price = 299.0,
            originalPrice = 499.0,
            unit = "1 PC",
            subcategory = "Bottles",
            category = "Home & Kitchen",
            description = "Food grade 304 rust-proof stainless steel fridge bottle with leak-proof cap. Odour-free and hygienic.",
            imageUrl = "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            isFeatured = true
        ),
        Product(
            id = "ecom_11",
            title = "Quick Manual Kitchen Food Chopper 650ml",
            hindiName = "किचन वेज कटर व चॉपर",
            price = 249.0,
            originalPrice = 499.0,
            unit = "1 Set",
            subcategory = "Kitchen Tools",
            category = "Home & Kitchen",
            description = "High-grade 3 stainless steel cutting blades with easy pull string mechanism for chopping onions, vegetables and nuts in seconds.",
            imageUrl = "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),
        Product(
            id = "ecom_12",
            title = "1.5L Stainless Steel Electric Kettle",
            hindiName = "इलेक्ट्रिक केतली १.५ लीटर",
            price = 599.0,
            originalPrice = 999.0,
            unit = "1 Unit",
            subcategory = "Appliances",
            category = "Home & Kitchen",
            description = "1500W rapid boil cordless electric kettle with auto shut-off, boil-dry protection and 360-degree swivel base.",
            imageUrl = "https://images.unsplash.com/photo-1594213114663-ddf3f2a02126?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),
        Product(
            id = "ecom_13",
            title = "Rechargeable LED Desk Study Lamp",
            hindiName = "एलईडी स्टडी लैम्प",
            price = 399.0,
            originalPrice = 699.0,
            unit = "1 PC",
            subcategory = "Lighting",
            category = "Home & Kitchen",
            description = "Flexible 360-degree gooseneck reading lamp with touch brightness dimmer, eye-protection soft light and built-in battery.",
            imageUrl = "https://images.unsplash.com/photo-1534972195531-a756b1126f25?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        ),

        // --- PERSONAL CARE & GROOMING ---
        Product(
            id = "ecom_14",
            title = "Rechargeable Cordless Hair & Beard Trimmer",
            hindiName = "हेयर व दाढ़ी ट्रिमर",
            price = 549.0,
            originalPrice = 999.0,
            unit = "1 Set",
            subcategory = "Grooming",
            category = "Personal Care & Grooming",
            description = "Ultra-quiet stainless steel self-sharpening blades with 4 guide combs (1.5mm to 4mm) and 120-minute runtime per charge.",
            imageUrl = "https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce",
            isFeatured = true
        ),
        Product(
            id = "ecom_15",
            title = "Heavy Duty Microfiber Cleaning Cloth (Set of 4)",
            hindiName = "माइक्रोफाइबर क्लॉथ (४ पीस)",
            price = 179.0,
            originalPrice = 299.0,
            unit = "4 Pcs",
            subcategory = "Home Care",
            category = "Home & Kitchen",
            description = "Super absorbent lint-free scratchless microfiber towels for car cleaning, kitchen countertops and screen dusting.",
            imageUrl = "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=600&q=80",
            section = "E-Commerce"
        )
    )
}
