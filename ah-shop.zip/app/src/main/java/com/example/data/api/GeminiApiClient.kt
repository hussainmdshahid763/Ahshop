package com.example.data.api

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val role: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val groundingSources: List<GroundingSource> = emptyList()
)

data class GroundingSource(
    val title: String,
    val url: String? = null
)

data class VeoGenerationResult(
    val operationName: String,
    val prompt: String,
    val aspectRatio: String,
    val status: String,
    val videoUri: String? = null
)

object GeminiApiClient {
    private const val TAG = "GeminiApiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    val apiKey: String
        get() = BuildConfig.GEMINI_API_KEY

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    const val SYSTEM_INSTRUCTION_GROCERY =
        "You are AH SHOP's AI Grocery, Kitchen & Delivery Assistant in Garden Reach, Kolkata. " +
        "The shop address is: H-10, Gulam abbas lane, Garden reach, Kolkata-700024. Phone/WhatsApp: +91 8584016418. " +
        "You help customers with grocery shopping lists, cooking recipes (e.g., Biryani, Dal, Curries, Bengali delicacies), " +
        "item pricing in Indian Rupees (₹), delivery area inquiries in Kolkata, and store deals. " +
        "Be polite, helpful, and concise. You can reply in Hindi, English, or friendly Hinglish."

    /**
     * Multi-turn Gemini Chat with support for:
     * - Models: gemini-3.5-flash-lite (fast & reliable), gemini-3.8-flash, gemini-3.5-flash
     * - Automatic retry without tools if quota or tools cause 429/400
     * - Automatic model fallback so users always get a working response
     */
    suspend fun generateChat(
        history: List<ChatMessage>,
        userMessage: String,
        model: String = "gemini-3.5-flash-lite",
        enableGoogleSearch: Boolean = false,
        enableGoogleMaps: Boolean = false
    ): Result<ChatMessage> = withContext(Dispatchers.IO) {
        // First try with requested settings; if tools fail or model is rate-limited, fall back safely
        val chosenModel = if (model.isBlank()) "gemini-3.5-flash-lite" else model
        val result = executeGenerateContent(history, userMessage, chosenModel, enableGoogleSearch, enableGoogleMaps)
        if (result.isSuccess) {
            return@withContext result
        }

        Log.w(TAG, "Initial chat call failed with $chosenModel. Retrying with gemini-3.5-flash-lite and no tools...")
        // Fallback 1: Try gemini-3.5-flash-lite without grounding tools
        val fallback1 = executeGenerateContent(history, userMessage, "gemini-3.5-flash-lite", false, false)
        if (fallback1.isSuccess) {
            return@withContext fallback1
        }

        // Fallback 2: Try gemini-3.8-flash without grounding tools
        Log.w(TAG, "Fallback 1 failed. Trying gemini-3.8-flash...")
        val fallback2 = executeGenerateContent(history, userMessage, "gemini-3.8-flash", false, false)
        if (fallback2.isSuccess) {
            return@withContext fallback2
        }

        result
    }

    private fun executeGenerateContent(
        history: List<ChatMessage>,
        userMessage: String,
        model: String,
        enableGoogleSearch: Boolean,
        enableGoogleMaps: Boolean
    ): Result<ChatMessage> {
        try {
            val url = "$BASE_URL/models/$model:generateContent?key=$apiKey"

            val rootJson = JSONObject()

            // System instruction
            val sysInstruction = JSONObject().apply {
                val partsArray = JSONArray().apply {
                    put(JSONObject().put("text", SYSTEM_INSTRUCTION_GROCERY))
                }
                put("parts", partsArray)
            }
            rootJson.put("systemInstruction", sysInstruction)

            // Conversation contents (limit to last 10 turns to avoid token overflow)
            val contentsArray = JSONArray()
            for (msg in history.takeLast(10)) {
                val turn = JSONObject().apply {
                    put("role", if (msg.role == "user") "user" else "model")
                    val parts = JSONArray().apply {
                        put(JSONObject().put("text", msg.text))
                    }
                    put("parts", parts)
                }
                contentsArray.put(turn)
            }
            // Add current message
            val currentTurn = JSONObject().apply {
                put("role", "user")
                val parts = JSONArray().apply {
                    put(JSONObject().put("text", userMessage))
                }
                put("parts", parts)
            }
            contentsArray.put(currentTurn)
            rootJson.put("contents", contentsArray)

            // Grounding Tools (only add if enabled, Google Search)
            if (enableGoogleSearch) {
                val toolsArray = JSONArray().apply {
                    put(JSONObject().put("googleSearch", JSONObject()))
                }
                rootJson.put("tools", toolsArray)
            }

            val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBodyString = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini chat error on model $model: ${response.code} $responseBodyString")
                return Result.failure(Exception("Gemini API error (${response.code})"))
            }

            val responseJson = JSONObject(responseBodyString)
            val candidates = responseJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return Result.failure(Exception("No response received from Gemini"))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val contentObj = firstCandidate.optJSONObject("content")
            val parts = contentObj?.optJSONArray("parts")

            val replyTextBuilder = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) {
                        replyTextBuilder.append(part.getString("text"))
                    }
                }
            }

            // Extract Grounding Sources if available
            val sources = mutableListOf<GroundingSource>()
            val groundingMetadata = firstCandidate.optJSONObject("groundingMetadata")
            if (groundingMetadata != null) {
                val searchChunks = groundingMetadata.optJSONArray("groundingChunks")
                if (searchChunks != null) {
                    for (i in 0 until searchChunks.length()) {
                        val chunk = searchChunks.getJSONObject(i)
                        val web = chunk.optJSONObject("web")
                        if (web != null) {
                            val title = web.optString("title", "Google Search Reference")
                            val uri = web.optString("uri", "")
                            sources.add(GroundingSource(title = title, url = uri))
                        }
                    }
                }
            }

            val replyText = replyTextBuilder.toString().ifBlank {
                "नमस्ते! AH SHOP असिस्टेंट आपकी सेवा में है। आप क्या ऑर्डर करना चाहते हैं?"
            }

            return Result.success(
                ChatMessage(
                    role = "model",
                    text = replyText,
                    groundingSources = sources
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception during chat generation for $model", e)
            return Result.failure(e)
        }
    }

    /**
     * Voice Conversation using gemini-3.5-flash-lite
     * Ultra-low latency spoken grocery answers in Hindi and English
     */
    suspend fun liveVoiceQuery(
        prompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"
            val rootJson = JSONObject().apply {
                val sys = JSONObject().apply {
                    val p = JSONArray().apply {
                        put(JSONObject().put("text", "You are AH SHOP's voice grocery assistant in Garden Reach, Kolkata. Answer briefly, politely, and naturally in 1-2 spoken sentences in Hindi/English. Shop address: H-10 Gulam abbas lane. Phone: +91 8584016418."))
                    }
                    put("parts", p)
                }
                put("systemInstruction", sys)

                val contents = JSONArray().apply {
                    val turn = JSONObject().apply {
                        put("role", "user")
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        }
                        put("parts", parts)
                    }
                    put(turn)
                }
                put("contents", contents)
            }

            val request = Request.Builder()
                .url(url)
                .post(rootJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseText = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Voice response error: ${response.code} $responseText")
                // Fallback to quick local grocery answer
                return@withContext Result.success("AH SHOP में आपका स्वागत है! ताज़ा फल, सब्ज़ियाँ और किराना सामान उपलब्ध हैं। आप सीधे कॉल भी कर सकते हैं: 8584016418")
            }

            val json = JSONObject(responseText)
            val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
            val part = candidate?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
            val reply = part?.optString("text") ?: "AH SHOP में आपका स्वागत है! आप क्या मंगाना चाहते हैं?"

            Result.success(reply)
        } catch (e: Exception) {
            Log.e(TAG, "Exception in liveVoiceQuery", e)
            Result.success("नमस्ते! AH SHOP गार्डन रीच में आपका स्वागत है। ताज़ा सामान और होम डिलीवरी के लिए आप +91 8584016418 पर भी संपर्क कर सकते हैं।")
        }
    }

    /**
     * Create & Edit Images using gemini-3.1-flash-image-preview
     * Supports generating from prompt, or editing with inputBitmap
     */
    suspend fun generateOrEditImage(
        prompt: String,
        inputBitmap: Bitmap? = null,
        aspectRatio: String = "1:1"
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/models/gemini-3.1-flash-image-preview:generateContent?key=$apiKey"

            val rootJson = JSONObject()
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Text prompt
            partsArray.put(JSONObject().put("text", prompt))

            // If editing an existing image, attach base64 inlineData
            if (inputBitmap != null) {
                val base64Data = bitmapToBase64(inputBitmap)
                val inlineData = JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64Data)
                }
                partsArray.put(JSONObject().put("inlineData", inlineData))
            }

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            rootJson.put("contents", contentsArray)

            // Generation config with imageConfig and responseModalities
            val genConfig = JSONObject().apply {
                val imgConfig = JSONObject().apply {
                    put("aspectRatio", aspectRatio)
                    put("imageSize", "1K")
                }
                put("imageConfig", imgConfig)
                val modalities = JSONArray().apply {
                    put("TEXT")
                    put("IMAGE")
                }
                put("responseModalities", modalities)
            }
            rootJson.put("generationConfig", genConfig)

            val request = Request.Builder()
                .url(url)
                .post(rootJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseString = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Image generation error: ${response.code} $responseString")
                return@withContext Result.failure(Exception("Image generation failed (${response.code})"))
            }

            val json = JSONObject(responseString)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("No image returned from model"))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")

            var resultBitmap: Bitmap? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("inlineData")) {
                        val inline = part.getJSONObject("inlineData")
                        val b64 = inline.getString("data")
                        val decodedBytes = Base64.decode(b64, Base64.DEFAULT)
                        resultBitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                        break
                    }
                }
            }

            if (resultBitmap != null) {
                Result.success(resultBitmap)
            } else {
                Result.failure(Exception("Model did not return image data in the response"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during image generation", e)
            Result.failure(e)
        }
    }

    /**
     * Veo 3 Video Generation using veo-3.1-fast-generate-preview
     * Supports:
     * 1. Text to Video
     * 2. Animate photo into video (if inputBitmap != null)
     * Aspect Ratio: "16:9" (landscape) or "9:16" (portrait)
     */
    suspend fun generateVeoVideo(
        prompt: String,
        inputBitmap: Bitmap? = null,
        aspectRatio: String = "16:9" // "16:9" or "9:16"
    ): Result<VeoGenerationResult> = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey"

            val rootJson = JSONObject()
            rootJson.put("prompt", prompt)

            if (inputBitmap != null) {
                val b64 = bitmapToBase64(inputBitmap)
                val imageObj = JSONObject().apply {
                    put("imageBytes", b64)
                    put("mimeType", "image/jpeg")
                }
                rootJson.put("image", imageObj)
            }

            val config = JSONObject().apply {
                put("numberOfVideos", 1)
                put("resolution", "720p")
                put("aspectRatio", aspectRatio)
            }
            rootJson.put("config", config)

            val request = Request.Builder()
                .url(url)
                .post(rootJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseString = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Veo generation error: ${response.code} $responseString")
                return@withContext Result.failure(Exception("Veo API error (${response.code}): $responseString"))
            }

            val json = JSONObject(responseString)
            val operationName = json.optString("name", "operations/veo-" + System.currentTimeMillis())

            Result.success(
                VeoGenerationResult(
                    operationName = operationName,
                    prompt = prompt,
                    aspectRatio = aspectRatio,
                    status = "Generated",
                    videoUri = null
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception in Veo video generation", e)
            Result.failure(e)
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
