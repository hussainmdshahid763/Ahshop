package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Room Entities ---

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val hindiName: String = "",
    val price: Double,
    val originalPrice: Double,
    val unit: String = "1 KG",
    val subcategory: String = "",
    val rating: Double = 4.8,
    val reviewsCount: Int = 45,
    val category: String,
    val imageIndex: Int = 1,
    val description: String,
    val sizes: String = "",
    val isFeatured: Boolean = false,
    val isNewArrival: Boolean = false,
    val imageUrl: String = "",
    val section: String = "Grocery"
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val productId: String,
    val title: String,
    val price: Double,
    val originalPrice: Double,
    val category: String,
    val imageIndex: Int,
    val selectedSize: String,
    val selectedColor: String,
    val quantity: Int,
    val imageUrl: String = "",
    val section: String = "Grocery"
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val productId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderNumber: String,
    val timestamp: Long,
    val totalAmount: Double,
    val itemsCount: Int,
    val status: String, // e.g. "Pending", "Accepted", "Out for Delivery", "Delivered", "Cancelled"
    val itemsSummary: String,
    val customerName: String = "",
    val customerPhone: String = "",
    val customerAddress: String = "",
    val paymentMethod: String = "Cash on Delivery"
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1, // Only 1 active profile locally
    val name: String,
    val email: String,
    val phone: String,
    val addressLine: String,
    val city: String,
    val state: String,
    val postalCode: String
)

// --- DAOs ---

@Dao
interface ShopDao {
    // Product catalog operations (Admin CRUD & Store listing)
    @Query("SELECT * FROM products ORDER BY category ASC, id ASC")
    fun getProducts(): Flow<List<ProductEntity>>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("DELETE FROM products WHERE id = :productId")
    suspend fun deleteProductById(productId: String)

    // Cart operations
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity)

    @Update
    suspend fun updateCartItem(item: CartItemEntity)

    @Delete
    suspend fun deleteCartItem(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE productId = :productId")
    suspend fun deleteCartItemById(productId: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    // Favorites operations
    @Query("SELECT * FROM favorites")
    fun getFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE productId = :productId)")
    fun isFavorite(productId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE productId = :productId")
    suspend fun deleteFavorite(productId: String)

    // Order History operations (Customer & Admin Management)
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE orderNumber = :orderNumber LIMIT 1")
    suspend fun getOrderByOrderNumber(orderNumber: String): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :newStatus WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Int, newStatus: String)

    @Query("UPDATE orders SET status = :newStatus WHERE orderNumber = :orderNumber")
    suspend fun updateOrderStatusByOrderNumber(orderNumber: String, newStatus: String)

    @Query("DELETE FROM orders WHERE id = :orderId")
    suspend fun deleteOrder(orderId: Int)

    @Query("DELETE FROM orders WHERE orderNumber = :orderNumber")
    suspend fun deleteOrderByOrderNumber(orderNumber: String)

    @Query("DELETE FROM orders")
    suspend fun deleteAllOrders()

    // Profile operations
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: UserProfileEntity)
}

// --- App Database ---

@Database(
    entities = [ProductEntity::class, CartItemEntity::class, FavoriteEntity::class, OrderEntity::class, UserProfileEntity::class],
    version = 3,
    exportSchema = false
)
abstract class ShopDatabase : RoomDatabase() {
    abstract fun shopDao(): ShopDao
}
