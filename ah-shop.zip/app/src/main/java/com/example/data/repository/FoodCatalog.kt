package com.example.data.repository

import com.example.data.model.Product

object FoodCatalog {
    val items: List<Product> = listOf(
        // --- BIRYANI & RICE ---
        Product(
            id = "food_1",
            title = "Kolkata Chicken Dum Biryani",
            hindiName = "कोलकाता चिकन दम बिरयानी",
            price = 190.0,
            originalPrice = 220.0,
            unit = "1 Plate",
            subcategory = "Biryani",
            category = "Biryani & Rice",
            description = "Aromatic long-grain basmati rice cooked with tender chicken, spiced aloo (potato) and boiled egg.",
            imageUrl = "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80",
            section = "Food",
            isFeatured = true
        ),
        Product(
            id = "food_2",
            title = "Kolkata Mutton Dum Biryani",
            hindiName = "कोलकाता मटन बिरयानी",
            price = 260.0,
            originalPrice = 299.0,
            unit = "1 Plate",
            subcategory = "Biryani",
            category = "Biryani & Rice",
            description = "Rich & juicy mutton piece cooked in traditional Kolkata dum pukht style with fragrant rice and saffron.",
            imageUrl = "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=600&q=80",
            section = "Food",
            isFeatured = true
        ),
        Product(
            id = "food_3",
            title = "Hyderabadi Veg Dum Biryani",
            hindiName = "वेज दम बिरयानी",
            price = 140.0,
            originalPrice = 170.0,
            unit = "1 Plate",
            subcategory = "Biryani",
            category = "Biryani & Rice",
            description = "Fresh seasonal vegetables, paneer cubes and caramelized onions layered with fragrant basmati rice.",
            imageUrl = "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_4",
            title = "Jeera Rice & Dal Makhani Combo",
            hindiName = "जीरा राइस व दाल मखनी",
            price = 150.0,
            originalPrice = 180.0,
            unit = "1 Combo",
            subcategory = "Rice Meals",
            category = "Biryani & Rice",
            description = "Fluffy cumin spiced basmati rice served with rich, slow-cooked creamy black dal makhani.",
            imageUrl = "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),

        // --- ROLLS & KEBABS ---
        Product(
            id = "food_5",
            title = "Chicken Kathi Roll",
            hindiName = "चिकन काठी रोल",
            price = 80.0,
            originalPrice = 95.0,
            unit = "1 Roll",
            subcategory = "Rolls",
            category = "Rolls & Kebabs",
            description = "Crispy laccha paratha wrapped with juicy spiced chicken boti, sliced onions and tangy green chutney.",
            imageUrl = "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=600&q=80",
            section = "Food",
            isFeatured = true
        ),
        Product(
            id = "food_6",
            title = "Double Egg Chicken Roll",
            hindiName = "डबल एग चिकन रोल",
            price = 95.0,
            originalPrice = 115.0,
            unit = "1 Roll",
            subcategory = "Rolls",
            category = "Rolls & Kebabs",
            description = "Crispy paratha coated with double eggs and stuffed with tender chicken tikka and secret roll masala.",
            imageUrl = "https://images.unsplash.com/photo-1606471191009-63994c53433b?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_7",
            title = "Paneer Tikka Roll",
            hindiName = "पनीर टिक्का रोल",
            price = 75.0,
            originalPrice = 90.0,
            unit = "1 Roll",
            subcategory = "Rolls",
            category = "Rolls & Kebabs",
            description = "Marinated grilled paneer cubes wrapped in layered flaky paratha with mint mayo and lemon onions.",
            imageUrl = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_8",
            title = "Tandoori Chicken (Half)",
            hindiName = "तंदूरी चिकन",
            price = 190.0,
            originalPrice = 220.0,
            unit = "Half (4 Pcs)",
            subcategory = "Kebabs",
            category = "Rolls & Kebabs",
            description = "Charcoal-grilled tender chicken marinated in Kashmiri red chilli, yogurt and aromatic spices.",
            imageUrl = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),

        // --- MAIN COURSE ---
        Product(
            id = "food_9",
            title = "Paneer Butter Masala",
            hindiName = "पनीर बटर मसाला",
            price = 180.0,
            originalPrice = 210.0,
            unit = "500 ML",
            subcategory = "Curry",
            category = "Main Course",
            description = "Soft malai paneer cubes simmered in a velvety, rich tomato cashew butter gravy.",
            imageUrl = "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80",
            section = "Food",
            isFeatured = true
        ),
        Product(
            id = "food_10",
            title = "Chicken Butter Masala",
            hindiName = "चिकन बटर मसाला",
            price = 210.0,
            originalPrice = 250.0,
            unit = "4 Pcs",
            subcategory = "Chicken",
            category = "Main Course",
            description = "Succulent tandoori chicken cooked in smooth buttery makhani gravy with cream drizzle.",
            imageUrl = "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_11",
            title = "Kadhai Chicken",
            hindiName = "कड़ाही चिकन",
            price = 195.0,
            originalPrice = 230.0,
            unit = "4 Pcs",
            subcategory = "Chicken",
            category = "Main Course",
            description = "Spicy bone-in chicken cooked with bell peppers, onions and freshly ground kadhai masala.",
            imageUrl = "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_12",
            title = "Butter Naan (2 Pcs)",
            hindiName = "बटर नान (२ पीस)",
            price = 60.0,
            originalPrice = 75.0,
            unit = "2 Pcs",
            subcategory = "Breads",
            category = "Main Course",
            description = "Soft, fluffy clay-oven baked refined flour bread brushed with melted salted amul butter.",
            imageUrl = "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),

        // --- FAST FOOD ---
        Product(
            id = "food_13",
            title = "Veg Hakka Noodles",
            hindiName = "वेज हक्का नूडल्स",
            price = 90.0,
            originalPrice = 110.0,
            unit = "1 Plate",
            subcategory = "Chinese",
            category = "Fast Food",
            description = "Wok-tossed noodles with shredded cabbage, carrots, capsicum and mild soy-chilli seasoning.",
            imageUrl = "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_14",
            title = "Chicken Hakka Noodles",
            hindiName = "चिकन हक्का नूडल्स",
            price = 130.0,
            originalPrice = 155.0,
            unit = "1 Plate",
            subcategory = "Chinese",
            category = "Fast Food",
            description = "Stir-fried noodles tossed with boneless chicken bits, scrambled egg and crunchy greens.",
            imageUrl = "https://images.unsplash.com/photo-1612927601601-6638404737ce?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_15",
            title = "Chilli Chicken Dry (8 Pcs)",
            hindiName = "चिली चिकन ड्राई",
            price = 160.0,
            originalPrice = 190.0,
            unit = "8 Pcs",
            subcategory = "Chinese",
            category = "Fast Food",
            description = "Crispy batter-fried chicken bites wok-tossed with green chillies, garlic and spring onions.",
            imageUrl = "https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_16",
            title = "Veg Cheese Burger",
            hindiName = "वेज चीज़ बर्गर",
            price = 80.0,
            originalPrice = 100.0,
            unit = "1 PC",
            subcategory = "Burgers",
            category = "Fast Food",
            description = "Crispy herb potato patty topped with melted cheese slice, lettuce, tomato and creamy burger sauce.",
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_17",
            title = "Cheese Margherita Pizza",
            hindiName = "चीज़ मार्गेरीटा पिज़्ज़ा",
            price = 189.0,
            originalPrice = 229.0,
            unit = "7 Inch",
            subcategory = "Pizza",
            category = "Fast Food",
            description = "Freshly baked pizza loaded with 100% mozzarella cheese, Italian herb tomato sauce and basil.",
            imageUrl = "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),

        // --- SNACKS & CHAAT ---
        Product(
            id = "food_18",
            title = "Crispy Masala Dosa",
            hindiName = "मसाला डोसा",
            price = 90.0,
            originalPrice = 110.0,
            unit = "1 Plate",
            subcategory = "South Indian",
            category = "Snacks & Chaat",
            description = "Golden crispy rice-lentil crepe filled with spiced mustard potato masala, served with sambar and chutney.",
            imageUrl = "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_19",
            title = "Hot Aloo Samosa (2 Pcs)",
            hindiName = "गरम आलू समोसा (२ पीस)",
            price = 30.0,
            originalPrice = 40.0,
            unit = "2 Pcs",
            subcategory = "Snacks",
            category = "Snacks & Chaat",
            description = "Crispy golden fried pastry cones stuffed with spicy green peas and potato filling, served with saunth.",
            imageUrl = "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80",
            section = "Food",
            isFeatured = true
        ),

        // --- SWEETS & DESSERTS ---
        Product(
            id = "food_20",
            title = "Warm Gulab Jamun (2 Pcs)",
            hindiName = "गरम गुलाब जामुन",
            price = 40.0,
            originalPrice = 50.0,
            unit = "2 Pcs",
            subcategory = "Sweets",
            category = "Sweets & Desserts",
            description = "Soft khoya milk dumplings fried to golden perfection and soaked in cardamom rose sugar syrup.",
            imageUrl = "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_21",
            title = "Kolkata Sponge Rasgulla (2 Pcs)",
            hindiName = "कोलकाता स्पंज रसगुल्ला",
            price = 35.0,
            originalPrice = 45.0,
            unit = "2 Pcs",
            subcategory = "Sweets",
            category = "Sweets & Desserts",
            description = "Fresh chhena cottage cheese spheres cooked in light aromatic sugar syrup. Melts in mouth.",
            imageUrl = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),

        // --- BEVERAGES ---
        Product(
            id = "food_22",
            title = "Special Kulhad Masala Chai",
            hindiName = "कुल्हड़ मसाला चाय",
            price = 25.0,
            originalPrice = 35.0,
            unit = "1 Cup",
            subcategory = "Chai",
            category = "Beverages",
            description = "Strong milk tea brewed with ginger, crushed cardamom and cloves, served in traditional clay kulhad.",
            imageUrl = "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_23",
            title = "Sweet Punjabi Lassi",
            hindiName = "मीठी पंजाबी लस्सी",
            price = 45.0,
            originalPrice = 55.0,
            unit = "300 ML",
            subcategory = "Cold Drinks",
            category = "Beverages",
            description = "Thick, creamy churned yogurt drink topped with rich malai and slivered pistachios.",
            imageUrl = "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        ),
        Product(
            id = "food_24",
            title = "Thick Cold Coffee",
            hindiName = "कोल्ड कॉफी",
            price = 65.0,
            originalPrice = 80.0,
            unit = "300 ML",
            subcategory = "Cold Drinks",
            category = "Beverages",
            description = "Chilled rich espresso blended with creamy milk and chocolate drizzle.",
            imageUrl = "https://images.unsplash.com/photo-1517256064527-09c73fc73e38?auto=format&fit=crop&w=600&q=80",
            section = "Food"
        )
    )
}
