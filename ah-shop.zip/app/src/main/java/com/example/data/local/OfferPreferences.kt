package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

data class StoreOffer(
    val isEnabled: Boolean = false, // Disabled by default ("hata do"), admin can enable and customize from Admin Panel
    val bannerTag: String = "SPECIAL GROCERY OFFER",
    val title: String = "Save ₹50 flat on orders over ₹200",
    val couponCode: String = "WELCOME50",
    val discountAmount: Double = 50.0,
    val minSpend: Double = 200.0,
    val subtitle: String = "Use coupon code: WELCOME50"
)

object OfferPreferences {
    private const val PREFS_NAME = "ah_shop_offer_prefs"
    private const val KEY_ENABLED = "offer_enabled"
    private const val KEY_TAG = "offer_tag"
    private const val KEY_TITLE = "offer_title"
    private const val KEY_CODE = "offer_code"
    private const val KEY_DISCOUNT = "offer_discount"
    private const val KEY_MIN_SPEND = "offer_min_spend"
    private const val KEY_SUBTITLE = "offer_subtitle"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun getOffer(): StoreOffer {
        val p = prefs ?: return StoreOffer(isEnabled = false)
        return StoreOffer(
            isEnabled = p.getBoolean(KEY_ENABLED, false),
            bannerTag = p.getString(KEY_TAG, "SPECIAL GROCERY OFFER") ?: "SPECIAL GROCERY OFFER",
            title = p.getString(KEY_TITLE, "Save ₹50 flat on orders over ₹200") ?: "Save ₹50 flat on orders over ₹200",
            couponCode = p.getString(KEY_CODE, "WELCOME50") ?: "WELCOME50",
            discountAmount = p.getFloat(KEY_DISCOUNT, 50f).toDouble(),
            minSpend = p.getFloat(KEY_MIN_SPEND, 200f).toDouble(),
            subtitle = p.getString(KEY_SUBTITLE, "Use coupon code: WELCOME50") ?: "Use coupon code: WELCOME50"
        )
    }

    fun saveOffer(offer: StoreOffer) {
        prefs?.edit()?.apply {
            putBoolean(KEY_ENABLED, offer.isEnabled)
            putString(KEY_TAG, offer.bannerTag)
            putString(KEY_TITLE, offer.title)
            putString(KEY_CODE, offer.couponCode.trim().uppercase())
            putFloat(KEY_DISCOUNT, offer.discountAmount.toFloat())
            putFloat(KEY_MIN_SPEND, offer.minSpend.toFloat())
            putString(KEY_SUBTITLE, offer.subtitle)
            apply()
        }
    }
}
