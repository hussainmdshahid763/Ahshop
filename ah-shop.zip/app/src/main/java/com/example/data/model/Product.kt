package com.example.data.model

import androidx.compose.ui.graphics.Color

data class Product(
    val id: String,
    val title: String,
    val hindiName: String = "",
    val price: Double,
    val originalPrice: Double,
    val unit: String = "1 KG",
    val subcategory: String = "",
    val rating: Double = 4.8,
    val reviewsCount: Int = 45,
    val category: String,
    val imageIndex: Int = 1, // Refers to custom local visual drawing index
    val description: String,
    val sizes: List<String> = emptyList(),
    val colors: List<String> = emptyList(),
    val isFeatured: Boolean = false,
    val isNewArrival: Boolean = false,
    val colorHexes: List<Color> = emptyList(),
    val imageUrl: String = "",
    val section: String = "Grocery" // "Grocery", "Food", "E-Commerce"
)

data class ProductReview(
    val author: String,
    val rating: Int,
    val comment: String,
    val date: String
)
