package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

object DeviceOrderPreferences {
    private const val PREFS_NAME = "ah_shop_device_orders"
    private const val KEY_ORDER_IDS = "placed_order_numbers"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun getPlacedOrders(): Set<String> {
        val p = prefs ?: return emptySet()
        return p.getStringSet(KEY_ORDER_IDS, emptySet()) ?: emptySet()
    }

    fun addPlacedOrder(orderNumber: String) {
        val p = prefs ?: return
        val current = p.getStringSet(KEY_ORDER_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.add(orderNumber)
        p.edit().putStringSet(KEY_ORDER_IDS, current).apply()
    }

    fun clearAll() {
        prefs?.edit()?.remove(KEY_ORDER_IDS)?.apply()
    }

    private const val KEY_TEST_ORDERS_PURGED = "has_purged_test_orders_v2"

    fun hasPurgedTestOrders(): Boolean {
        return prefs?.getBoolean(KEY_TEST_ORDERS_PURGED, false) ?: false
    }

    fun markPurged() {
        prefs?.edit()?.putBoolean(KEY_TEST_ORDERS_PURGED, true)?.apply()
    }
}
