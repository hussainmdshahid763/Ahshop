package com.example.data.repository

import androidx.compose.ui.graphics.Color
import com.example.data.local.*
import com.example.data.model.Product
import com.example.data.model.ProductReview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ShopRepository(private val shopDao: ShopDao) {

    companion object {
        private const val TAG = "ShopRepository"
        private const val CENTRAL_CLOUD_SYNC_URL = "https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/central_orders"
        private const val ORDER_PREFIX_URL = "https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/order_"
        private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

        private val httpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(12, TimeUnit.SECONDS)
                .writeTimeout(12, TimeUnit.SECONDS)
                .build()
        }
    }

    // Dynamic Product Catalog from Room database
    val products: Flow<List<Product>> = shopDao.getProducts().map { list ->
        if (list.isEmpty()) {
            GroceryCatalog.items
        } else {
            list.map { it.toProduct() }
        }
    }

    // Dynamic Database Operations
    val cartItems: Flow<List<CartItemEntity>> = shopDao.getCartItems()
    val favorites: Flow<List<FavoriteEntity>> = shopDao.getFavorites()
    val orders: Flow<List<OrderEntity>> = shopDao.getOrders()
    val profile: Flow<UserProfileEntity?> = shopDao.getProfile()

    suspend fun ensureProductsSeeded() {
        try {
            val totalCombinedCatalog = GroceryCatalog.items + FoodCatalog.items + EcommerceCatalog.items
            val currentCount = shopDao.getProductsCount()
            if (currentCount == 0) {
                val entities = totalCombinedCatalog.map { it.toEntity() }
                shopDao.insertAllProducts(entities)
            } else if (currentCount < 180) {
                // Ensure Food and E-Commerce catalogs are populated
                val foodAndEcom = (FoodCatalog.items + EcommerceCatalog.items).map { it.toEntity() }
                shopDao.insertAllProducts(foodAndEcom)
            }
        } catch (e: Exception) {
            Log.e("ShopRepository", "Error seeding products: ${e.message}")
        }
    }

    // Product Management (Admin CRUD)
    suspend fun addProduct(product: Product) {
        shopDao.insertProduct(product.toEntity())
    }

    suspend fun updateProduct(product: Product) {
        shopDao.updateProduct(product.toEntity())
    }

    suspend fun deleteProduct(productId: String) {
        shopDao.deleteProductById(productId)
    }

    // Order Management (Admin)
    suspend fun updateOrderStatus(orderId: Int, newStatus: String) {
        shopDao.updateOrderStatus(orderId, newStatus)
        syncOrdersProgress()
        withContext(Dispatchers.IO) {
            try {
                // Also update status in central cloud sync
                updateOrderStatusInCloud(orderId, newStatus)
            } catch (e: Exception) {
                Log.e(TAG, "Error updating status in cloud", e)
            }
        }
    }

    suspend fun deleteOrder(orderId: Int) {
        val list = shopDao.getOrders().map { it }.firstOrNull() ?: emptyList()
        val target = list.find { it.id == orderId }
        shopDao.deleteOrder(orderId)
        syncOrdersProgress()
        withContext(Dispatchers.IO) {
            try {
                if (target != null) {
                    deleteOrderFromCloud(target.orderNumber)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting order in cloud", e)
            }
        }
    }

    suspend fun clearAllOrders(): Boolean = withContext(Dispatchers.IO) {
        var success = false
        try {
            shopDao.deleteAllOrders()
            // Clear cloud central array
            try {
                val postRequest = Request.Builder()
                    .url(CENTRAL_CLOUD_SYNC_URL)
                    .post("[]".toRequestBody(jsonMediaType))
                    .build()
                httpClient.newCall(postRequest).execute().close()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to clear central cloud orders: ${e.message}")
            }

            // Clear prefix keys
            try {
                val prefixRequest = Request.Builder()
                    .url("https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/?prefix=order_&format=json")
                    .get()
                    .build()
                val prefixResp = httpClient.newCall(prefixRequest).execute()
                val prefixBody = prefixResp.body?.string().orEmpty()
                prefixResp.close()
                if (prefixBody.startsWith("[")) {
                    val keyArray = JSONArray(prefixBody)
                    for (i in 0 until keyArray.length()) {
                        val k = keyArray.optString(i)
                        if (k.isNotBlank()) {
                            try {
                                val delReq = Request.Builder()
                                    .url("https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/$k")
                                    .delete()
                                    .build()
                                httpClient.newCall(delReq).execute().close()
                            } catch (_: Exception) {}
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to clear prefix keys: ${e.message}")
            }
            syncOrdersProgress()
            success = true
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing all orders", e)
        }
        success
    }

    // Mock Reviews provider
    fun getProductReviews(productId: String): List<ProductReview> {
        return listOf(
            ProductReview("Jessica K.", 5, "Remarkable build. Fits flawlessly into my routine. Exceeds standard expectations!", "2 weeks ago"),
            ProductReview("David L.", 4, "Truly beautiful design ethos. Materials look and feel incredibly high quality. Highly recommended.", "3 days ago"),
            ProductReview("Michael S.", 5, "Pure craftsmanship! Shipping was clean, and support resolved sizing inquiries instantly.", "Yesterday")
        )
    }

    // Cart Handlers
    // --- Firestore Sync Engine ---
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: java.lang.Exception) {
            Log.e("ShopRepository", "Firestore not initialized. Ensure google-services.json is valid or Firebase is initialized.", e)
            null
        }
    }

    private fun syncToFirestore(collectionPath: String, documentId: String, data: Any) {
        try {
            val db = firestore ?: return
            db.collection(collectionPath)
                .document(documentId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("ShopRepository", "Synced $documentId successfully to $collectionPath")
                }
                .addOnFailureListener { e ->
                    Log.e("ShopRepository", "Failed to sync $documentId to $collectionPath", e)
                }
        } catch (e: Exception) {
            Log.e("ShopRepository", "Error syncing to Firestore: ${e.message}")
        }
    }

    private suspend fun getUserEmail(): String {
        return try {
            val p = shopDao.getProfile().map { it }.firstOrNull()
            p?.email?.replace(".", "_")?.ifBlank { "anonymous_user" } ?: "anonymous_user"
        } catch (e: Exception) {
            "anonymous_user"
        }
    }

    private suspend fun syncCartProgress() {
        try {
            val email = getUserEmail()
            val list = shopDao.getCartItems().map { it }.firstOrNull() ?: emptyList()
            val data = mapOf(
                "items" to list.map { item ->
                    mapOf(
                        "productId" to item.productId,
                        "title" to item.title,
                        "price" to item.price,
                        "originalPrice" to item.originalPrice,
                        "category" to item.category,
                        "imageIndex" to item.imageIndex,
                        "selectedSize" to item.selectedSize,
                        "selectedColor" to item.selectedColor,
                        "quantity" to item.quantity
                    )
                },
                "lastUpdated" to System.currentTimeMillis()
            )
            syncToFirestore("users/$email/progress", "cart", data)
        } catch (e: Exception) {
            Log.e("ShopRepository", "syncCartProgress error", e)
        }
    }

    private suspend fun syncFavoritesProgress() {
        try {
            val email = getUserEmail()
            val list = shopDao.getFavorites().map { it }.firstOrNull() ?: emptyList()
            val data = mapOf(
                "productIds" to list.map { it.productId },
                "lastUpdated" to System.currentTimeMillis()
            )
            syncToFirestore("users/$email/progress", "favorites", data)
        } catch (e: Exception) {
            Log.e("ShopRepository", "syncFavoritesProgress error", e)
        }
    }

    private suspend fun syncOrdersProgress() {
        try {
            val email = getUserEmail()
            val list = shopDao.getOrders().map { it }.firstOrNull() ?: emptyList()
            val data = mapOf(
                "orders" to list.map { order ->
                    mapOf(
                        "orderNumber" to order.orderNumber,
                        "timestamp" to order.timestamp,
                        "totalAmount" to order.totalAmount,
                        "itemsCount" to order.itemsCount,
                        "status" to order.status,
                        "itemsSummary" to order.itemsSummary,
                        "customerName" to order.customerName,
                        "customerPhone" to order.customerPhone,
                        "customerAddress" to order.customerAddress,
                        "paymentMethod" to order.paymentMethod
                    )
                },
                "lastUpdated" to System.currentTimeMillis()
            )
            syncToFirestore("users/$email/progress", "orders", data)
        } catch (e: Exception) {
            Log.e("ShopRepository", "syncOrdersProgress error", e)
        }
    }

    private suspend fun syncProfileProgress(profile: UserProfileEntity) {
        try {
            val email = profile.email.replace(".", "_").ifBlank { "anonymous_user" }
            val data = mapOf(
                "name" to profile.name,
                "email" to profile.email,
                "phone" to profile.phone,
                "addressLine" to profile.addressLine,
                "city" to profile.city,
                "state" to profile.state,
                "postalCode" to profile.postalCode,
                "lastUpdated" to System.currentTimeMillis()
            )
            syncToFirestore("users/$email/progress", "profile", data)
        } catch (e: Exception) {
            Log.e("ShopRepository", "syncProfileProgress error", e)
        }
    }

    // Cart Handlers
    suspend fun addToCart(item: CartItemEntity) {
        shopDao.insertCartItem(item)
        syncCartProgress()
    }

    suspend fun updateCartQuantity(item: CartItemEntity) {
        if (item.quantity <= 0) {
            shopDao.deleteCartItem(item)
        } else {
            shopDao.insertCartItem(item)
        }
        syncCartProgress()
    }

    suspend fun removeFromCart(item: CartItemEntity) {
        shopDao.deleteCartItem(item)
        syncCartProgress()
    }

    suspend fun removeFromCartById(productId: String) {
        shopDao.deleteCartItemById(productId)
        syncCartProgress()
    }

    suspend fun clearCart() {
        shopDao.clearCart()
        syncCartProgress()
    }

    // Favorites Handlers
    suspend fun toggleFavorite(productId: String, isFav: Boolean) {
        if (isFav) {
            shopDao.deleteFavorite(productId)
        } else {
            shopDao.insertFavorite(FavoriteEntity(productId))
        }
        syncFavoritesProgress()
    }

    fun isFavoriteItem(productId: String): Flow<Boolean> = shopDao.isFavorite(productId)

    // Order Handlers
    suspend fun placeOrder(
        orderNumber: String,
        totalAmount: Double,
        itemsCount: Int,
        summary: String,
        customerName: String,
        customerPhone: String,
        customerAddress: String,
        paymentMethod: String = "Cash on Delivery"
    ): OrderEntity {
        val order = OrderEntity(
            orderNumber = orderNumber,
            timestamp = System.currentTimeMillis(),
            totalAmount = totalAmount,
            itemsCount = itemsCount,
            status = "Pending", // Admin can review and accept/deliver
            itemsSummary = summary,
            customerName = customerName.trim(),
            customerPhone = customerPhone.trim(),
            customerAddress = customerAddress.trim(),
            paymentMethod = paymentMethod
        )
        shopDao.insertOrder(order)
        shopDao.clearCart()

        // Push directly to Central Cloud Sync so Admin on any phone sees it immediately
        withContext(Dispatchers.IO) {
            try {
                pushOrderToCloud(order)
            } catch (e: Exception) {
                Log.e(TAG, "Error pushing order to central cloud", e)
            }
        }
        return order
    }

    /**
     * Pushes an order to the Central Cloud Sync endpoint (kvdb.io)
     * Reads the current order list, prepends the new order, and writes back.
     * Also writes to a dedicated order_<orderNumber> key with retries.
     */
    suspend fun pushOrderToCloud(order: OrderEntity): Boolean = withContext(Dispatchers.IO) {
        var success = false
        try {
            val orderObj = JSONObject().apply {
                put("orderNumber", order.orderNumber)
                put("timestamp", order.timestamp)
                put("totalAmount", order.totalAmount)
                put("itemsCount", order.itemsCount)
                put("status", order.status)
                put("itemsSummary", order.itemsSummary)
                put("customerName", order.customerName)
                put("customerPhone", order.customerPhone)
                put("customerAddress", order.customerAddress)
                put("paymentMethod", order.paymentMethod)
            }

            // 1. Write individual order key with retry
            for (attempt in 1..3) {
                try {
                    val singleRequest = Request.Builder()
                        .url("$ORDER_PREFIX_URL${order.orderNumber}")
                        .post(orderObj.toString().toRequestBody(jsonMediaType))
                        .build()
                    val resp = httpClient.newCall(singleRequest).execute()
                    val isOk = resp.isSuccessful
                    resp.close()
                    if (isOk) {
                        success = true
                        Log.d(TAG, "Order ${order.orderNumber} pushed as individual key")
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Single order push attempt $attempt failed: ${e.message}")
                }
            }

            // 2. Update central orders array with retry
            for (attempt in 1..3) {
                try {
                    val getRequest = Request.Builder()
                        .url(CENTRAL_CLOUD_SYNC_URL)
                        .get()
                        .build()

                    val existingArray = try {
                        val response = httpClient.newCall(getRequest).execute()
                        val body = response.body?.string().orEmpty()
                        response.close()
                        if (body.startsWith("[")) JSONArray(body) else JSONArray()
                    } catch (e: Exception) {
                        JSONArray()
                    }

                    val newArray = JSONArray()
                    newArray.put(orderObj) // Put newest order at the top

                    // Add other orders (avoid duplicates of same orderNumber)
                    for (i in 0 until existingArray.length()) {
                        val item = existingArray.optJSONObject(i) ?: continue
                        if (item.optString("orderNumber") != order.orderNumber) {
                            newArray.put(item)
                        }
                    }

                    val putRequest = Request.Builder()
                        .url(CENTRAL_CLOUD_SYNC_URL)
                        .post(newArray.toString().toRequestBody(jsonMediaType))
                        .build()

                    val putResponse = httpClient.newCall(putRequest).execute()
                    val isOk = putResponse.isSuccessful
                    putResponse.close()
                    if (isOk) {
                        success = true
                        Log.d(TAG, "Order ${order.orderNumber} successfully pushed to central cloud: ${putResponse.code}")
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Central orders push attempt $attempt failed: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to push order to central cloud", e)
        }
        success
    }

    /**
     * Synchronizes orders from the Central Cloud into the local Room database.
     * Checks both central list and prefix keys to guarantee 100% cross-device delivery.
     */
    suspend fun syncOrdersFromCloud(): Int = withContext(Dispatchers.IO) {
        var count = 0
        try {
            // First: Fetch from CENTRAL_CLOUD_SYNC_URL
            try {
                val request = Request.Builder()
                    .url(CENTRAL_CLOUD_SYNC_URL)
                    .get()
                    .build()

                val response = httpClient.newCall(request).execute()
                val responseBody = response.body?.string().orEmpty()
                response.close()

                if (responseBody.startsWith("[")) {
                    val array = JSONArray(responseBody)
                    for (i in 0 until array.length()) {
                        val obj = array.optJSONObject(i) ?: continue
                        val orderNo = obj.optString("orderNumber")
                        if (orderNo.isBlank()) continue

                        val existing = shopDao.getOrderByOrderNumber(orderNo)
                        val status = obj.optString("status", "Pending")

                        if (existing != null) {
                            if (existing.status != status) {
                                shopDao.updateOrderStatusByOrderNumber(orderNo, status)
                            }
                        } else {
                            val newEntity = OrderEntity(
                                orderNumber = orderNo,
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                totalAmount = obj.optDouble("totalAmount", 0.0),
                                itemsCount = obj.optInt("itemsCount", 1),
                                status = status,
                                itemsSummary = obj.optString("itemsSummary", ""),
                                customerName = obj.optString("customerName", "Customer"),
                                customerPhone = obj.optString("customerPhone", ""),
                                customerAddress = obj.optString("customerAddress", ""),
                                paymentMethod = obj.optString("paymentMethod", "Cash on Delivery")
                            )
                            shopDao.insertOrder(newEntity)
                            count++
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Central cloud sync fetch failed: ${e.message}")
            }

            // Second: Also query prefix keys to catch any individual orders
            try {
                val prefixRequest = Request.Builder()
                    .url("https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/?prefix=order_&format=json")
                    .get()
                    .build()
                val prefixResp = httpClient.newCall(prefixRequest).execute()
                val prefixBody = prefixResp.body?.string().orEmpty()
                prefixResp.close()

                if (prefixBody.startsWith("[")) {
                    val keyArray = JSONArray(prefixBody)
                    for (k in 0 until keyArray.length()) {
                        val keyName = keyArray.optString(k)
                        val orderNum = keyName.removePrefix("order_")
                        if (orderNum.isBlank()) continue

                        val exists = shopDao.getOrderByOrderNumber(orderNum)
                        if (exists == null) {
                            val singleReq = Request.Builder()
                                .url("https://kvdb.io/9h2yyUNPmWtyHpL6k1PN8r/$keyName")
                                .get()
                                .build()
                            val singleResp = httpClient.newCall(singleReq).execute()
                            val singleBody = singleResp.body?.string().orEmpty()
                            singleResp.close()

                            if (singleBody.startsWith("{")) {
                                val obj = JSONObject(singleBody)
                                val newEntity = OrderEntity(
                                    orderNumber = obj.optString("orderNumber", orderNum),
                                    timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                    totalAmount = obj.optDouble("totalAmount", 0.0),
                                    itemsCount = obj.optInt("itemsCount", 1),
                                    status = obj.optString("status", "Pending"),
                                    itemsSummary = obj.optString("itemsSummary", ""),
                                    customerName = obj.optString("customerName", "Customer"),
                                    customerPhone = obj.optString("customerPhone", ""),
                                    customerAddress = obj.optString("customerAddress", ""),
                                    paymentMethod = obj.optString("paymentMethod", "Cash on Delivery")
                                )
                                shopDao.insertOrder(newEntity)
                                count++
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Prefix orders sync check failed: ${e.message}")
            }

            if (count > 0) {
                Log.d(TAG, "Cloud sync complete: $count new orders saved to local database.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during cloud orders sync", e)
        }
        count
    }

    private suspend fun updateOrderStatusInCloud(orderId: Int, newStatus: String) = withContext(Dispatchers.IO) {
        try {
            val list = shopDao.getOrders().map { it }.firstOrNull() ?: return@withContext
            val target = list.find { it.id == orderId } ?: return@withContext

            val getRequest = Request.Builder().url(CENTRAL_CLOUD_SYNC_URL).get().build()
            val response = httpClient.newCall(getRequest).execute()
            if (!response.isSuccessful) return@withContext

            val body = response.body?.string().orEmpty()
            if (!body.startsWith("[")) return@withContext

            val array = JSONArray(body)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (item.optString("orderNumber") == target.orderNumber) {
                    item.put("status", newStatus)
                }
            }

            val postRequest = Request.Builder()
                .url(CENTRAL_CLOUD_SYNC_URL)
                .post(array.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(postRequest).execute().close()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating status in cloud", e)
        }
    }

    private suspend fun deleteOrderFromCloud(orderNumber: String) = withContext(Dispatchers.IO) {
        try {
            val getRequest = Request.Builder().url(CENTRAL_CLOUD_SYNC_URL).get().build()
            val response = httpClient.newCall(getRequest).execute()
            if (!response.isSuccessful) return@withContext

            val body = response.body?.string().orEmpty()
            if (!body.startsWith("[")) return@withContext

            val array = JSONArray(body)
            val updated = JSONArray()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                if (item.optString("orderNumber") != orderNumber) {
                    updated.put(item)
                }
            }

            val postRequest = Request.Builder()
                .url(CENTRAL_CLOUD_SYNC_URL)
                .post(updated.toString().toRequestBody(jsonMediaType))
                .build()
            httpClient.newCall(postRequest).execute().close()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting order in cloud", e)
        }
    }

    // Profile Handlers
    suspend fun saveProfile(profileEntity: UserProfileEntity) {
        shopDao.saveProfile(profileEntity)
        syncProfileProgress(profileEntity)
    }

    suspend fun ensureDefaultProfile() {
        // Customer profile should NOT default to Admin's shop address!
        val currentProfile = shopDao.getProfile().map { it }.firstOrNull()
        if (currentProfile == null || currentProfile.name == "Shahid Hussain" || currentProfile.phone.contains("8584016418")) {
            // Initialize with an empty customer profile so the customer is prompted to enter their own details
            val emptyCustomerProfile = UserProfileEntity(
                name = "",
                email = "",
                phone = "",
                addressLine = "",
                city = "Kolkata",
                state = "West Bengal",
                postalCode = "700024"
            )
            shopDao.saveProfile(emptyCustomerProfile)
        }
    }
}

// Entity Mappers
fun ProductEntity.toProduct(): Product = Product(
    id = id,
    title = title,
    hindiName = hindiName,
    price = price,
    originalPrice = originalPrice,
    unit = unit,
    subcategory = subcategory,
    rating = rating,
    reviewsCount = reviewsCount,
    category = category,
    imageIndex = imageIndex,
    description = description,
    sizes = if (sizes.isBlank()) emptyList() else sizes.split(",").map { it.trim() },
    isFeatured = isFeatured,
    isNewArrival = isNewArrival,
    imageUrl = imageUrl,
    section = section
)

fun Product.toEntity(): ProductEntity = ProductEntity(
    id = id,
    title = title,
    hindiName = hindiName,
    price = price,
    originalPrice = originalPrice,
    unit = unit,
    subcategory = subcategory,
    rating = rating,
    reviewsCount = reviewsCount,
    category = category,
    imageIndex = imageIndex,
    description = description,
    sizes = sizes.joinToString(","),
    isFeatured = isFeatured,
    isNewArrival = isNewArrival,
    imageUrl = imageUrl,
    section = section
)
