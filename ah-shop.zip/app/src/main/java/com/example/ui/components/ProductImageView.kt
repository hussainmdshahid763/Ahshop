package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.model.Product

/**
 * Returns a high quality curated image for standard products if a custom image URL was not explicitly set.
 */
fun getCuratedImageUrl(title: String, category: String, section: String): String {
    val t = title.lowercase()
    val c = category.lowercase()
    val s = section.lowercase()

    // 1. Food Section
    if (s.contains("food") || c.contains("biryani") || c.contains("roll") || c.contains("noodle") || c.contains("curry")) {
        return when {
            t.contains("biryani") -> "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
            t.contains("roll") -> "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=600&q=80"
            t.contains("kebab") || t.contains("tandoori") -> "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80"
            t.contains("paneer") -> "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80"
            t.contains("chicken") -> "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80"
            t.contains("naan") || t.contains("roti") -> "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80"
            t.contains("noodle") || t.contains("chowmein") -> "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80"
            t.contains("burger") -> "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"
            t.contains("pizza") -> "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80"
            t.contains("dosa") -> "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=600&q=80"
            t.contains("samosa") -> "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80"
            t.contains("gulab jamun") || t.contains("sweet") || t.contains("rasgulla") -> "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80"
            t.contains("chai") || t.contains("tea") -> "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80"
            t.contains("lassi") || t.contains("coffee") -> "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80"
            else -> "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80"
        }
    }

    // 2. E-Commerce Section
    if (s.contains("ecom") || s.contains("commerce") || c.contains("electronics") || c.contains("fashion") || c.contains("accessories")) {
        return when {
            t.contains("earbud") || t.contains("headphone") || t.contains("tws") -> "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80"
            t.contains("neckband") -> "https://images.unsplash.com/photo-1577174881658-0f30ed549adc?auto=format&fit=crop&w=600&q=80"
            t.contains("watch") -> "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80"
            t.contains("power bank") -> "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=600&q=80"
            t.contains("charger") || t.contains("cable") -> "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80"
            t.contains("stand") || t.contains("holder") -> "https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=600&q=80"
            t.contains("shirt") || t.contains("t-shirt") -> "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80"
            t.contains("jean") || t.contains("denim") -> "https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=600&q=80"
            t.contains("bag") || t.contains("backpack") -> "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80"
            t.contains("bottle") -> "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80"
            t.contains("chopper") || t.contains("knife") -> "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=600&q=80"
            t.contains("kettle") -> "https://images.unsplash.com/photo-1594213114663-ddf3f2a02126?auto=format&fit=crop&w=600&q=80"
            t.contains("lamp") || t.contains("light") -> "https://images.unsplash.com/photo-1534972195531-a756b1126f25?auto=format&fit=crop&w=600&q=80"
            t.contains("trimmer") || t.contains("grooming") -> "https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&w=600&q=80"
            else -> "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=600&q=80"
        }
    }

    // 3. Grocery Section
    return when {
        t.contains("potato") || t.contains("आलू") -> "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80"
        t.contains("onion") || t.contains("प्याज़") -> "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=600&q=80"
        t.contains("tomato") || t.contains("टमाटर") -> "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80"
        t.contains("chilli") || t.contains("मिर्च") -> "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=600&q=80"
        t.contains("ginger") || t.contains("अदरक") -> "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80"
        t.contains("garlic") || t.contains("लहसुन") -> "https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?auto=format&fit=crop&w=600&q=80"
        t.contains("carrot") || t.contains("गाजर") -> "https://images.unsplash.com/photo-1598170845058-32b9d6a5c317?auto=format&fit=crop&w=600&q=80"
        t.contains("beetroot") || t.contains("चुकंदर") -> "https://images.unsplash.com/photo-1593105544559-ecb03bf76f82?auto=format&fit=crop&w=600&q=80"
        t.contains("cabbage") || t.contains("पत्ता") -> "https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=600&q=80"
        t.contains("cauliflower") || t.contains("गोभी") -> "https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&w=600&q=80"
        t.contains("cucumber") || t.contains("खीरा") -> "https://images.unsplash.com/photo-1449300079323-02e209d9d3a6?auto=format&fit=crop&w=600&q=80"
        t.contains("spinach") || t.contains("पालक") -> "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80"
        t.contains("coriander") || t.contains("धनिया") -> "https://images.unsplash.com/photo-1598030304671-5aa1d6f21128?auto=format&fit=crop&w=600&q=80"
        t.contains("lemon") || t.contains("नींबू") -> "https://images.unsplash.com/photo-1590502593747-42a996133562?auto=format&fit=crop&w=600&q=80"
        t.contains("apple") || t.contains("सेब") -> "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80"
        t.contains("banana") || t.contains("केला") -> "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80"
        t.contains("mango") || t.contains("आम") -> "https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=600&q=80"
        t.contains("orange") || t.contains("संतरा") -> "https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=600&q=80"
        t.contains("pomegranate") || t.contains("अनार") -> "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80"
        t.contains("grapes") || t.contains("अंगूर") -> "https://images.unsplash.com/photo-1537640538966-79f369143f8f?auto=format&fit=crop&w=600&q=80"
        t.contains("papaya") || t.contains("पपीता") -> "https://images.unsplash.com/photo-1517282009859-f000ec3b26fe?auto=format&fit=crop&w=600&q=80"
        t.contains("watermelon") || t.contains("तरबूज") -> "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80"
        t.contains("milk") || t.contains("दूध") -> "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80"
        t.contains("paneer") || t.contains("पनीर") -> "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80"
        t.contains("butter") || t.contains("मक्खन") -> "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&w=600&q=80"
        t.contains("ghee") || t.contains("घी") -> "https://images.unsplash.com/photo-1628088062854-d1870b4553da?auto=format&fit=crop&w=600&q=80"
        t.contains("curd") || t.contains("दही") -> "https://images.unsplash.com/photo-1571212515416-fef01fc43637?auto=format&fit=crop&w=600&q=80"
        t.contains("cheese") || t.contains("चीज़") -> "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?auto=format&fit=crop&w=600&q=80"
        t.contains("rice") || t.contains("चावल") || t.contains("basmati") -> "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"
        t.contains("atta") || t.contains("flour") || t.contains("आटा") || t.contains("wheat") -> "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80"
        t.contains("dal") || t.contains("दाल") -> "https://images.unsplash.com/photo-1585994192701-518290f6701a?auto=format&fit=crop&w=600&q=80"
        t.contains("spice") || t.contains("masala") || t.contains("हल्दी") || t.contains("मसाले") -> "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80"
        t.contains("biscuit") || t.contains("cookie") || t.contains("बिस्कुट") -> "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=600&q=80"
        t.contains("namkeen") || t.contains("chips") || t.contains("नमकीन") -> "https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=600&q=80"
        t.contains("oil") || t.contains("तेल") -> "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80"
        t.contains("tea") || t.contains("chai") || t.contains("चाय") -> "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80"
        c.contains("vegetables") -> "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80"
        c.contains("fruits") -> "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=600&q=80"
        c.contains("dairy") -> "https://images.unsplash.com/photo-1528750997573-59b89d56f4f7?auto=format&fit=crop&w=600&q=80"
        c.contains("grains") -> "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"
        c.contains("spices") -> "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80"
        c.contains("snacks") -> "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=600&q=80"
        else -> "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80"
    }
}

/**
 * Universal product image viewer supporting remote URLs, fallback images, shimmer loader, and vector canvas fallback.
 */
@Composable
fun ProductImageView(
    imageUrl: String?,
    category: String,
    title: String = "",
    section: String = "Grocery",
    imageIndex: Int = 0,
    modifier: Modifier = Modifier,
    contentDescription: String? = null
) {
    val finalUrl = if (!imageUrl.isNullOrBlank()) {
        imageUrl
    } else {
        getCuratedImageUrl(title, category, section)
    }

    SubcomposeAsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(finalUrl)
            .crossfade(true)
            .build(),
        contentDescription = contentDescription ?: title,
        contentScale = ContentScale.Crop,
        modifier = modifier.clip(RoundedCornerShape(14.dp)),
        loading = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp,
                    color = Color(0xFF1E2E5D)
                )
            }
        },
        error = {
            ProductVisualDrawing(
                index = imageIndex,
                category = category,
                modifier = Modifier.fillMaxSize()
            )
        }
    )
}

@Composable
fun ProductImageView(
    product: Product,
    modifier: Modifier = Modifier,
    contentDescription: String? = null
) {
    ProductImageView(
        imageUrl = product.imageUrl,
        category = product.category,
        title = product.title,
        section = product.section,
        imageIndex = product.imageIndex,
        modifier = modifier,
        contentDescription = contentDescription ?: product.title
    )
}
