package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ProductVisualDrawing(
    index: Int = 1,
    category: String,
    modifier: Modifier = Modifier
) {
    // Dynamic background gradient according to category
    val gradientColors = when (category) {
        "Vegetables" -> listOf(Color(0xFFE8F5E9), Color(0xFFC8E6C9))
        "Fruits" -> listOf(Color(0xFFFFF3E0), Color(0xFFFFE0B2))
        "Dairy" -> listOf(Color(0xFFE3F2FD), Color(0xFFBBDEFB))
        "Grains" -> listOf(Color(0xFFFFF8E1), Color(0xFFFFECB3))
        "Spices & Masala" -> listOf(Color(0xFFFBE9E7), Color(0xFFFFCCBC))
        "Snacks & Biscuits" -> listOf(Color(0xFFF3E5F5), Color(0xFFE1BEE7))
        else -> listOf(Color(0xFFF0F4F8), Color(0xFFE2EAF4))
    }

    val badgeBg = when (category) {
        "Vegetables" -> Color(0xFF2E7D32)
        "Fruits" -> Color(0xFFE65100)
        "Dairy" -> Color(0xFF1565C0)
        "Grains" -> Color(0xFFF57F17)
        "Spices & Masala" -> Color(0xFFD84315)
        "Snacks & Biscuits" -> Color(0xFF6A1B9A)
        else -> Color(0xFF1E2E5D)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(brush = Brush.linearGradient(colors = gradientColors)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2
            val cy = h / 2

            when (category) {
                "Vegetables" -> {
                    // Fresh Green Cabbage / Leaf Icon
                    // Leaf 1
                    val leafPath1 = Path().apply {
                        moveTo(cx - 20.dp.toPx(), cy + 15.dp.toPx())
                        cubicTo(cx - 35.dp.toPx(), cy - 15.dp.toPx(), cx, cy - 35.dp.toPx(), cx, cy - 35.dp.toPx())
                        cubicTo(cx, cy - 35.dp.toPx(), cx - 5.dp.toPx(), cy, cx - 20.dp.toPx(), cy + 15.dp.toPx())
                        close()
                    }
                    drawPath(leafPath1, Color(0xFF4CAF50))

                    // Leaf 2
                    val leafPath2 = Path().apply {
                        moveTo(cx, cy + 20.dp.toPx())
                        cubicTo(cx + 35.dp.toPx(), cy + 10.dp.toPx(), cx + 30.dp.toPx(), cy - 25.dp.toPx(), cx + 5.dp.toPx(), cy - 28.dp.toPx())
                        cubicTo(cx - 5.dp.toPx(), cy - 10.dp.toPx(), cx, cy, cx, cy + 20.dp.toPx())
                        close()
                    }
                    drawPath(leafPath2, Color(0xFF388E3C))

                    // Center fresh circle (e.g., tomato/pea bulb)
                    drawCircle(Color(0xFF81C784), 16.dp.toPx(), Offset(cx - 5.dp.toPx(), cy + 5.dp.toPx()))
                    drawCircle(Color(0xFF2E7D32), 16.dp.toPx(), Offset(cx - 5.dp.toPx(), cy + 5.dp.toPx()), style = Stroke(width = 2.dp.toPx()))
                }
                "Fruits" -> {
                    // Juicy Apple / Citrus
                    // Apple body
                    val applePath = Path().apply {
                        moveTo(cx, cy - 10.dp.toPx())
                        cubicTo(cx + 25.dp.toPx(), cy - 30.dp.toPx(), cx + 35.dp.toPx(), cy + 15.dp.toPx(), cx, cy + 30.dp.toPx())
                        cubicTo(cx - 35.dp.toPx(), cy + 15.dp.toPx(), cx - 25.dp.toPx(), cy - 30.dp.toPx(), cx, cy - 10.dp.toPx())
                        close()
                    }
                    drawPath(applePath, Color(0xFFE53935))

                    // Apple leaf & stem
                    drawLine(Color(0xFF5D4037), Offset(cx, cy - 10.dp.toPx()), Offset(cx + 4.dp.toPx(), cy - 25.dp.toPx()), strokeWidth = 3.dp.toPx())
                    val fruitLeaf = Path().apply {
                        moveTo(cx + 4.dp.toPx(), cy - 20.dp.toPx())
                        quadraticTo(cx + 18.dp.toPx(), cy - 28.dp.toPx(), cx + 16.dp.toPx(), cy - 16.dp.toPx())
                        quadraticTo(cx + 8.dp.toPx(), cy - 14.dp.toPx(), cx + 4.dp.toPx(), cy - 20.dp.toPx())
                        close()
                    }
                    drawPath(fruitLeaf, Color(0xFF43A047))
                }
                "Dairy" -> {
                    // Milk bottle / jug
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(cx - 18.dp.toPx(), cy - 10.dp.toPx()),
                        size = Size(36.dp.toPx(), 45.dp.toPx()),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                    )
                    drawRoundRect(
                        color = Color(0xFF0288D1),
                        topLeft = Offset(cx - 18.dp.toPx(), cy - 10.dp.toPx()),
                        size = Size(36.dp.toPx(), 45.dp.toPx()),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    // Neck
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(cx - 10.dp.toPx(), cy - 24.dp.toPx()),
                        size = Size(20.dp.toPx(), 16.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                    drawRoundRect(
                        color = Color(0xFF0288D1),
                        topLeft = Offset(cx - 10.dp.toPx(), cy - 24.dp.toPx()),
                        size = Size(20.dp.toPx(), 16.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    // Cap
                    drawRoundRect(
                        color = Color(0xFF0288D1),
                        topLeft = Offset(cx - 12.dp.toPx(), cy - 28.dp.toPx()),
                        size = Size(24.dp.toPx(), 6.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                    // Milk wave banner on bottle
                    drawCircle(Color(0xFF29B6F6), 8.dp.toPx(), Offset(cx, cy + 12.dp.toPx()))
                }
                "Grains" -> {
                    // Wheat sheaf / rice ear
                    drawLine(Color(0xFFD4A017), Offset(cx, cy + 30.dp.toPx()), Offset(cx, cy - 25.dp.toPx()), strokeWidth = 3.dp.toPx())
                    for (i in 0..4) {
                        val yOffset = cy - 20.dp.toPx() + (i * 9.dp.toPx())
                        // Left grain
                        drawOval(Color(0xFFF9A825), Offset(cx - 14.dp.toPx(), yOffset), Size(12.dp.toPx(), 6.dp.toPx()))
                        // Right grain
                        drawOval(Color(0xFFF9A825), Offset(cx + 2.dp.toPx(), yOffset - 3.dp.toPx()), Size(12.dp.toPx(), 6.dp.toPx()))
                    }
                }
                "Spices & Masala" -> {
                    // Spice Mortar & Bowl
                    val bowlPath = Path().apply {
                        moveTo(cx - 24.dp.toPx(), cy - 5.dp.toPx())
                        lineTo(cx + 24.dp.toPx(), cy - 5.dp.toPx())
                        cubicTo(cx + 20.dp.toPx(), cy + 25.dp.toPx(), cx - 20.dp.toPx(), cy + 25.dp.toPx(), cx - 24.dp.toPx(), cy - 5.dp.toPx())
                        close()
                    }
                    drawPath(bowlPath, Color(0xFFBF360C))

                    // Base
                    drawRoundRect(
                        color = Color(0xFF870000),
                        topLeft = Offset(cx - 12.dp.toPx(), cy + 22.dp.toPx()),
                        size = Size(24.dp.toPx(), 5.dp.toPx()),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )

                    // Spices mound inside
                    drawArc(
                        color = Color(0xFFFFB300),
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = true,
                        topLeft = Offset(cx - 20.dp.toPx(), cy - 16.dp.toPx()),
                        size = Size(40.dp.toPx(), 22.dp.toPx())
                    )

                    // Cinnamon / Chilli sticking out
                    drawLine(Color(0xFFD50000), Offset(cx + 6.dp.toPx(), cy - 8.dp.toPx()), Offset(cx + 18.dp.toPx(), cy - 26.dp.toPx()), strokeWidth = 4.dp.toPx())
                }
                "Snacks & Biscuits" -> {
                    // Crisp Biscuit / Cookie
                    drawCircle(Color(0xFFD7A15C), 26.dp.toPx(), Offset(cx, cy))
                    drawCircle(Color(0xFFB07A3B), 26.dp.toPx(), Offset(cx, cy), style = Stroke(width = 2.dp.toPx()))

                    // Biscuit holes / choc chips
                    val dots = listOf(
                        Offset(cx - 12.dp.toPx(), cy - 10.dp.toPx()),
                        Offset(cx, cy - 14.dp.toPx()),
                        Offset(cx + 12.dp.toPx(), cy - 10.dp.toPx()),
                        Offset(cx - 8.dp.toPx(), cy),
                        Offset(cx + 8.dp.toPx(), cy),
                        Offset(cx - 12.dp.toPx(), cy + 10.dp.toPx()),
                        Offset(cx, cy + 14.dp.toPx()),
                        Offset(cx + 12.dp.toPx(), cy + 10.dp.toPx())
                    )
                    dots.forEach { dot ->
                        drawCircle(Color(0xFF8D5524), 2.5.dp.toPx(), dot)
                    }
                }
                else -> {
                    // Grocery bag fallback
                    drawRoundRect(
                        color = Color(0xFF2E7D32),
                        topLeft = Offset(cx - 20.dp.toPx(), cy - 15.dp.toPx()),
                        size = Size(40.dp.toPx(), 45.dp.toPx()),
                        cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx())
                    )
                    val handle = Path().apply {
                        moveTo(cx - 10.dp.toPx(), cy - 15.dp.toPx())
                        quadraticTo(cx, cy - 30.dp.toPx(), cx + 10.dp.toPx(), cy - 15.dp.toPx())
                    }
                    drawPath(handle, Color(0xFF2E7D32), style = Stroke(width = 3.dp.toPx()))
                }
            }
        }

        // Mini Category Label Tag overlay at top corner
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
                .background(badgeBg, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = category.uppercase(),
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
