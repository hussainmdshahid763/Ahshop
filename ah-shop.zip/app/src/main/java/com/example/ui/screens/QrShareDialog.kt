package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.util.QrCodeGenerator
import com.example.util.QrCodePreferences
import com.example.util.StoreConstants

@Composable
fun QrShareDialog(
    initialUrl: String? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var appUrl by remember { mutableStateOf(initialUrl ?: QrCodePreferences.getSavedUrl(context)) }
    var isEditingUrl by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf(0) } // 0 = Clean QR, 1 = Printable Shop Poster

    // Generate QR Bitmap
    val qrBitmap = remember(appUrl) {
        QrCodeGenerator.generateQrBitmap(content = appUrl, width = 600, height = 600)
    }

    // Generate Poster Bitmap
    val posterBitmap = remember(appUrl, qrBitmap) {
        if (qrBitmap != null) {
            QrCodeGenerator.generatePrintablePoster(appUrl = appUrl, qrBitmap = qrBitmap)
        } else null
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, Color(0xFFCBD5E1)),
            elevation = CardDefaults.cardElevation(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A)) // DeepNavyBlack
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.QrCode2,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "AH SHOP App QR Code",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "ग्राहकों को ऐप शेयर व प्रिंट करने का QR कोड",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .size(32.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                // Mode Selector Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedMode == 0,
                        onClick = { selectedMode = 0 },
                        label = {
                            Text(
                                "📱 Direct QR Code",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0F172A),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFFF1F5F9),
                            labelColor = Color(0xFF0F172A)
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = selectedMode == 1,
                        onClick = { selectedMode = 1 },
                        label = {
                            Text(
                                "🖨️ Printable Shop Poster",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0F172A),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFFF1F5F9),
                            labelColor = Color(0xFF0F172A)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // QR Type Presets (App Download, WhatsApp, UPI)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Text(
                        "QR Code Target (स्कैन करने पर क्या खुले?):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val isAppDownload = appUrl == StoreConstants.APP_DOWNLOAD_URL
                        val isWhatsApp = appUrl.startsWith("https://wa.me")
                        val isUpi = appUrl.startsWith("upi://")

                        SuggestionChip(
                            onClick = { appUrl = StoreConstants.APP_DOWNLOAD_URL },
                            label = { Text("📲 App Download", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isAppDownload) Color(0xFFEDE9FE) else Color(0xFFF1F5F9),
                                labelColor = if (isAppDownload) Color(0xFF6366F1) else Color(0xFF334155)
                            ),
                            border = BorderStroke(1.dp, if (isAppDownload) Color(0xFF818CF8) else Color.Transparent)
                        )

                        SuggestionChip(
                            onClick = { appUrl = QrCodeGenerator.DEFAULT_WHATSAPP_URL },
                            label = { Text("💬 WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isWhatsApp) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
                                labelColor = if (isWhatsApp) Color(0xFF15803D) else Color(0xFF334155)
                            ),
                            border = BorderStroke(1.dp, if (isWhatsApp) Color(0xFF22C55E) else Color.Transparent)
                        )

                        SuggestionChip(
                            onClick = { appUrl = QrCodeGenerator.DEFAULT_UPI_URL },
                            label = { Text("💳 UPI Pay (9470026573@ybl)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isUpi) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                labelColor = if (isUpi) Color(0xFF1D4ED8) else Color(0xFF334155)
                            ),
                            border = BorderStroke(1.dp, if (isUpi) Color(0xFF3B82F6) else Color.Transparent)
                        )

                        SuggestionChip(
                            onClick = { isEditingUrl = true },
                            label = { Text("✏️ Custom Link", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (!isAppDownload && !isWhatsApp && !isUpi) Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
                                labelColor = if (!isAppDownload && !isWhatsApp && !isUpi) Color(0xFFB45309) else Color(0xFF334155)
                            ),
                            border = BorderStroke(1.dp, if (!isAppDownload && !isWhatsApp && !isUpi) Color(0xFFF59E0B) else Color.Transparent)
                        )
                    }
                }

                // Visual QR / Poster Display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedMode == 0) {
                        // Direct QR View
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(2.dp, Color(0xFF0F172A)),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.padding(8.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Text(
                                    "AH SHOP GROCERY",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    "Scan with any Camera / Google Lens",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                if (qrBitmap != null) {
                                    Image(
                                        bitmap = qrBitmap.asImageBitmap(),
                                        contentDescription = "AH SHOP Download QR Code",
                                        modifier = Modifier
                                            .size(230.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(230.dp)
                                            .background(Color(0xFFF1F5F9)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Generating QR...", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                val isWhatsApp = appUrl.startsWith("https://wa.me")
                                val isUpi = appUrl.startsWith("upi://")
                                Text(
                                    text = when {
                                        isWhatsApp -> "📱 स्कैन करते ही WhatsApp चैट शुरू होगी"
                                        isUpi -> "💳 PhonePe / GPay / Paytm से सीधे पेमेंट करें"
                                        else -> "ताज़ा राशन घर बैठे मंगवाएं"
                                    },
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = when {
                                        isWhatsApp -> Color(0xFF15803D)
                                        isUpi -> Color(0xFF1D4ED8)
                                        else -> Color(0xFF15803D)
                                    }
                                )
                            }
                        }
                    } else {
                        // Poster Preview
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(2.dp, Color(0xFF0F172A)),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.padding(8.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Text(
                                    "🏪 Store Counter Poster Preview",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    "Ready to print on paper or banner (A4/A5)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                if (posterBitmap != null) {
                                    Image(
                                        bitmap = posterBitmap.asImageBitmap(),
                                        contentDescription = "Printable Store Poster",
                                        modifier = Modifier
                                            .width(220.dp)
                                            .height(290.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .border(1.dp, Color(0xFFCBD5E1))
                                    )
                                }
                            }
                        }
                    }
                }

                // URL Details & Edit Section
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Linked App / Download URL:",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = Color(0xFF0F172A)
                            )

                            TextButton(
                                onClick = {
                                    if (isEditingUrl) {
                                        QrCodePreferences.saveUrl(context, appUrl)
                                        Toast.makeText(context, "URL saved successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                    isEditingUrl = !isEditingUrl
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(
                                    if (isEditingUrl) Icons.Default.Check else Icons.Default.Edit,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    if (isEditingUrl) "Save & Done" else "Change Link",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color(0xFF0F172A)
                                )
                            }
                        }

                        if (isEditingUrl) {
                            OutlinedTextField(
                                value = appUrl,
                                onValueChange = {
                                    appUrl = it
                                    QrCodePreferences.saveUrl(context, it)
                                },
                                placeholder = { Text("https://your-apk-link.com") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "💡 अपना APK गूगल ड्राइव, मीडियाफायर या वेबसाइट का लिंक यहाँ पेस्ट करें। क्यूआर कोड तुरंत अपडेट हो जाएगा।",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White, RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = appUrl,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF334155),
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(appUrl)).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Cannot open URL: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.OpenInBrowser, contentDescription = "Test Link", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("AH SHOP URL", appUrl))
                                            Toast.makeText(context, "Link copied to clipboard!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Link", tint = Color(0xFF0F172A), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // Sharing & Print Actions
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // WhatsApp & General Share Button
                    Button(
                        onClick = {
                            val targetBitmap = if (selectedMode == 1 && posterBitmap != null) posterBitmap else qrBitmap
                            if (targetBitmap != null) {
                                QrCodeGenerator.shareQrImage(
                                    context = context,
                                    bitmap = targetBitmap,
                                    appUrl = appUrl,
                                    isPoster = (selectedMode == 1)
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)), // Forest Green
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_share_qr_whatsapp_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedMode == 1) "Share Store Poster on WhatsApp" else "Share QR Code with Customers",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }

                    // Save / Download for Printing Button
                    OutlinedButton(
                        onClick = {
                            val targetBitmap = if (selectedMode == 1 && posterBitmap != null) posterBitmap else qrBitmap
                            if (targetBitmap != null) {
                                val fileName = if (selectedMode == 1) "AH_SHOP_Print_Poster_${System.currentTimeMillis()}" else "AH_SHOP_QR_Code_${System.currentTimeMillis()}"
                                QrCodeGenerator.saveImageToGallery(context, targetBitmap, fileName)
                            }
                        },
                        border = BorderStroke(2.dp, Color(0xFF0F172A)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_save_qr_print_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color(0xFF0F172A))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Save for Printing (दुकान पर्चा प्रिंट करें)",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
