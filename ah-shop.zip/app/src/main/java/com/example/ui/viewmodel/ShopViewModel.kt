package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ChatMessage
import com.example.data.api.GeminiApiClient
import com.example.data.api.VeoGenerationResult
import com.example.data.local.CartItemEntity
import com.example.data.local.DeviceOrderPreferences
import com.example.data.local.FavoriteEntity
import com.example.data.local.OfferPreferences
import com.example.data.local.OrderEntity
import com.example.data.local.StoreOffer
import com.example.data.local.UserProfileEntity
import com.example.data.model.Product
import com.example.data.model.ProductReview
import com.example.data.repository.GroceryCatalog
import com.example.data.repository.FoodCatalog
import com.example.data.repository.EcommerceCatalog
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

sealed class Screen {
    object Main : Screen()
    data class ProductDetail(val productId: String) : Screen()
    object Cart : Screen()
    object Favorites : Screen()
    object Checkout : Screen()
    object Orders : Screen()
    object Profile : Screen()
    object AiHub : Screen()
    data class OrderSuccess(
        val orderNumber: String,
        val totalAmount: Double,
        val itemsSummary: String,
        val paymentMethod: String = "Cash on Delivery"
    ) : Screen()

    // Admin Screens
    object AdminLogin : Screen()
    object AdminDashboard : Screen()
}

enum class SortBy {
    RECOMMENDED, PRICE_LOW_HIGH, PRICE_HIGH_LOW, RATING
}

data class Voucher(
    val code: String,
    val description: String,
    val applyDiscount: (subtotal: Double) -> Double,
    val discountText: String
)

class ShopViewModel(private val repository: ShopRepository) : ViewModel() {

    // --- Navigation Stack ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Main)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()
    private val backStack = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        backStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeAt(backStack.size - 1)
            return true
        }
        return false
    }

    // --- Search & Filtering States ---
    val searchQuery = MutableStateFlow("")
    val selectedSection = MutableStateFlow("Grocery") // "Grocery", "Food", "E-Commerce", "All"
    val selectedCategory = MutableStateFlow("All")
    val sortBy = MutableStateFlow(SortBy.RECOMMENDED)
    val priceRange = MutableStateFlow(0f..5000f)

    fun selectSection(section: String) {
        selectedSection.value = section
        selectedCategory.value = "All"
    }

    // Reactive streams from Repository
    val cartItems: StateFlow<List<CartItemEntity>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<FavoriteEntity>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tracks orders placed on THIS device and filters personal orders from the central sync
    val myDeviceOrderIds = MutableStateFlow<Set<String>>(DeviceOrderPreferences.getPlacedOrders())

    val profile: StateFlow<UserProfileEntity?> = repository.profile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Customer-only orders: only orders placed from this mobile device or matching user's mobile number
    val myOrders: StateFlow<List<OrderEntity>> = combine(
        orders,
        profile,
        myDeviceOrderIds
    ) { allStoreOrders, userProfile, localDeviceOrders ->
        val userPhone = userProfile?.phone?.filter { it.isDigit() } ?: ""
        allStoreOrders.filter { order ->
            val orderPhone = order.customerPhone.filter { it.isDigit() }
            localDeviceOrders.contains(order.orderNumber) ||
            (userPhone.length >= 10 && orderPhone.isNotEmpty() && orderPhone.endsWith(userPhone.takeLast(10)))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dynamic catalog of all products
    val allProducts: StateFlow<List<Product>> = repository.products
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GroceryCatalog.items + FoodCatalog.items + EcommerceCatalog.items)

    // Filtered Products Stream
    val filteredProducts: StateFlow<List<Product>> = combine(
        allProducts,
        searchQuery,
        selectedSection,
        selectedCategory,
        combine(sortBy, priceRange) { s, r -> Pair(s, r) }
    ) { productsList: List<Product>, query: String, section: String, category: String, sortAndRange: Pair<SortBy, ClosedFloatingPointRange<Float>> ->
        val (sort, range) = sortAndRange
        var list = productsList

        // Apply section filter
        if (section != "All") {
            list = list.filter {
                it.section.equals(section, ignoreCase = true) ||
                    (section == "Grocery" && (it.section.isBlank() || it.section.equals("kirana", ignoreCase = true)))
            }
        }

        // Apply category filter
        if (category != "All") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }

        // Apply textual search match (matches English name, Hindi name, subcategory, description)
        if (query.isNotBlank()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.hindiName.contains(query, ignoreCase = true) ||
                        it.subcategory.contains(query, ignoreCase = true) ||
                        it.description.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true)
            }
        }

        // Apply price constraints
        list = list.filter { it.price >= range.start && it.price <= range.endInclusive }

        // Apply sorting preference
        when (sort) {
            SortBy.RECOMMENDED -> list
            SortBy.PRICE_LOW_HIGH -> list.sortedBy { it.price }
            SortBy.PRICE_HIGH_LOW -> list.sortedByDescending { it.price }
            SortBy.RATING -> list.sortedByDescending { it.rating }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GroceryCatalog.items + FoodCatalog.items + EcommerceCatalog.items)

    // Active voucher
    val activeVoucher = MutableStateFlow<Voucher?>(null)
    val voucherError = MutableStateFlow<String?>(null)

    // Admin manageable Special Grocery Offer & Banner
    val storeOffer = MutableStateFlow<StoreOffer>(OfferPreferences.getOffer())

    fun updateStoreOffer(newOffer: StoreOffer) {
        OfferPreferences.saveOffer(newOffer)
        storeOffer.value = newOffer
        // If current active voucher matches the old coupon, re-evaluate or clear
        if (activeVoucher.value?.code == newOffer.couponCode.uppercase() && !newOffer.isEnabled) {
            removeVoucher()
        }
    }

    // Preloaded available voucher lists
    val availableVouchers = listOf(
        Voucher("AHSHOP10", "10% Off Grocery (No Minimum)", { sub -> sub * 0.10 }, "10% Off"),
        Voucher("SHIPFREE", "Free Delivery (₹40 value)", { _ -> 0.0 }, "Free Delivery")
    )

    // --- Admin Authentication & Controls ---
    val isAdminLoggedIn = MutableStateFlow(false)
    val adminLoginError = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repository.ensureProductsSeeded()
            repository.ensureDefaultProfile()

            // Purge all initial test orders as requested by user
            if (!DeviceOrderPreferences.hasPurgedTestOrders()) {
                try {
                    repository.clearAllOrders()
                    DeviceOrderPreferences.clearAll()
                    DeviceOrderPreferences.markPurged()
                    myDeviceOrderIds.value = emptySet()
                    Log.d("ShopViewModel", "Purged all initial test orders successfully.")
                } catch (e: Exception) {
                    Log.e("ShopViewModel", "Error purging test orders", e)
                }
            }

            // Immediate cloud sync on startup
            try {
                repository.syncOrdersFromCloud()
            } catch (e: Exception) {
                Log.e("ShopViewModel", "Startup sync error", e)
            }
        }

        // Periodic cloud sync every 8 seconds so Admin and Customer phones are always up-to-date
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(8000)
                try {
                    repository.syncOrdersFromCloud()
                } catch (e: Exception) {
                    // Silent background retry
                }
            }
        }
    }

    fun clearAllOrders(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.clearAllOrders()
            DeviceOrderPreferences.clearAll()
            myDeviceOrderIds.value = emptySet()
            onComplete()
        }
    }

    // --- Admin Login & Logout ---
    fun loginAdmin(username: String, pin: String): Boolean {
        val u = username.trim().lowercase()
        val p = pin.trim()
        if (u == "hussainmdshahid763@gmail.com" && p == "wH0192014et!V") {
            isAdminLoggedIn.value = true
            adminLoginError.value = null
            syncOrdersFromCloud() // Immediately synchronize orders on admin entry
            navigateTo(Screen.AdminDashboard)
            return true
        } else {
            adminLoginError.value = "गलत ईमेल या पासवर्ड! केवल अधिकृत एडमिन ही लॉगिन कर सकते हैं।"
            return false
        }
    }

    fun logoutAdmin() {
        isAdminLoggedIn.value = false
        navigateTo(Screen.Main)
    }

    // --- Admin Product Listing Management (Add, Edit, Delete) ---
    fun adminAddProduct(
        title: String,
        hindiName: String,
        price: Double,
        originalPrice: Double,
        unit: String,
        category: String,
        subcategory: String,
        description: String,
        imageUrl: String = "",
        section: String = "Grocery"
    ) {
        viewModelScope.launch {
            val newId = "prod_${System.currentTimeMillis()}"
            val newProduct = Product(
                id = newId,
                title = title.trim(),
                hindiName = hindiName.trim(),
                price = price,
                originalPrice = if (originalPrice > 0) originalPrice else price,
                unit = unit.trim().ifBlank { "1 KG" },
                category = category.trim().ifBlank { "Vegetables" },
                subcategory = subcategory.trim().ifBlank { title.trim() },
                description = description.trim(),
                rating = 4.8,
                reviewsCount = 1,
                isFeatured = true,
                isNewArrival = true,
                imageUrl = imageUrl.trim(),
                section = section.trim().ifBlank { "Grocery" }
            )
            repository.addProduct(newProduct)
        }
    }

    fun adminUpdateProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun adminDeleteProduct(productId: String) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
        }
    }

    // --- Admin Order Management (Status Update & Deletion) ---
    fun adminUpdateOrderStatus(orderId: Int, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
        }
    }

    fun adminDeleteOrder(orderId: Int) {
        viewModelScope.launch {
            repository.deleteOrder(orderId)
        }
    }

    // --- Operations ---

    fun applyVoucherCode(code: String) {
        val uppercaseCode = code.trim().uppercase()
        val currentOffer = storeOffer.value
        val dynamicOfferVoucher = if (currentOffer.isEnabled && uppercaseCode == currentOffer.couponCode.trim().uppercase()) {
            Voucher(
                code = currentOffer.couponCode.trim().uppercase(),
                description = "₹${currentOffer.discountAmount.toInt()} Flat Off (Min Spend ₹${currentOffer.minSpend.toInt()})",
                applyDiscount = { sub -> if (sub >= currentOffer.minSpend) currentOffer.discountAmount else 0.0 },
                discountText = "₹${currentOffer.discountAmount.toInt()} Flat"
            )
        } else null

        val found = dynamicOfferVoucher ?: availableVouchers.find { it.code == uppercaseCode }
        if (found != null) {
            activeVoucher.value = found
            voucherError.value = null
        } else {
            voucherError.value = "Invalid or expired coupon code"
            activeVoucher.value = null
        }
    }

    fun removeVoucher() {
        activeVoucher.value = null
        voucherError.value = null
    }

    fun addToCart(product: Product, size: String, color: String, qty: Int = 1) {
        viewModelScope.launch {
            val existing = cartItems.value.find {
                it.productId == product.id && it.selectedSize == size && it.selectedColor == color
            }

            if (existing != null) {
                repository.addToCart(existing.copy(quantity = existing.quantity + qty))
            } else {
                repository.addToCart(
                    CartItemEntity(
                        productId = product.id,
                        title = product.title,
                        price = product.price,
                        originalPrice = product.originalPrice,
                        category = product.category,
                        imageIndex = product.imageIndex,
                        selectedSize = size,
                        selectedColor = color,
                        quantity = qty,
                        imageUrl = product.imageUrl,
                        section = product.section
                    )
                )
            }
        }
    }

    fun updateCartQty(item: CartItemEntity, isAddition: Boolean) {
        viewModelScope.launch {
            val newQty = if (isAddition) item.quantity + 1 else item.quantity - 1
            repository.updateCartQuantity(item.copy(quantity = newQty))
        }
    }

    fun removeFromCart(item: CartItemEntity) {
        viewModelScope.launch {
            repository.removeFromCart(item)
        }
    }

    fun removeFromCartById(productId: String) {
        viewModelScope.launch {
            repository.removeFromCartById(productId)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    /**
     * Quick add single product to cart directly from home/catalog cards
     */
    fun addOneToCart(product: Product) {
        val defaultSize = product.sizes.firstOrNull() ?: product.unit
        val defaultColor = product.colors.firstOrNull() ?: "Default"
        addToCart(product, defaultSize, defaultColor, 1)
    }

    /**
     * Decrement product count from cart or remove if 0
     */
    fun removeOneFromCart(product: Product) {
        val existing = cartItems.value.find { it.productId == product.id }
        if (existing != null) {
            if (existing.quantity <= 1) {
                removeFromCart(existing)
            } else {
                updateCartQty(existing, false)
            }
        }
    }

    fun toggleFavorite(productId: String) {
        viewModelScope.launch {
            val isFav = favorites.value.any { it.productId == productId }
            repository.toggleFavorite(productId, isFav)
        }
    }

    fun getProductById(id: String): Product? {
        return allProducts.value.find { it.id == id } ?: GroceryCatalog.items.find { it.id == id }
    }

    fun getProductReviews(productId: String): List<ProductReview> {
        return repository.getProductReviews(productId)
    }

    // --- Cloud Orders Synchronization (Multi-Device Sync) ---
    val isSyncingOrders = MutableStateFlow(false)
    val syncStatusMessage = MutableStateFlow<String?>(null)

    fun syncOrdersFromCloud() {
        viewModelScope.launch {
            isSyncingOrders.value = true
            try {
                val count = repository.syncOrdersFromCloud()
                syncStatusMessage.value = if (count > 0) "$count new orders synced" else "Orders are up-to-date"
            } catch (e: Exception) {
                Log.e("ShopViewModel", "Cloud sync failed", e)
                syncStatusMessage.value = "Sync failed"
            } finally {
                isSyncingOrders.value = false
            }
        }
    }

    // Checkout execution with customer-entered details and Cash on Delivery
    fun executeCheckout(
        customerName: String,
        customerPhone: String,
        customerAddress: String,
        paymentMethod: String = "Cash on Delivery"
    ): Boolean {
        val trimmedName = customerName.trim()
        val trimmedPhone = customerPhone.trim()
        val trimmedAddress = customerAddress.trim()

        if (trimmedName.isBlank() || trimmedPhone.isBlank() || trimmedAddress.isBlank()) {
            return false
        }

        viewModelScope.launch {
            val items = cartItems.value
            if (items.isEmpty()) return@launch

            val subtotal = items.sumOf { it.price * it.quantity }
            val discount = activeVoucher.value?.applyDiscount?.invoke(subtotal) ?: 0.0
            val shipping = if (activeVoucher.value?.code == "SHIPFREE" || subtotal >= 499.0) 0.0 else 40.0
            val tax = 0.0
            val total = (subtotal - discount + shipping).coerceAtLeast(0.0)

            // Save entered details into customer's local profile
            val currentProfile = profile.value
            val updatedProfile = UserProfileEntity(
                name = trimmedName,
                email = currentProfile?.email ?: "",
                phone = trimmedPhone,
                addressLine = trimmedAddress,
                city = currentProfile?.city?.ifBlank { "Kolkata" } ?: "Kolkata",
                state = currentProfile?.state?.ifBlank { "West Bengal" } ?: "West Bengal",
                postalCode = currentProfile?.postalCode?.ifBlank { "700024" } ?: "700024"
            )
            repository.saveProfile(updatedProfile)

            val randNum = Random.nextInt(100000, 999999)
            val orderNo = "AH-${randNum}"
            val itemsSummary = items.joinToString { "${it.title} (${it.quantity}x)" }

            repository.placeOrder(
                orderNumber = orderNo,
                totalAmount = total,
                itemsCount = items.fold(0) { sum, i -> sum + i.quantity },
                summary = itemsSummary,
                customerName = trimmedName,
                customerPhone = trimmedPhone,
                customerAddress = trimmedAddress,
                paymentMethod = paymentMethod
            )

            // Record order on this local device so it appears in this device's My Orders
            DeviceOrderPreferences.addPlacedOrder(orderNo)
            myDeviceOrderIds.value = DeviceOrderPreferences.getPlacedOrders()

            removeVoucher()
            navigateTo(Screen.OrderSuccess(orderNo, total, itemsSummary, paymentMethod))
        }
        return true
    }

    // Save customer delivery profile
    fun updateProfile(name: String, email: String, phone: String, address: String, city: String, state: String, code: String) {
        viewModelScope.launch {
            val updated = UserProfileEntity(
                name = name,
                email = email,
                phone = phone,
                addressLine = address,
                city = city,
                state = state,
                postalCode = code
            )
            repository.saveProfile(updated)
        }
    }

    // --- GEMINI & VEO AI STUDIO INTEGRATION ---
    val chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                role = "model",
                text = "नमस्ते! मैं AH SHOP का AI असिस्टेंट हूँ। आप मुझसे किसी भी राशन, ताज़ा सब्ज़ी, रेसिपी (जैसे कोलकाता बिरयानी, दाल तड़का), या गार्डन रीच डिलीवरी के बारे में पूछ सकते हैं!"
            )
        )
    )
    val selectedChatModel = MutableStateFlow("gemini-3.5-flash-lite")
    val searchGrounding = MutableStateFlow(false)
    val mapsGrounding = MutableStateFlow(false)
    val isChatLoading = MutableStateFlow(false)
    val chatError = MutableStateFlow<String?>(null)

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage(role = "user", text = text)
        chatMessages.value = chatMessages.value + userMsg
        isChatLoading.value = true
        chatError.value = null

        viewModelScope.launch {
            val result = GeminiApiClient.generateChat(
                history = chatMessages.value.dropLast(1),
                userMessage = text,
                model = selectedChatModel.value,
                enableGoogleSearch = searchGrounding.value,
                enableGoogleMaps = mapsGrounding.value
            )
            isChatLoading.value = false
            result.onSuccess { replyMsg ->
                chatMessages.value = chatMessages.value + replyMsg
            }.onFailure { err ->
                chatError.value = err.message ?: "Failed to get response"
                chatMessages.value = chatMessages.value + ChatMessage(
                    role = "model",
                    text = "माफ़ी चाहता हूँ, कुछ तकनीकी कारण से उत्तर नहीं मिल पाया। कृपया पुनः प्रयास करें। (Error: ${err.message})"
                )
            }
        }
    }

    fun clearChat() {
        chatMessages.value = listOf(
            ChatMessage(
                role = "model",
                text = "चैट रीसेट हो गई है। आप नया सवाल पूछ सकते हैं!"
            )
        )
    }

    // Image Studio State (gemini-3.1-flash-image-preview)
    val imageStudioResult = MutableStateFlow<Bitmap?>(null)
    val isImageGenerating = MutableStateFlow(false)
    val imageError = MutableStateFlow<String?>(null)

    fun generateOrEditImage(prompt: String, inputBitmap: Bitmap?, aspectRatio: String = "1:1") {
        if (prompt.isBlank()) return
        isImageGenerating.value = true
        imageError.value = null

        viewModelScope.launch {
            val result = GeminiApiClient.generateOrEditImage(
                prompt = prompt,
                inputBitmap = inputBitmap,
                aspectRatio = aspectRatio
            )
            isImageGenerating.value = false
            result.onSuccess { bitmap ->
                imageStudioResult.value = bitmap
            }.onFailure { err ->
                imageError.value = err.message ?: "Failed to generate image"
            }
        }
    }

    // Veo Video Studio State (veo-3.1-fast-generate-preview)
    val veoStudioResult = MutableStateFlow<VeoGenerationResult?>(null)
    val isVeoGenerating = MutableStateFlow(false)
    val veoError = MutableStateFlow<String?>(null)

    fun generateVeoVideo(prompt: String, inputBitmap: Bitmap?, aspectRatio: String = "16:9") {
        if (prompt.isBlank()) return
        isVeoGenerating.value = true
        veoError.value = null

        viewModelScope.launch {
            val result = GeminiApiClient.generateVeoVideo(
                prompt = prompt,
                inputBitmap = inputBitmap,
                aspectRatio = aspectRatio
            )
            isVeoGenerating.value = false
            result.onSuccess { res ->
                veoStudioResult.value = res
            }.onFailure { err ->
                veoError.value = err.message ?: "Veo video generation failed"
            }
        }
    }

    // Live Voice State (gemini-3.1-flash-live-preview)
    val liveVoiceTranscript = MutableStateFlow("")
    val liveVoiceResponse = MutableStateFlow("")
    val isLiveVoiceLoading = MutableStateFlow(false)

    fun sendLiveVoiceQuery(prompt: String, onSpokenResult: (String) -> Unit) {
        if (prompt.isBlank()) return
        liveVoiceTranscript.value = prompt
        isLiveVoiceLoading.value = true

        viewModelScope.launch {
            val result = GeminiApiClient.liveVoiceQuery(prompt)
            isLiveVoiceLoading.value = false
            result.onSuccess { reply ->
                liveVoiceResponse.value = reply
                onSpokenResult(reply)
            }.onFailure { err ->
                val fallback = "I could not process the voice query right now. Please try again."
                liveVoiceResponse.value = fallback
                onSpokenResult(fallback)
            }
        }
    }
}
