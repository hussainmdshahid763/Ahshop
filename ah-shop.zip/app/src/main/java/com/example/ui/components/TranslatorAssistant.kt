package com.example.ui.components

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.StoreConstants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

data class TransLang(
    val code: String,
    val name: String,
    val nativeName: String,
    val flag: String
)

val SOURCE_LANGUAGES = listOf(
    TransLang("auto", "Auto Detect", "स्वचालित / Auto", "🌐"),
    TransLang("en", "English", "English", "🇬🇧"),
    TransLang("hi", "Hindi", "हिन्दी", "🇮🇳"),
    TransLang("ur", "Urdu", "اردو", "🇵🇰"),
    TransLang("bn", "Bengali", "বাংলা", "🇧🇩"),
    TransLang("ar", "Arabic", "العربية", "🇸🇦"),
    TransLang("fa", "Persian", "فارسی", "🇮🇷"),
    TransLang("zh", "Chinese", "中文", "🇨🇳"),
    TransLang("de", "German", "Deutsch", "🇩🇪"),
    TransLang("fr", "French", "Français", "🇫🇷"),
    TransLang("es", "Spanish", "Español", "🇪🇸"),
    TransLang("ru", "Russian", "Русский", "🇷🇺"),
    TransLang("ja", "Japanese", "日本語", "🇯🇵"),
    TransLang("tr", "Turkish", "Türkçe", "🇹🇷")
)

val TARGET_LANGUAGES = listOf(
    TransLang("hi", "Hindi", "हिन्दी", "🇮🇳"),
    TransLang("en", "English", "English", "🇬🇧"),
    TransLang("ur", "Urdu", "اردو", "🇵🇰"),
    TransLang("bn", "Bengali", "বাংলা", "🇧🇩"),
    TransLang("ar", "Arabic", "العربية", "🇸🇦"),
    TransLang("fa", "Persian", "فارسی", "🇮🇷"),
    TransLang("zh", "Chinese", "中文", "🇨🇳"),
    TransLang("de", "German", "Deutsch", "🇩🇪"),
    TransLang("fr", "French", "Français", "🇫🇷"),
    TransLang("es", "Spanish", "Español", "🇪🇸"),
    TransLang("ru", "Russian", "Русский", "🇷🇺"),
    TransLang("ja", "Japanese", "日本語", "🇯🇵"),
    TransLang("tr", "Turkish", "Türkçe", "🇹🇷")
)

/**
 * Real-Time Dynamic Translation Engine for single words and long sentences.
 * Connects to live translation endpoints with comprehensive fallback.
 */
object TranslationEngine {

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .build()
    }

    // Comprehensive offline dictionary for common words and queries
    private val vocabDictionary = mapOf(
        "work" to mapOf("hi" to "काम / कार्य / नौकरी", "en" to "Work / Job", "ur" to "کام / نوکری", "bn" to "কাজ / চাকরি", "ar" to "عمل / شغل", "fa" to "کار", "zh" to "工作", "de" to "Arbeit", "fr" to "Travail", "es" to "Trabajo"),
        "job" to mapOf("hi" to "नौकरी / रोज़गार", "en" to "Job", "ur" to "ملازمت / نوکری", "bn" to "চাকরি", "ar" to "وظيفة", "fa" to "شغل", "zh" to "职业", "de" to "Beruf", "fr" to "Emploi", "es" to "Empleo"),
        "shop" to mapOf("hi" to "दुकान", "en" to "Shop / Store", "ur" to "دکان", "bn" to "দোকান", "ar" to "متجر / دكان", "fa" to "فروشگاه", "zh" to "商店", "de" to "Geschäft", "fr" to "Magasin", "es" to "Tienda"),
        "price" to mapOf("hi" to "कीमत / दाम / रेट", "en" to "Price / Cost", "ur" to "قیمت / نرخ", "bn" to "দাম / মূল্য", "ar" to "السعر", "fa" to "قیمت", "zh" to "价格", "de" to "Preis", "fr" to "Prix", "es" to "Precio"),
        "money" to mapOf("hi" to "रुपये / पैसा", "en" to "Money / Cash", "ur" to "پیسہ / رقم", "bn" to "টাকা / অর্থ", "ar" to "المال", "fa" to "پول", "zh" to "钱", "de" to "Geld", "fr" to "Argent", "es" to "Dinero"),
        "delivery" to mapOf("hi" to "डिलीवरी / घर पहुँचाना", "en" to "Delivery", "ur" to "ڈیلیوری / ترسیل", "bn" to "ডেলিভারি", "ar" to "توصيل", "fa" to "تحویل", "zh" to "送货 / 配送", "de" to "Lieferung", "fr" to "Livraison", "es" to "Entrega"),
        "discount" to mapOf("hi" to "छूट / डिस्काउंट", "en" to "Discount / Offer", "ur" to "رعایت / چھوٹ", "bn" to "ছাড় / ডিসকাউন্ট", "ar" to "خصم", "fa" to "تخفیف", "zh" to "折扣", "de" to "Rabatt", "fr" to "Réduction", "es" to "Descuento"),
        "order" to mapOf("hi" to "ऑर्डर / आदेश", "en" to "Order", "ur" to "آرڈر / فرمائش", "bn" to "অর্ডার", "ar" to "طلب", "fa" to "سفارش", "zh" to "订单", "de" to "Bestellung", "fr" to "Commande", "es" to "Pedido"),
        "address" to mapOf("hi" to "पता / मकान नंबर", "en" to "Address / Location", "ur" to "پتہ", "bn" to "ঠিকানা", "ar" to "العنوان", "fa" to "نشانی / آدرس", "zh" to "地址", "de" to "Adresse", "fr" to "Adresse", "es" to "Dirección"),
        "payment" to mapOf("hi" to "भुगतान / पेमेंट", "en" to "Payment", "ur" to "ادائیگی", "bn" to "পেমেন্ট", "ar" to "الدفع", "fa" to "پرداخت", "zh" to "付款", "de" to "Zahlung", "fr" to "Paiement", "es" to "Pago"),
        "food" to mapOf("hi" to "खाना / भोजन", "en" to "Food / Meals", "ur" to "کھانا", "bn" to "খাবার", "ar" to "طعام", "fa" to "غذا", "zh" to "食物", "de" to "Essen", "fr" to "Nourriture", "es" to "Comida"),
        "rice" to mapOf("hi" to "चावल / बासमती", "en" to "Rice", "ur" to "چاول", "bn" to "চাল / ভাত", "ar" to "أرز", "fa" to "برنج", "zh" to "米饭", "de" to "Reis", "fr" to "Riz", "es" to "Arroz"),
        "oil" to mapOf("hi" to "तेल (सरसों/रिफाइंड)", "en" to "Cooking Oil", "ur" to "تیل", "bn" to "তেল", "ar" to "زيت", "fa" to "روغن", "zh" to "食用油", "de" to "Öl", "fr" to "Huile", "es" to "Aceite"),
        "water" to mapOf("hi" to "पानी / जल", "en" to "Water", "ur" to "پانی", "bn" to "জল / পানি", "ar" to "ماء", "fa" to "آب", "zh" to "水", "de" to "Wasser", "fr" to "Eau", "es" to "Agua"),
        "urgent" to mapOf("hi" to "जल्दी / तुरंत", "en" to "Urgent / Fast", "ur" to "فوری / جلدی", "bn" to "জরুরী / দ্রুত", "ar" to "عاجل", "fa" to "فوری", "zh" to "紧急", "de" to "Dringend", "fr" to "Urgent", "es" to "Urgente"),
        "quality" to mapOf("hi" to "गुणवत्ता / अच्छा माल", "en" to "High Quality", "ur" to "معیار", "bn" to "গুণমান", "ar" to "جودة", "fa" to "کیفیت", "zh" to "质量", "de" to "Qualität", "fr" to "Qualité", "es" to "Calidad"),
        "help" to mapOf("hi" to "मदद / सहायता", "en" to "Help / Support", "ur" to "مدد", "bn" to "সাহায্য", "ar" to "مساعدة", "fa" to "کمک", "zh" to "帮助", "de" to "Hilfe", "fr" to "Aide", "es" to "Ayuda"),
        "hello" to mapOf("hi" to "नमस्ते / नमस्कार", "en" to "Hello / Greetings", "ur" to "سلام عليكم", "bn" to "নমস্কার / হ্যালো", "ar" to "مرحباً", "fa" to "سلام", "zh" to "你好", "de" to "Hallo", "fr" to "Bonjour", "es" to "Hola"),
        "thanks" to mapOf("hi" to "धन्यवाद / शुक्रिया", "en" to "Thank you", "ur" to "شکریہ", "bn" to "ধন্যবাদ", "ar" to "شكراً", "fa" to "متشکرم", "zh" to "谢谢", "de" to "Danke", "fr" to "Merci", "es" to "Gracias")
    )

    // Common customer phrases
    private val phraseMap = mapOf(
        "available" to mapOf(
            "en" to "Is this item available in stock?",
            "hi" to "क्या यह सामान दुकान में उपलब्ध है?",
            "ur" to "کیا یہ سامان اسٹاک میں دستیاب ہے؟",
            "bn" to "এই পণ্যটি কি স্টকে পাওয়া যাবে?",
            "ar" to "هل هذا المنتج متوفر في المخزون؟",
            "fa" to "آیا این کالا در انبار موجود است؟",
            "zh" to "这件商品有现货吗？"
        ),
        "delivery_time" to mapOf(
            "en" to "What is the delivery time to my address?",
            "hi" to "मेरे पते पर डिलीवरी कितने समय में होगी?",
            "ur" to "میرے پتے پر ڈیلیوری میں کتنا وقت لگے گا؟",
            "bn" to "আমার ঠিকানায় ডেলিভারি হতে কত সময় লাগবে?",
            "ar" to "كم من الوقت يستغرق التوصيل إلى عنواني؟",
            "fa" to "زمان تحویل چقدر طول می‌کشد؟",
            "zh" to "送到我的地址需要多长时间？"
        ),
        "cod" to mapOf(
            "en" to "I want Cash on Delivery without advance payment.",
            "hi" to "मुझे बिना किसी एडवांस के कैश ऑन डिलीवरी (COD) चाहिए।",
            "ur" to "مجھے بغیر کسی ایڈوانس کے کیش آن ڈیلیوری چاہیے۔",
            "bn" to "আমি অগ্রিম টাকা ছাড়া ক্যাশ অন ডেলিভারি চাই।",
            "ar" to "أريد الدفع عند الاستلام نقداً دون دفع مسبق.",
            "fa" to "من پرداخت در محل بدون پیش‌پرداخت می‌خواهم.",
            "zh" to "我需要无预付款的货到付款。"
        ),
        "confirm_order" to mapOf(
            "en" to "Please confirm and pack my order now.",
            "hi" to "कृपया मेरा ऑर्डर तुरंत कन्फर्म और पैक करें।",
            "ur" to "براہ کرم میرا آرڈر فورا کنفرم اور پیک کریں۔",
            "bn" to "দয়া করে আমার অর্ডারটি এখনই নিশ্চিত করুন।",
            "ar" to "يرجى تأكيد وتجهيز طلبي الآن.",
            "fa" to "لطفاً سفارش من را تأیید و بسته‌بندی کنید.",
            "zh" to "请立即确认并打包我的订单。"
        ),
        "upi_paid" to mapOf(
            "en" to "I have sent payment on UPI ID: 9470026573@ybl",
            "hi" to "मैंने UPI आईडी 9470026573@ybl पर पेमेंट भेज दिया है।",
            "ur" to "میں نے یو پی آئی پر ادائیگی بھیج دی ہے۔",
            "bn" to "আমি ইউপিআই আইডি 9470026573@ybl-এ টাকা পাঠিয়েছি।",
            "ar" to "لقد أرسلت المبلغ عبر معرف UPI.",
            "fa" to "من پرداخت را از طریق UPI ارسال کرده‌ام.",
            "zh" to "我已向 UPI ID 完成转账付款。"
        ),
        "discount" to mapOf(
            "en" to "Can I get a discount or special offer on this order?",
            "hi" to "क्या इस ऑर्डर पर कोई खास डिस्काउंट या छूट मिलेगी?",
            "ur" to "کیا اس آرڈر پر کوئی خاص ڈسکاؤنٹ ملے گا؟",
            "bn" to "এই অর্ডারে কোনো বিশেষ ছাড় পাওয়া যাবে?",
            "ar" to "هل يمكنني الحصول على خصم خاص على هذا الطلب؟",
            "fa" to "آیا برای این سفارش تخفیف ویژه‌ای وجود دارد؟",
            "zh" to "这笔订单能享受优惠折扣吗？"
        )
    )

    fun getQuickWords(): List<Pair<String, String>> = listOf(
        "work" to "Work (काम)",
        "price" to "Price (दाम)",
        "delivery" to "Delivery (डिलीवरी)",
        "discount" to "Discount (छूट)",
        "money" to "Money (पैसा)",
        "shop" to "Shop (दुकान)",
        "quality" to "Quality (गुणवत्ता)",
        "food" to "Food (खाना)"
    )

    fun getQuickPhrases(): List<Pair<String, String>> = listOf(
        "available" to "📦 Available? (सामान है?)",
        "delivery_time" to "⏱️ Delivery Time? (समय)",
        "cod" to "💵 Cash on Delivery (COD)",
        "confirm_order" to "✅ Confirm Order",
        "upi_paid" to "📱 Paid on UPI",
        "discount" to "🎟️ Discount? (छूट)"
    )

    /**
     * Translates any single word, sentence, or long multi-line paragraph.
     * Executes online live translation via Google Translate gtx service with fallbacks.
     */
    suspend fun translateText(text: String, sourceLang: String, targetLang: String): String = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext ""
        if (sourceLang != "auto" && sourceLang == targetLang) return@withContext trimmed

        val sl = if (sourceLang == "bho") "hi" else sourceLang
        val tl = if (targetLang == "bho") "hi" else targetLang

        // 1. Check direct vocabulary match first for instant single-word lookup
        val lower = trimmed.lowercase()
        if (vocabDictionary.containsKey(lower)) {
            val direct = vocabDictionary[lower]?.get(tl)
            if (!direct.isNullOrBlank()) {
                return@withContext direct
            }
        }

        // 2. Online Google Translate Public Endpoint (high accuracy for words & long sentences)
        try {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$encoded"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBody = response.body?.string()
                if (!responseBody.isNullOrBlank()) {
                    val rootArray = JSONArray(responseBody)
                    val sentencesArray = rootArray.getJSONArray(0)
                    val sb = StringBuilder()
                    for (i in 0 until sentencesArray.length()) {
                        val sentence = sentencesArray.getJSONArray(i)
                        sb.append(sentence.getString(0))
                    }
                    val translatedResult = sb.toString().trim()
                    if (translatedResult.isNotEmpty()) {
                        return@withContext translatedResult
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("RealTranslator", "Google gtx failed: ${e.message}")
        }

        // 3. Secondary Online Fallback: MyMemory API
        try {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            val sLang = if (sl == "auto") "en" else sl
            val url = "https://api.mymemory.translated.net/get?q=$encoded&langpair=$sLang|$tl"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (!body.isNullOrBlank()) {
                    val json = JSONObject(body)
                    val resData = json.optJSONObject("responseData")
                    val trans = resData?.optString("translatedText")
                    if (!trans.isNullOrBlank() && !trans.contains("MYMEMORY WARNING", ignoreCase = true)) {
                        return@withContext trans
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("RealTranslator", "MyMemory fallback failed: ${e.message}")
        }

        // 4. Offline Phrase & Substring fallback
        for ((_, transMap) in phraseMap) {
            val match = transMap.entries.find { (_, v) ->
                v.equals(trimmed, ignoreCase = true) || trimmed.contains(v, ignoreCase = true)
            }
            if (match != null) {
                return@withContext transMap[tl] ?: transMap["en"] ?: trimmed
            }
        }

        // 5. Offline vocabulary word-by-word fallback
        for ((word, wordTranslations) in vocabDictionary) {
            if (lower == word || lower.contains(word)) {
                val found = wordTranslations[tl]
                if (found != null) {
                    return@withContext found
                }
            }
        }

        // Return original if no translation network accessible
        return@withContext trimmed
    }
}

/**
 * Modern, High-Performance Dynamic Translator Assistant Card
 * Supports:
 * - Real live translation for ANY single word (e.g., "work" -> "काम", "market" -> "बाज़ार")
 * - Real live translation for long multi-line sentences & customer messages
 * - Voice Input (Microphone / Speak to translate)
 * - Text-To-Speech (Pronunciation playback)
 * - Swap languages (English ⇄ Hindi ⇄ Urdu ⇄ Bengali etc.)
 * - Instant Copy & Direct WhatsApp sharing
 */
@Composable
fun TranslatorAssistantCard(
    modifier: Modifier = Modifier,
    onClose: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var sourceLang by remember { mutableStateOf(SOURCE_LANGUAGES[0]) } // Auto Detect
    var targetLang by remember { mutableStateOf(TARGET_LANGUAGES[0]) } // Hindi default
    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }

    var showSourceDropdown by remember { mutableStateOf(false) }
    var showTargetDropdown by remember { mutableStateOf(false) }

    // TextToSpeech for pronunciation
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val speech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
            }
        }
        tts = speech
        onDispose {
            speech.stop()
            speech.shutdown()
        }
    }

    // Voice recognition launcher for speech-to-text
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenWords = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenWords?.firstOrNull() ?: ""
            if (spokenText.isNotBlank()) {
                inputText = spokenText
                coroutineScope.launch {
                    isTranslating = true
                    translatedText = TranslationEngine.translateText(spokenText, sourceLang.code, targetLang.code)
                    isTranslating = false
                }
            }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp),
        border = BorderStroke(1.5.dp, Color(0xFFCBD5E1))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(0xFF2563EB).copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Translate,
                            contentDescription = null,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Real-Time Translator",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFF16A34A).copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "LIVE",
                                    color = Color(0xFF16A34A),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Words & Full Sentences (Hindi, English, Urdu, Bengali & more)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Language Selector Row (Source ⇄ Target)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language Selector
                Box {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                        modifier = Modifier.clickable { showSourceDropdown = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${sourceLang.flag} ${sourceLang.nativeName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                        }
                    }

                    DropdownMenu(
                        expanded = showSourceDropdown,
                        onDismissRequest = { showSourceDropdown = false }
                    ) {
                        SOURCE_LANGUAGES.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text("${lang.flag} ${lang.nativeName} (${lang.name})") },
                                onClick = {
                                    sourceLang = lang
                                    showSourceDropdown = false
                                    if (inputText.isNotBlank()) {
                                        coroutineScope.launch {
                                            isTranslating = true
                                            translatedText = TranslationEngine.translateText(inputText, lang.code, targetLang.code)
                                            isTranslating = false
                                        }
                                    }
                                }
                            )
                        }
                    }
                }

                // Swap Languages Button
                IconButton(
                    onClick = {
                        val currentTargetAsSource = SOURCE_LANGUAGES.find { it.code == targetLang.code } ?: SOURCE_LANGUAGES[1]
                        val currentSourceAsTarget = TARGET_LANGUAGES.find { it.code == sourceLang.code } ?: TARGET_LANGUAGES[0]
                        sourceLang = currentTargetAsSource
                        targetLang = currentSourceAsTarget

                        val prevInput = inputText
                        val prevTrans = translatedText
                        inputText = prevTrans
                        translatedText = prevInput
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = "Swap Languages", tint = Color(0xFF2563EB))
                }

                // Target Language Selector
                Box {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                        modifier = Modifier.clickable { showTargetDropdown = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${targetLang.flag} ${targetLang.nativeName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                        }
                    }

                    DropdownMenu(
                        expanded = showTargetDropdown,
                        onDismissRequest = { showTargetDropdown = false }
                    ) {
                        TARGET_LANGUAGES.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text("${lang.flag} ${lang.nativeName} (${lang.name})") },
                                onClick = {
                                    targetLang = lang
                                    showTargetDropdown = false
                                    if (inputText.isNotBlank()) {
                                        coroutineScope.launch {
                                            isTranslating = true
                                            translatedText = TranslationEngine.translateText(inputText, sourceLang.code, lang.code)
                                            isTranslating = false
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Word Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TranslationEngine.getQuickWords().forEach { (word, label) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                        modifier = Modifier.clickable {
                            inputText = word
                            coroutineScope.launch {
                                isTranslating = true
                                translatedText = TranslationEngine.translateText(word, sourceLang.code, targetLang.code)
                                isTranslating = false
                            }
                        }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Phrases Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TranslationEngine.getQuickPhrases().forEach { (key, label) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.clickable {
                            val defaultEn = when (key) {
                                "available" -> "Is this item available in stock?"
                                "delivery_time" -> "What is the delivery time to my address?"
                                "cod" -> "I want Cash on Delivery without advance."
                                "confirm_order" -> "Please confirm my order."
                                "upi_paid" -> "I have sent payment on UPI."
                                else -> "Can I get a discount?"
                            }
                            inputText = defaultEn
                            coroutineScope.launch {
                                isTranslating = true
                                translatedText = TranslationEngine.translateText(defaultEn, "en", targetLang.code)
                                isTranslating = false
                            }
                        }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1D4ED8),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Multi-line Input Text Field with Mic and Clear
            OutlinedTextField(
                value = inputText,
                onValueChange = {
                    inputText = it
                },
                placeholder = {
                    Text(
                        "Type any word or full sentence (e.g. 'work' या 'डिलीवरी कब होगी?')...",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 68.dp, max = 110.dp),
                shape = RoundedCornerShape(10.dp),
                maxLines = 4,
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (inputText.isNotEmpty()) {
                            IconButton(onClick = {
                                inputText = ""
                                translatedText = ""
                            }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak word or sentence to translate...")
                            }
                            try {
                                speechLauncher.launch(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Voice input not supported", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFFCBD5E1),
                    unfocusedContainerColor = Color(0xFFF8FAFC),
                    focusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Action: Translate Button
            Button(
                onClick = {
                    if (inputText.isNotBlank()) {
                        coroutineScope.launch {
                            isTranslating = true
                            translatedText = TranslationEngine.translateText(inputText, sourceLang.code, targetLang.code)
                            isTranslating = false
                        }
                    }
                },
                enabled = inputText.isNotBlank() && !isTranslating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                if (isTranslating) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Translating...", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.GTranslate, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Translate (अनुवाद करें)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                }
            }

            // Result Display Box
            if (translatedText.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF0FDF4),
                    border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Meaning / Translation (${targetLang.nativeName}):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF166534)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Speak / TTS Pronunciation
                                IconButton(
                                    onClick = {
                                        if (isTtsReady && tts != null) {
                                            val loc = when (targetLang.code) {
                                                "hi" -> Locale("hi", "IN")
                                                "bn" -> Locale("bn", "IN")
                                                "ur" -> Locale("ur", "PK")
                                                "ar" -> Locale("ar")
                                                "zh" -> Locale.CHINESE
                                                "de" -> Locale.GERMAN
                                                "fr" -> Locale.FRENCH
                                                "es" -> Locale("es")
                                                else -> Locale.ENGLISH
                                            }
                                            tts?.language = loc
                                            tts?.speak(translatedText, TextToSpeech.QUEUE_FLUSH, null, "TransTts")
                                        } else {
                                            Toast.makeText(context, "Voice playback initializing...", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Listen", tint = Color(0xFF166534), modifier = Modifier.size(17.dp))
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                // Copy
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", translatedText))
                                        Toast.makeText(context, "Translation copied!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFF166534), modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                // Send to WhatsApp
                                IconButton(
                                    onClick = {
                                        StoreConstants.openWhatsApp(context, translatedText)
                                    },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send WhatsApp", tint = Color(0xFF166534), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = translatedText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A),
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}
