package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OrderEntity
import com.example.data.model.Product
import com.example.ui.components.ProductVisualDrawing
import com.example.ui.components.ProductImageView
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.ShopViewModel
import com.example.util.OrderExcelExporter
import com.example.util.StoreConstants
import com.example.data.local.StoreOffer
import com.example.ui.components.AdminAiAssistantCard
import com.example.R
import android.widget.Toast
import androidx.compose.ui.res.painterResource
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// High-contrast design palette
val ContrastBgCanvas = Color(0xFFF1F5F9) // Slate-100 canvas (Never blinding flat white)
val DeepNavyBlack = Color(0xFF0F172A)    // Slate-900 (High-contrast deep dark text)
val DarkCharcoalText = Color(0xFF1E293B) // Slate-800 (Bold high-contrast subtitle)
val MutedBoldText = Color(0xFF475569)    // Slate-600 (Crisp readable text)
val BorderCrisp = Color(0xFFCBD5E1)      // Slate-300 (Crisp distinct card borders)

// ==========================================
// SCREEN: ADMIN LOGIN (STRICT CREDENTIALS)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginScreen(viewModel: ShopViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val loginError by viewModel.adminLoginError.collectAsStateWithLifecycle()
    val focusManager = LocalFocusManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AH SHOP Admin Portal",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = DeepNavyBlack
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("admin_login_back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = DeepNavyBlack
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ContrastBgCanvas)
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(NordicMidnightIndigo.copy(alpha = 0.12f))
                    .border(2.dp, NordicMidnightIndigo, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Security",
                    tint = NordicMidnightIndigo,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "AH SHOP STORE ADMIN",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = DeepNavyBlack,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "अधिकृत स्टोर एडमिन लॉगिन (Official Admin Access)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = DarkCharcoalText,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, BorderCrisp),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(22.dp)) {
                    Text(
                        text = "Admin Email ID (ईमेल)*",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = DeepNavyBlack
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        placeholder = {
                            Text(
                                "Enter Admin Email ID",
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = NordicMidnightIndigo)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_username_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = DeepNavyBlack,
                            unfocusedTextColor = DeepNavyBlack,
                            focusedBorderColor = NordicMidnightIndigo,
                            unfocusedBorderColor = BorderCrisp
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Admin Password (पासवर्ड)*",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = DeepNavyBlack
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = {
                            Text(
                                "Enter Admin Password",
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = NordicMidnightIndigo)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = NordicMidnightIndigo
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_password_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = DeepNavyBlack,
                            unfocusedTextColor = DeepNavyBlack,
                            focusedBorderColor = NordicMidnightIndigo,
                            unfocusedBorderColor = BorderCrisp
                        )
                    )

                    if (loginError != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = Color(0xFFFFEBEE),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFEF9A9A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = Color(0xFFC62828),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = loginError!!,
                                    color = Color(0xFFC62828),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.loginAdmin(username, password)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("admin_submit_login_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        shape = RoundedCornerShape(12.dp),
                        elevation = ButtonDefaults.buttonElevation(4.dp)
                    ) {
                        Icon(Icons.Default.Login, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Admin Login (लॉगिन करें)",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, BorderCrisp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint = AccentGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Strict Security: केवल अधिकृत ईमेल और पासवर्ड से ही लॉगिन संभव है।",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = DarkCharcoalText
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN: ADMIN DASHBOARD
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(viewModel: ShopViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val isSyncingOrders by viewModel.isSyncingOrders.collectAsStateWithLifecycle()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsStateWithLifecycle()

    var showAddProductDialog by remember { mutableStateOf(false) }
    var showExcelSheetDialog by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // Automatically synchronize orders from all customer phones on opening & periodically
    LaunchedEffect(Unit) {
        viewModel.syncOrdersFromCloud()
        while (true) {
            kotlinx.coroutines.delay(8000) // Poll central cloud every 8 seconds for new orders
            viewModel.syncOrdersFromCloud()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "AH SHOP Admin Console",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = DeepNavyBlack
                        )
                        Text(
                            text = "स्टोर मैनेजमेंट व ऑर्डर ट्रैकिंग",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = DarkCharcoalText
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.Main) },
                        modifier = Modifier.testTag("admin_exit_to_store_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Store", tint = DeepNavyBlack)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AiHub) },
                        modifier = Modifier.testTag("admin_top_ai_studio_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI Voice & Chat Assistant", tint = Color(0xFF6366F1))
                    }
                    IconButton(
                        onClick = { showQrDialog = true },
                        modifier = Modifier.testTag("admin_top_qr_button")
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = "App QR Code & Poster", tint = NordicMidnightIndigo)
                    }
                    IconButton(
                        onClick = { showExcelSheetDialog = true },
                        modifier = Modifier.testTag("admin_top_excel_sheet_button")
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = "Excel Orders Sheet", tint = AccentGreen)
                    }
                    IconButton(
                        onClick = { viewModel.logoutAdmin() },
                        modifier = Modifier.testTag("admin_logout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Logout", tint = Color.Red)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            if (selectedTab == 1) {
                ExtendedFloatingActionButton(
                    onClick = { showAddProductDialog = true },
                    containerColor = NordicMidnightIndigo,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null, tint = Color.White) },
                    text = {
                        Text(
                            text = "+ Add Product (सामान जोड़ें)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier.testTag("admin_add_product_fab")
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ContrastBgCanvas)
                .padding(padding)
        ) {
            // Tab Selector with clear bold contrast
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = NordicMidnightIndigo
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Orders (${orders.size})",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = if (selectedTab == 0) NordicMidnightIndigo else DarkCharcoalText
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Listings (${allProducts.size})",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = if (selectedTab == 1) NordicMidnightIndigo else DarkCharcoalText
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            text = "Overview (रिपोर्ट)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = if (selectedTab == 2) NordicMidnightIndigo else DarkCharcoalText
                        )
                    }
                )
            }

            when (selectedTab) {
                0 -> AdminOrdersTab(
                    viewModel = viewModel,
                    orders = orders
                )
                1 -> AdminProductsTab(
                    viewModel = viewModel,
                    products = allProducts,
                    onAddNewProduct = { showAddProductDialog = true }
                )
                2 -> AdminAnalyticsTab(
                    viewModel = viewModel,
                    orders = orders,
                    products = allProducts,
                    isSyncing = isSyncingOrders,
                    syncMessage = syncStatusMessage,
                    onSyncNow = { viewModel.syncOrdersFromCloud() },
                    onGoToStore = { viewModel.navigateTo(Screen.Main) },
                    onOpenQrStudio = { showQrDialog = true }
                )
            }
        }

        if (showAddProductDialog) {
            AdminAddProductDialog(
                onDismiss = { showAddProductDialog = false },
                onAdd = { title, hindiName, price, originalPrice, unit, category, subcategory, desc, imageUrl, section ->
                    viewModel.adminAddProduct(title, hindiName, price, originalPrice, unit, category, subcategory, desc, imageUrl, section)
                    showAddProductDialog = false
                }
            )
        }

        if (showExcelSheetDialog) {
            AdminExcelPreviewDialog(
                orders = orders,
                onDismiss = { showExcelSheetDialog = false },
                onExport = { OrderExcelExporter.exportAndShare(context, orders) },
                onCopy = { OrderExcelExporter.copyToClipboard(context, orders) }
            )
        }

        if (showQrDialog) {
            QrShareDialog(
                onDismiss = { showQrDialog = false }
            )
        }
    }
}

// ==========================================
// TAB 1: ADMIN ORDERS TAB
// ==========================================

@Composable
fun AdminOrdersTab(
    viewModel: ShopViewModel,
    orders: List<OrderEntity>
) {
    var filterStatus by remember { mutableStateOf("All") }
    var orderSearch by remember { mutableStateOf("") }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val statusOptions = listOf("All", "Pending", "Accepted", "Out for Delivery", "Delivered", "Cancelled")

    val filteredOrders = orders.filter { order ->
        val statusMatches = filterStatus == "All" || order.status.equals(filterStatus, ignoreCase = true)
        val searchMatches = orderSearch.isBlank() ||
                order.orderNumber.contains(orderSearch, ignoreCase = true) ||
                order.customerName.contains(orderSearch, ignoreCase = true) ||
                order.customerPhone.contains(orderSearch, ignoreCase = true) ||
                order.itemsSummary.contains(orderSearch, ignoreCase = true)
        statusMatches && searchMatches
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Orders Header Bar with Clear All button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Orders List (${filteredOrders.size}/${orders.size})",
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                color = DeepNavyBlack
            )

            OutlinedButton(
                onClick = { showDeleteAllDialog = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFFEF4444)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Delete All Orders", tint = Color(0xFFDC2626), modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("Clear All", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
            }
        }

        if (showDeleteAllDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteAllDialog = false },
                title = {
                    Text("Delete All Orders? (सभी ऑर्डर हटाएं)", fontWeight = FontWeight.Black, color = Color(0xFFDC2626))
                },
                text = {
                    Text("क्या आप सचमुच सभी ऑर्डर्स डिलीट करना चाहते हैं? इससे सभी टेस्ट ऑर्डर्स आपके फोन और ऑनलाइन क्लाउड दोनों से हमेशा के लिए साफ हो जाएंगे।")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showDeleteAllDialog = false
                            viewModel.clearAllOrders {
                                android.widget.Toast.makeText(context, "सारे टेस्ट ऑर्डर्स सफलतापूर्वक डिलीट कर दिए गए!", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("हाँ, सब डिलीट करें", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteAllDialog = false }) {
                        Text("रद्द करें", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        Surface(
            color = Color.White,
            shadowElevation = 1.dp,
            border = BorderStroke(1.dp, BorderCrisp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                TextField(
                    value = orderSearch,
                    onValueChange = { orderSearch = it },
                    placeholder = {
                        Text(
                            "Search Order #, Customer, Phone...",
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DeepNavyBlack, modifier = Modifier.size(16.dp)) },
                    trailingIcon = {
                        if (orderSearch.isNotBlank()) {
                            IconButton(onClick = { orderSearch = "" }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .border(1.dp, BorderCrisp, RoundedCornerShape(8.dp))
                        .testTag("admin_order_search_input"),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = DeepNavyBlack,
                        unfocusedTextColor = DeepNavyBlack,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        unfocusedContainerColor = Color(0xFFF8FAFC),
                        focusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    statusOptions.forEach { status ->
                        val isSelected = filterStatus == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { filterStatus = status },
                            label = {
                                Text(
                                    text = status,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NordicMidnightIndigo,
                                selectedLabelColor = Color.White,
                                containerColor = Color.White,
                                labelColor = DeepNavyBlack
                            ),
                            border = BorderStroke(1.dp, if (isSelected) NordicMidnightIndigo else BorderCrisp)
                        )
                    }
                }
            }
        }

        if (filteredOrders.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.Inbox,
                    contentDescription = null,
                    modifier = Modifier.size(60.dp),
                    tint = MutedBoldText
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "No Orders Found",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = DeepNavyBlack
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Customer orders will show up here live in real-time.",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkCharcoalText,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Spacer(modifier = Modifier.height(10.dp)) }

                items(filteredOrders) { order ->
                    AdminOrderCard(
                        order = order,
                        onUpdateStatus = { newStatus ->
                            viewModel.adminUpdateOrderStatus(order.id, newStatus)
                        },
                        onDelete = {
                            viewModel.adminDeleteOrder(order.id)
                        }
                    )
                }

                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
fun AdminOrderCard(
    order: OrderEntity,
    onUpdateStatus: (String) -> Unit,
    onDelete: () -> Unit
) {
    var showStatusMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val statusColor = when (order.status.lowercase()) {
        "pending" -> Color(0xFFC2410C) // Bold Deep Orange
        "accepted" -> Color(0xFF1D4ED8) // Bold Blue
        "out for delivery" -> Color(0xFFD97706) // Bold Amber
        "delivered" -> Color(0xFF15803D) // Bold Green
        "cancelled" -> Color(0xFFB91C1C) // Bold Red
        else -> DeepNavyBlack
    }

    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val dateStr = sdf.format(Date(order.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, BorderCrisp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Order ID + Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ORDER: ${order.orderNumber}",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = DeepNavyBlack
                    )
                    Text(
                        text = dateStr,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedBoldText
                    )
                }

                Box(
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .border(1.5.dp, statusColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = order.status.uppercase(),
                        color = statusColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = BorderCrisp, thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Customer Details Box
            Surface(
                color = ContrastBgCanvas,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, BorderCrisp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CUSTOMER DETAILS (ग्राहक का विवरण)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = NordicMidnightIndigo,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = DeepNavyBlack, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (order.customerName.isNotBlank()) order.customerName else "Customer",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = DeepNavyBlack
                        )
                    }
                    if (order.customerPhone.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = AccentWarmSand, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = order.customerPhone,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeepNavyBlack
                            )
                        }
                    }
                    if (order.customerAddress.isNotBlank()) {
                        val context = LocalContext.current
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Red, modifier = Modifier.size(15.dp).padding(top = 1.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = order.customerAddress,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkCharcoalText
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFEFF6FF),
                                border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                modifier = Modifier.clickable {
                                    val q = order.customerAddress + ", Garden Reach, Kolkata"
                                    val mapUri = Uri.parse("geo:0,0?q=${Uri.encode(q)}")
                                    try {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, mapUri))
                                    } catch (e: Exception) {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(q)}")))
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Map Location", tint = Color(0xFF2563EB), modifier = Modifier.size(11.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Map ➔", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ordered Items
            Text(
                text = "Items Ordered (${order.itemsCount} total):",
                fontSize = 12.sp,
                color = MutedBoldText,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = order.itemsSummary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = DeepNavyBlack
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Payment & Total
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = order.paymentMethod,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = AccentGreen
                    )
                }

                Text(
                    text = "Total: ₹${String.format("%.2f", order.totalAmount)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    color = DeepNavyBlack
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderCrisp, thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Status Actions & Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Button(
                        onClick = { showStatusMenu = true },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Text(
                            text = "Update Status ▾",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }

                    DropdownMenu(
                        expanded = showStatusMenu,
                        onDismissRequest = { showStatusMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Mark Accepted (स्वीकार करें)", fontWeight = FontWeight.Bold) },
                            onClick = {
                                onUpdateStatus("Accepted")
                                showStatusMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Out for Delivery (डिलीवरी के लिए रवाना)", fontWeight = FontWeight.Bold) },
                            onClick = {
                                onUpdateStatus("Out for Delivery")
                                showStatusMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Mark Delivered (डिलीवर हो गया)", fontWeight = FontWeight.Bold) },
                            onClick = {
                                onUpdateStatus("Delivered")
                                showStatusMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Cancel Order (रद्द करें)", fontWeight = FontWeight.Bold, color = Color.Red) },
                            onClick = {
                                onUpdateStatus("Cancelled")
                                showStatusMenu = false
                            }
                        )
                    }
                }

                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.5.dp, Color.Red),
                    modifier = Modifier.height(38.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Order", tint = Color.Red, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete", color = Color.Red, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = {
                Text(
                    text = "Delete Order?",
                    fontWeight = FontWeight.Black,
                    color = DeepNavyBlack
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove order ${order.orderNumber} from the store records?",
                    fontWeight = FontWeight.Bold,
                    color = DarkCharcoalText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Delete Order", color = Color.White, fontWeight = FontWeight.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Keep", fontWeight = FontWeight.Black, color = DeepNavyBlack)
                }
            }
        )
    }
}

// ==========================================
// TAB 2: ADMIN PRODUCTS TAB (CRUD)
// ==========================================

@Composable
fun AdminProductsTab(
    viewModel: ShopViewModel,
    products: List<Product>,
    onAddNewProduct: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val categories = listOf("All", "Vegetables", "Fruits", "Dairy", "Grains", "Spices & Masala", "Snacks & Biscuits")

    val displayedProducts = products.filter { p ->
        val catMatches = selectedCategory == "All" || p.category.equals(selectedCategory, ignoreCase = true)
        val searchMatches = searchQuery.isBlank() ||
                p.title.contains(searchQuery, ignoreCase = true) ||
                p.hindiName.contains(searchQuery, ignoreCase = true) ||
                p.subcategory.contains(searchQuery, ignoreCase = true) ||
                p.category.contains(searchQuery, ignoreCase = true)
        catMatches && searchMatches
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = Color.White,
            shadowElevation = 1.dp,
            border = BorderStroke(1.dp, BorderCrisp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            "Search catalog by name, Hindi, category...",
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DeepNavyBlack, modifier = Modifier.size(16.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .border(1.dp, BorderCrisp, RoundedCornerShape(8.dp))
                        .testTag("admin_catalog_search_input"),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = DeepNavyBlack,
                        unfocusedTextColor = DeepNavyBlack,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        unfocusedContainerColor = Color(0xFFF8FAFC),
                        focusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSel = selectedCategory == cat
                        FilterChip(
                            selected = isSel,
                            onClick = { selectedCategory = cat },
                            label = {
                                Text(
                                    text = cat,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NordicMidnightIndigo,
                                selectedLabelColor = Color.White,
                                containerColor = Color.White,
                                labelColor = DeepNavyBlack
                            ),
                            border = BorderStroke(1.dp, if (isSel) NordicMidnightIndigo else BorderCrisp)
                        )
                    }
                }
            }
        }

        // Counter & Quick Add Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${displayedProducts.size} Items Listed in Store",
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                color = DeepNavyBlack
            )
            Button(
                onClick = onAddNewProduct,
                colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Item", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color.White)
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(displayedProducts, key = { it.id }) { product ->
                AdminProductCard(
                    product = product,
                    onEdit = { editingProduct = product },
                    onDelete = { productToDelete = product }
                )
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }

    // Edit Product Dialog
    if (editingProduct != null) {
        AdminEditProductDialog(
            product = editingProduct!!,
            onDismiss = { editingProduct = null },
            onSave = { updated ->
                viewModel.adminUpdateProduct(updated)
                editingProduct = null
            }
        )
    }

    // Delete Confirmation Dialog
    if (productToDelete != null) {
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = {
                Text(
                    text = "Delete Product / सामान हटाएं?",
                    fontWeight = FontWeight.Black,
                    color = DeepNavyBlack
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove '${productToDelete!!.title} (${productToDelete!!.hindiName})' from the store catalog?",
                    fontWeight = FontWeight.Bold,
                    color = DarkCharcoalText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminDeleteProduct(productToDelete!!.id)
                        productToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("Cancel", fontWeight = FontWeight.Black, color = DeepNavyBlack)
                }
            }
        )
    }
}

@Composable
fun AdminProductCard(
    product: Product,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, BorderCrisp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, BorderCrisp, RoundedCornerShape(8.dp))
            ) {
                ProductImageView(product = product, modifier = Modifier.fillMaxSize())
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = DeepNavyBlack,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (product.hindiName.isNotBlank()) {
                    Text(
                        text = product.hindiName,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = Color(0xFFC2410C) // Deep Warm Amber
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val pPrice = if (product.price % 1.0 == 0.0) product.price.toInt().toString() else product.price.toString()
                    Text(
                        text = "₹$pPrice / ${product.unit}",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = AccentGreen
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = if (product.section == "Food") Color(0xFFFFEDD5) else if (product.section == "E-Commerce") Color(0xFFE0E7FF) else Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = product.section.ifBlank { "Grocery" },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (product.section == "Food") Color(0xFFC2410C) else if (product.section == "E-Commerce") Color(0xFF4338CA) else Color(0xFF15803D),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${product.category}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MutedBoldText
                    )
                }
            }

            IconButton(onClick = onEdit, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = NordicMidnightIndigo, modifier = Modifier.size(22.dp))
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(22.dp))
            }
        }
    }
}

// ==========================================
// DIALOG: ADD PRODUCT
// ==========================================

@Composable
fun AdminAddProductDialog(
    onDismiss: () -> Unit,
    onAdd: (
        title: String,
        hindiName: String,
        price: Double,
        originalPrice: Double,
        unit: String,
        category: String,
        subcategory: String,
        description: String,
        imageUrl: String,
        section: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var hindiName by remember { mutableStateOf("") }
    var priceStr by remember { mutableStateOf("") }
    var originalPriceStr by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("1 KG") }
    var section by remember { mutableStateOf("Grocery") }
    var category by remember { mutableStateOf("Vegetables") }
    var subcategory by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }

    val sections = listOf("Grocery", "Food", "E-Commerce")
    val categories = when (section) {
        "Food" -> listOf("Biryani & Rice", "Rolls & Kebabs", "Chaat & Snacks", "Sweets & Desserts", "Beverages", "Mughlai")
        "E-Commerce" -> listOf("Electronics & Mobile", "Fashion & Apparel", "Home & Kitchen", "Beauty & Personal Care", "Bags & Luggage")
        else -> listOf("Vegetables", "Fruits", "Dairy", "Grains", "Spices & Masala", "Snacks & Biscuits")
    }
    val units = listOf("1 KG", "500 GM", "250 GM", "100 GM", "50 GM", "1 LTR", "500 ML", "1 PKT", "1 DOZEN", "1 PC", "1 PLATE", "1 PORTION")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Add New Product / नया सामान जोड़ें",
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = DeepNavyBlack
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Product Name (English)*", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        placeholder = { Text("e.g. Fresh Potato", fontWeight = FontWeight.Bold, color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth().testTag("add_product_title_input"),
                        singleLine = true
                    )
                }
                item {
                    Text("Hindi Name (हिंदी नाम)*", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = hindiName,
                        onValueChange = { hindiName = it },
                        placeholder = { Text("e.g. आलू / टमाटर", fontWeight = FontWeight.Bold, color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth().testTag("add_product_hindi_input"),
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Selling Price (₹)*", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = priceStr,
                                onValueChange = { priceStr = it },
                                placeholder = { Text("e.g. 35", fontWeight = FontWeight.Bold, color = Color.Gray) },
                                modifier = Modifier.fillMaxWidth().testTag("add_product_price_input"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("MRP (₹)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = originalPriceStr,
                                onValueChange = { originalPriceStr = it },
                                placeholder = { Text("e.g. 45", fontWeight = FontWeight.Bold, color = Color.Gray) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                    }
                }
                item {
                    Text("Section / विभाग:*", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sections.forEach { s ->
                            FilterChip(
                                selected = section == s,
                                onClick = {
                                    section = s
                                    category = when (s) {
                                        "Food" -> "Biryani & Rice"
                                        "E-Commerce" -> "Electronics & Mobile"
                                        else -> "Vegetables"
                                    }
                                },
                                label = {
                                    val labelText = when (s) {
                                        "Food" -> "🍽️ Food (खाना)"
                                        "E-Commerce" -> "🛍️ E-Commerce (शॉपिंग)"
                                        else -> "🛒 Grocery (किराना)"
                                    }
                                    Text(labelText, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Unit / वजन:*", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        units.forEach { u ->
                            FilterChip(
                                selected = unit == u,
                                onClick = { unit = u },
                                label = { Text(u, fontSize = 12.sp, fontWeight = FontWeight.Black) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Category / कैटेगरी:*", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { c ->
                            FilterChip(
                                selected = category == c,
                                onClick = { category = c },
                                label = { Text(c, fontSize = 12.sp, fontWeight = FontWeight.Black) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Subcategory / उपश्रेणी", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = subcategory,
                        onValueChange = { subcategory = it },
                        placeholder = { Text("e.g. Table Potatoes / Biryani / Smart Gadget", fontWeight = FontWeight.Bold, color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Text("Product Photo URL (फोटो लिंक / URL)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        placeholder = { Text("https://images.unsplash.com/... (optional)", color = Color.Gray, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Text("Description / विवरण", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        placeholder = { Text("Fresh, high quality daily produce / freshly cooked food", fontWeight = FontWeight.Bold, color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = priceStr.toDoubleOrNull() ?: 0.0
                    val op = originalPriceStr.toDoubleOrNull() ?: p
                    if (title.isNotBlank() && p > 0) {
                        onAdd(title, hindiName, p, op, unit, category, subcategory, description, imageUrl, section)
                    }
                },
                enabled = title.isNotBlank() && priceStr.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                modifier = Modifier.testTag("confirm_add_product_button")
            ) {
                Text("Add Product (जोड़ें)", fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontWeight = FontWeight.Black, color = DeepNavyBlack)
            }
        }
    )
}

// ==========================================
// DIALOG: EDIT PRODUCT
// ==========================================

@Composable
fun AdminEditProductDialog(
    product: Product,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var title by remember { mutableStateOf(product.title) }
    var hindiName by remember { mutableStateOf(product.hindiName) }
    var priceStr by remember { mutableStateOf(if (product.price % 1.0 == 0.0) product.price.toInt().toString() else product.price.toString()) }
    var originalPriceStr by remember { mutableStateOf(if (product.originalPrice % 1.0 == 0.0) product.originalPrice.toInt().toString() else product.originalPrice.toString()) }
    var unit by remember { mutableStateOf(product.unit) }
    var section by remember { mutableStateOf(product.section.ifBlank { "Grocery" }) }
    var category by remember { mutableStateOf(product.category) }
    var description by remember { mutableStateOf(product.description) }
    var imageUrl by remember { mutableStateOf(product.imageUrl) }

    val sections = listOf("Grocery", "Food", "E-Commerce")
    val categories = when (section) {
        "Food" -> listOf("Biryani & Rice", "Rolls & Kebabs", "Chaat & Snacks", "Sweets & Desserts", "Beverages", "Mughlai")
        "E-Commerce" -> listOf("Electronics & Mobile", "Fashion & Apparel", "Home & Kitchen", "Beauty & Personal Care", "Bags & Luggage")
        else -> listOf("Vegetables", "Fruits", "Dairy", "Grains", "Spices & Masala", "Snacks & Biscuits")
    }
    val units = listOf("1 KG", "500 GM", "250 GM", "100 GM", "50 GM", "1 LTR", "500 ML", "1 PKT", "1 DOZEN", "1 PC", "1 PLATE", "1 PORTION")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Edit Product / सामान एडिट करें",
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = DeepNavyBlack
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Product Name (English)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_title_input"),
                        singleLine = true
                    )
                }
                item {
                    Text("Hindi Name (हिंदी नाम)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = hindiName,
                        onValueChange = { hindiName = it },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_hindi_input"),
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Price (₹)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = priceStr,
                                onValueChange = { priceStr = it },
                                modifier = Modifier.fillMaxWidth().testTag("edit_product_price_input"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("MRP (₹)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = originalPriceStr,
                                onValueChange = { originalPriceStr = it },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                    }
                }
                item {
                    Text("Section / विभाग:*", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sections.forEach { s ->
                            FilterChip(
                                selected = section == s,
                                onClick = {
                                    section = s
                                    category = when (s) {
                                        "Food" -> "Biryani & Rice"
                                        "E-Commerce" -> "Electronics & Mobile"
                                        else -> "Vegetables"
                                    }
                                },
                                label = {
                                    val labelText = when (s) {
                                        "Food" -> "🍽️ Food (खाना)"
                                        "E-Commerce" -> "🛍️ E-Commerce (शॉपिंग)"
                                        else -> "🛒 Grocery (किराना)"
                                    }
                                    Text(labelText, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Unit / वजन:", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        units.forEach { u ->
                            FilterChip(
                                selected = unit == u,
                                onClick = { unit = u },
                                label = { Text(u, fontSize = 12.sp, fontWeight = FontWeight.Black) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Category / कैटेगरी:", fontSize = 12.sp, fontWeight = FontWeight.Black, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { c ->
                            FilterChip(
                                selected = category == c,
                                onClick = { category = c },
                                label = { Text(c, fontSize = 12.sp, fontWeight = FontWeight.Black) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NordicMidnightIndigo,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
                item {
                    Text("Product Photo URL (फोटो लिंक / URL)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        placeholder = { Text("https://images.unsplash.com/... (optional)", color = Color.Gray, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Text("Description / विवरण", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DeepNavyBlack)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = priceStr.toDoubleOrNull() ?: product.price
                    val op = originalPriceStr.toDoubleOrNull() ?: product.originalPrice
                    onSave(
                        product.copy(
                            title = title.trim(),
                            hindiName = hindiName.trim(),
                            price = p,
                            originalPrice = op,
                            unit = unit,
                            category = category,
                            description = description.trim(),
                            imageUrl = imageUrl.trim(),
                            section = section
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                modifier = Modifier.testTag("confirm_edit_product_button")
            ) {
                Text("Save Changes (सेव करें)", fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontWeight = FontWeight.Black, color = DeepNavyBlack)
            }
        }
    )
}

// ==========================================
// TAB 3: ADMIN ANALYTICS TAB
// ==========================================

@Composable
fun AdminAnalyticsTab(
    viewModel: ShopViewModel,
    orders: List<OrderEntity>,
    products: List<Product>,
    isSyncing: Boolean = false,
    syncMessage: String? = null,
    onSyncNow: () -> Unit = {},
    onGoToStore: () -> Unit,
    onOpenQrStudio: () -> Unit = {}
) {
    val totalRevenue = orders.filter { it.status != "Cancelled" }.sumOf { it.totalAmount }
    val pendingCount = orders.count { it.status.equals("pending", ignoreCase = true) }
    val deliveredCount = orders.count { it.status.equals("delivered", ignoreCase = true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Store Performance Overview",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = DeepNavyBlack
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Real-time summary of sales, orders & catalog health",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = DarkCharcoalText
            )
        }

        // Central Cloud Sync Card (Transferred to Overview)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                border = BorderStroke(1.5.dp, Color(0xFFCBD5E1))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            Icons.Default.CloudSync,
                            contentDescription = null,
                            tint = NordicMidnightIndigo,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Central Cloud Sync",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = DeepNavyBlack
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = AccentGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "LIVE",
                                        color = AccentGreen,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (isSyncing) "दूसरे फोन से ऑर्डर आ रहे हैं..." else (syncMessage ?: "अन्य मोबाइलों के ऑर्डर स्वतः अपडेट होते हैं"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MutedBoldText
                            )
                        }
                    }

                    Button(
                        onClick = onSyncNow,
                        enabled = !isSyncing,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        modifier = Modifier.height(34.dp)
                    ) {
                        if (isSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // Super-Powered Admin AI Business & Operations Assistant
        item {
            AdminAiAssistantCard(
                orders = orders,
                products = products,
                onOpenQrStudio = onOpenQrStudio
            )
        }

        // Revenue Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = NordicMidnightIndigo),
                border = BorderStroke(1.5.dp, DeepNavyBlack),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "TOTAL STORE REVENUE",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f),
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "₹${String.format("%.2f", totalRevenue)}",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        Icon(
                            Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = AccentWarmSand,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
        }

        // Stats Grid
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Total Orders",
                    value = orders.size.toString(),
                    subtitle = "All-time customer orders",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.ShoppingCart
                )
                AdminStatCard(
                    title = "Pending Orders",
                    value = pendingCount.toString(),
                    subtitle = "Awaiting dispatch",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.PendingActions,
                    color = if (pendingCount > 0) Color(0xFFC2410C) else DeepNavyBlack
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Delivered",
                    value = deliveredCount.toString(),
                    subtitle = "Fulfilled successfully",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.CheckCircle,
                    color = AccentGreen
                )
                AdminStatCard(
                    title = "Active Products",
                    value = products.size.toString(),
                    subtitle = "Live in grocery catalog",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Storefront
                )
            }
        }

        // Customer QR Code & Counter Poster Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, BorderCrisp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Store QR Code & Poster Studio (Admin Only)",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = DeepNavyBlack
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "दुकान का QR केवल एडमिन के पास सुरक्षित है। WhatsApp QR, UPI पेमेंट QR या प्रिंट पोस्टर तैयार करें",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkCharcoalText
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFFEDE9FE), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.QrCode2,
                                contentDescription = null,
                                tint = NordicMidnightIndigo,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onOpenQrStudio,
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("admin_analytics_open_qr_button")
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Open QR & Poster Studio (QR कोड व पोस्टर)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Excel Reports Card
        item {
            val context = LocalContext.current
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, BorderCrisp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Excel / CSV Store Reports",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = DeepNavyBlack
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Download complete orders report for bookkeeping and accounts",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkCharcoalText
                            )
                        }
                        Icon(
                            Icons.Default.TableChart,
                            contentDescription = null,
                            tint = AccentGreen,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            OrderExcelExporter.exportAndShare(context, orders)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("admin_analytics_export_excel_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Export All Orders to Excel (.csv)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Admin Special Grocery Offer Manager Card ("admin khud se ye offer de admin pannel se")
        item {
            val context = LocalContext.current
            val currentOffer by viewModel.storeOffer.collectAsStateWithLifecycle()

            var offerEnabled by remember(currentOffer) { mutableStateOf(currentOffer.isEnabled) }
            var bannerTag by remember(currentOffer) { mutableStateOf(currentOffer.bannerTag) }
            var offerTitle by remember(currentOffer) { mutableStateOf(currentOffer.title) }
            var couponCode by remember(currentOffer) { mutableStateOf(currentOffer.couponCode) }
            var discountAmount by remember(currentOffer) { mutableStateOf(currentOffer.discountAmount.toInt().toString()) }
            var minSpend by remember(currentOffer) { mutableStateOf(currentOffer.minSpend.toInt().toString()) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_offer_manager_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, if (offerEnabled) AccentWarmSand else Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Special Grocery Offer Banner",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = DeepNavyBlack
                            )
                            Text(
                                "होम स्क्रीन का स्पेशल ऑफर बैनर व कूपन कोड कंट्रोल करें",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkCharcoalText
                            )
                        }
                        Switch(
                            checked = offerEnabled,
                            onCheckedChange = { offerEnabled = it },
                            modifier = Modifier.testTag("admin_offer_toggle_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Status Badge
                    Box(
                        modifier = Modifier
                            .background(
                                if (offerEnabled) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (offerEnabled) "● OFFER ACTIVE ON CUSTOMER HOME SCREEN" else "○ OFFER DISABLED / HIDDEN FROM HOME",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = if (offerEnabled) Color(0xFF15803D) else Color(0xFFB91C1C)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = bannerTag,
                        onValueChange = { bannerTag = it },
                        label = { Text("Banner Tag (e.g. SPECIAL GROCERY OFFER)") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_offer_tag_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = offerTitle,
                        onValueChange = { offerTitle = it },
                        label = { Text("Offer Headline (e.g. Save ₹50 flat on orders over ₹200)") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_offer_title_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = couponCode,
                            onValueChange = { couponCode = it.uppercase() },
                            label = { Text("Coupon Code") },
                            modifier = Modifier.weight(1f).testTag("admin_offer_code_input")
                        )
                        OutlinedTextField(
                            value = discountAmount,
                            onValueChange = { discountAmount = it },
                            label = { Text("Discount (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f).testTag("admin_offer_discount_input")
                        )
                        OutlinedTextField(
                            value = minSpend,
                            onValueChange = { minSpend = it },
                            label = { Text("Min Order (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f).testTag("admin_offer_minspend_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Banner Preview
                    Text("Preview on Customer Home (कैसा दिखेगा):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(95.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NordicMidnightIndigo)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .background(AccentWarmSand, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = bannerTag.ifBlank { "SPECIAL GROCERY OFFER" },
                                        color = Color.White,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = offerTitle.ifBlank { "Save flat discount on groceries" },
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Coupon: ${couponCode.ifBlank { "WELCOME50" }} • Flat ₹${discountAmount.ifBlank { "50" }} OFF",
                                    color = AccentWarmSand,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Icon(
                                Icons.Default.LocalMall,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.2f),
                                modifier = Modifier.size(60.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val disc = discountAmount.toDoubleOrNull() ?: 50.0
                            val min = minSpend.toDoubleOrNull() ?: 200.0
                            val updatedOffer = StoreOffer(
                                isEnabled = offerEnabled,
                                bannerTag = bannerTag.trim().ifBlank { "SPECIAL GROCERY OFFER" },
                                title = offerTitle.trim().ifBlank { "Save ₹${disc.toInt()} flat on orders over ₹${min.toInt()}" },
                                couponCode = couponCode.trim().uppercase().ifBlank { "WELCOME50" },
                                discountAmount = disc,
                                minSpend = min
                            )
                            viewModel.updateStoreOffer(updatedOffer)
                            Toast.makeText(
                                context,
                                if (offerEnabled) "ऑफर सफलतापूर्वक अपडेट हो गया!" else "स्पेशल ऑफर हटा दिया गया (Disabled)",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (offerEnabled) AccentWarmSand else Color.DarkGray
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("admin_save_offer_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (offerEnabled) "Save & Publish Offer (ऑफर सेव करें)" else "Save (ऑफर बंद रखें)",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // AH SHOP Official Support & WhatsApp Info Card
        item {
            val context = LocalContext.current
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_store_contact_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, Color(0xFF86EFAC))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Store Address & WhatsApp Support",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = DeepNavyBlack
                            )
                            Text(
                                "दुकान का आधिकारिक पता व सपोर्ट नंबर",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DarkCharcoalText
                            )
                        }
                        Icon(
                            painter = painterResource(id = R.drawable.ic_whatsapp),
                            contentDescription = "WhatsApp",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(18.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = StoreConstants.STORE_ADDRESS,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepNavyBlack,
                            lineHeight = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Phone,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "WhatsApp & Mobile: ${StoreConstants.PHONE_NUMBER}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF15803D)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { StoreConstants.openWhatsApp(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                        ) {
                            Icon(painter = painterResource(id = R.drawable.ic_whatsapp), contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test WhatsApp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        }

                        OutlinedButton(
                            onClick = { StoreConstants.callStore(context) },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.5.dp, Color(0xFF16A34A)),
                            modifier = Modifier
                                .weight(0.9f)
                                .height(42.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Dial Phone", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF16A34A))
                        }
                    }
                }
            }
        }

        // Store Navigation CTA
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.5.dp, BorderCrisp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        "Customer Storefront",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = DeepNavyBlack
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Visit the customer shopping view to test the app as your shoppers do or place a test order.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkCharcoalText
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onGoToStore,
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text("Open Customer Shop (दुकान देखें)", fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color = DeepNavyBlack
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, BorderCrisp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 12.sp, color = DarkCharcoalText, fontWeight = FontWeight.Black)
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, fontSize = 24.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 11.sp, color = MutedBoldText, fontWeight = FontWeight.Bold)
        }
    }
}

// ==========================================
// COMPOSABLE: EXCEL SPREADSHEET PREVIEW DIALOG
// ==========================================

@Composable
fun AdminExcelPreviewDialog(
    orders: List<OrderEntity>,
    onDismiss: () -> Unit,
    onExport: () -> Unit,
    onCopy: () -> Unit
) {
    val totalRevenue = orders.sumOf { it.totalAmount }
    val dispTotal = if (totalRevenue % 1.0 == 0.0) totalRevenue.toInt().toString() else String.format(Locale.ENGLISH, "%.2f", totalRevenue)
    val deliveredCount = orders.count { it.status.equals("Delivered", ignoreCase = true) }
    val pendingCount = orders.count { it.status.equals("Pending", ignoreCase = true) }

    val dateFormat = remember { SimpleDateFormat("dd-MMM hh:mm a", Locale.ENGLISH) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.90f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, BorderCrisp),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NordicMidnightIndigo)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TableChart, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "Excel Orders Spreadsheet",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                "एक्सेल व गूगल शीट्स ऑर्डर रिपोर्ट",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .size(32.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                // Summary Pill Bar
                Surface(
                    color = ContrastBgCanvas,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, BorderCrisp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ExcelStatBadge("Total Orders", orders.size.toString(), DeepNavyBlack)
                        ExcelStatBadge("Total Sales", "₹$dispTotal", AccentGreen)
                        ExcelStatBadge("Delivered", deliveredCount.toString(), AccentGreen)
                        ExcelStatBadge("Pending", pendingCount.toString(), Color(0xFFC2410C))
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onExport,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export (.csv)", fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = onCopy,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.5.dp, DeepNavyBlack),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = DeepNavyBlack, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy All Rows", fontWeight = FontWeight.Black, fontSize = 13.sp, color = DeepNavyBlack)
                    }
                }

                // Table Container
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .border(1.5.dp, BorderCrisp, RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    if (orders.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No orders available in table", fontWeight = FontWeight.Bold, color = DarkCharcoalText)
                        }
                    } else {
                        val horizontalScrollState = rememberScrollState()
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .horizontalScroll(horizontalScrollState)
                        ) {
                            // Table Header Row
                            Row(
                                modifier = Modifier
                                    .background(DeepNavyBlack)
                                    .padding(vertical = 10.dp)
                            ) {
                                TableCell("#", 45.dp, isHeader = true)
                                TableCell("Order ID", 110.dp, isHeader = true)
                                TableCell("Date & Time", 140.dp, isHeader = true)
                                TableCell("Customer", 130.dp, isHeader = true)
                                TableCell("Mobile", 120.dp, isHeader = true)
                                TableCell("Address", 160.dp, isHeader = true)
                                TableCell("Items Summary", 190.dp, isHeader = true)
                                TableCell("Qty", 60.dp, isHeader = true)
                                TableCell("Amount (₹)", 100.dp, isHeader = true)
                                TableCell("Payment", 110.dp, isHeader = true)
                                TableCell("Status", 110.dp, isHeader = true)
                            }

                            // Table Rows in LazyColumn
                            LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                                items(orders.size) { index ->
                                    val order = orders[index]
                                    val isEven = index % 2 == 0
                                    val rowBg = if (isEven) Color.White else Color(0xFFF8FAFC)
                                    val dateStr = try { dateFormat.format(Date(order.timestamp)) } catch (e: Exception) { "" }
                                    val amountStr = if (order.totalAmount % 1.0 == 0.0) "₹${order.totalAmount.toInt()}" else "₹${String.format(Locale.ENGLISH, "%.2f", order.totalAmount)}"

                                    Row(
                                        modifier = Modifier
                                            .background(rowBg)
                                            .border(width = 0.5.dp, color = Color(0xFFE2E8F0))
                                            .padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TableCell((index + 1).toString(), 45.dp)
                                        TableCell(order.orderNumber.ifBlank { "ORD-${order.id}" }, 110.dp, isBold = true)
                                        TableCell(dateStr, 140.dp)
                                        TableCell(order.customerName.ifBlank { "Customer" }, 130.dp, isBold = true)
                                        TableCell(order.customerPhone.ifBlank { "N/A" }, 120.dp)
                                        TableCell(order.customerAddress.ifBlank { "Store Pickup" }, 160.dp)
                                        TableCell(order.itemsSummary.ifBlank { "Items" }, 190.dp)
                                        TableCell(order.itemsCount.toString(), 60.dp)
                                        TableCell(amountStr, 100.dp, isBold = true, textColor = DeepNavyBlack)
                                        TableCell(order.paymentMethod, 110.dp)
                                        TableStatusCell(order.status, 110.dp)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun ExcelStatBadge(label: String, value: String, valueColor: Color) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderCrisp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "$label: ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DarkCharcoalText)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Black, color = valueColor)
        }
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    isBold: Boolean = false,
    textColor: Color = if (isHeader) Color.White else DeepNavyBlack
) {
    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            fontSize = if (isHeader) 12.sp else 11.sp,
            fontWeight = if (isHeader) FontWeight.Black else if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = textColor,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TableStatusCell(status: String, width: androidx.compose.ui.unit.Dp) {
    val (bgColor, txtColor) = when (status.lowercase()) {
        "delivered" -> Pair(Color(0xFFDCFCE7), Color(0xFF15803D))
        "pending" -> Pair(Color(0xFFFFEDD5), Color(0xFFC2410C))
        "accepted" -> Pair(Color(0xFFDBEAFE), Color(0xFF1D4ED8))
        "out for delivery" -> Pair(Color(0xFFFEF3C7), Color(0xFFB45309))
        "cancelled" -> Pair(Color(0xFFFEE2E2), Color(0xFFB91C1C))
        else -> Pair(Color(0xFFF1F5F9), DeepNavyBlack)
    }

    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .background(bgColor, RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Text(
                text = status,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                color = txtColor,
                maxLines = 1
            )
        }
    }
}
