package com.example.ui.components

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.local.OrderEntity
import com.example.data.model.Product
import com.example.util.StoreConstants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Super-Powered Admin AI Business & Operations Assistant.
 * Built exclusively for the Admin Overview tab.
 *
 * Capabilities:
 * 1. Listens to speech with high capacity (>50 words input via Google Speech recognizer).
 * 2. Text chat with prompt history.
 * 3. In-depth, exhaustive long answers (>100 to 300+ words).
 * 4. Comprehensive knowledge base of BOTH Admin Panel & Customer Panel,
 *    live orders, product catalog, revenue, customer addresses, UPI, GPS tracking.
 * 5. Text-To-Speech (reads answers aloud).
 * 6. Powered by Gemini REST API with intelligent offline fallback.
 */
object AdminAiEngine {

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    suspend fun queryAssistant(
        prompt: String,
        orders: List<OrderEntity>,
        products: List<Product>
    ): String = withContext(Dispatchers.IO) {
        val totalRev = orders.filter { it.status != "Cancelled" }.sumOf { it.totalAmount }
        val pendingOrders = orders.filter { it.status.equals("pending", ignoreCase = true) }
        val deliveredOrders = orders.filter { it.status.equals("delivered", ignoreCase = true) }
        val foodProducts = products.filter { it.section.equals("Food", ignoreCase = true) }
        val groceryProducts = products.filter { it.section.equals("Grocery", ignoreCase = true) }
        val ecomProducts = products.filter { it.section.equals("E-Commerce", ignoreCase = true) }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // Try Gemini API if key is available and not dummy
        if (apiKey.isNotBlank() && !apiKey.contains("MY_GEMINI_API_KEY", ignoreCase = true)) {
            try {
                val liveContext = buildString {
                    append("STORE: AH SHOP (Garden Reach, Kolkata 700024). ")
                    append("TOTAL ORDERS: ${orders.size}. REVENUE: ₹${String.format("%.2f", totalRev)}. ")
                    append("PENDING ORDERS: ${pendingOrders.size}. DELIVERED: ${deliveredOrders.size}. ")
                    append("ACTIVE PRODUCTS: ${products.size} (Food: ${foodProducts.size}, Grocery: ${groceryProducts.size}, E-Commerce: ${ecomProducts.size}). ")
                    append("PAYMENT: UPI ID 9470026573@ybl, Cash on Delivery with ₹0 advance. ")
                    append("CUSTOMER PANEL FEATURES: GPS Auto-fetch location, 1-tap WhatsApp order, 3 categories (Food, Grocery, E-Commerce). ")
                    append("ADMIN PANEL FEATURES: Live Cloud Sync, Order dispatch, Product management, QR Studio. ")
                    append("CRITICAL REQUIREMENT: Provide an exhaustive, multi-paragraph, in-depth response (>120 to 300+ words) with clear structural bullet points, precise live figures, operational step-by-step guidance, and strategic advice. Never give short one-line replies.")
                }

                val systemPrompt = "You are the Chief Business & Operations AI Advisor for AH SHOP Admin. You answer in comprehensive, highly informative Hindi/English (Hinglish) or pure English. Address both Admin Panel and Customer Panel workings thoroughly."

                val jsonBody = JSONObject().apply {
                    val contents = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val parts = JSONArray().apply {
                                val partObj = JSONObject().apply {
                                    put("text", "$liveContext\n\nADMIN QUESTION: $prompt")
                                }
                                put(partObj)
                            }
                            put("parts", parts)
                        }
                        put(contentObj)
                    }
                    put("contents", contents)

                    val config = JSONObject().apply {
                        put("temperature", 0.7)
                        put("topP", 0.95)
                    }
                    put("generationConfig", config)
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val respString = response.body?.string()
                    if (!respString.isNullOrBlank()) {
                        val respJson = JSONObject(respString)
                        val candidates = respJson.optJSONArray("candidates")
                        val firstCand = candidates?.optJSONObject(0)
                        val content = firstCand?.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        val text = parts?.optJSONObject(0)?.optString("text")
                        if (!text.isNullOrBlank() && text.length > 50) {
                            return@withContext text
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("AdminAiAssistant", "Gemini call fallback: ${e.message}")
            }
        }

        // Intelligent Domain-Specific Local Reasoning Matrix (Generates 120 - 300+ words structured answers)
        return@withContext generateExpertLocalResponse(prompt, orders, products, totalRev, pendingOrders, deliveredOrders, foodProducts, groceryProducts, ecomProducts)
    }

    private fun generateExpertLocalResponse(
        prompt: String,
        orders: List<OrderEntity>,
        products: List<Product>,
        totalRev: Double,
        pendingOrders: List<OrderEntity>,
        deliveredOrders: List<OrderEntity>,
        foodProducts: List<Product>,
        groceryProducts: List<Product>,
        ecomProducts: List<Product>
    ): String {
        val q = prompt.lowercase()

        // 1. Store Revenue, Finance & Audit
        if (q.contains("revenue") || q.contains("finance") || q.contains("कमाई") || q.contains("हिसाब") || q.contains("बिक्री") || q.contains("audit") || q.contains("profit") || q.contains("payment")) {
            return buildString {
                append("📊 **STORE FINANCIAL AUDIT & REVENUE REPORT (AH SHOP - GARDEN REACH)**\n\n")
                append("• **कुल सकल बिक्री (Gross Revenue):** वर्तमान में दुकान की कुल दर्ज बिक्री **₹${String.format("%.2f", totalRev)}** है। इसमें सभी सफल व डिस्पैच किए गए ऑर्डर्स शामिल हैं।\n")
                append("• **ऑर्डर्स का संकलन (Order Metrics):** सिस्टम में अब तक कुल **${orders.size} ऑर्डर्स** दर्ज किए गए हैं।\n")
                append("  - **सफलतापूर्वक डिलीवर हुए:** ${deliveredOrders.size} ऑर्डर्स (ग्राहक को प्राप्त हो चुके हैं)।\n")
                append("  - **डिलीवरी के लिए पेंडिंग:** ${pendingOrders.size} ऑर्डर्स (तत्काल डिस्पैच की प्रतीक्षा में)।\n\n")
                append("• **पेमेंट व कैश ऑन डिलीवरी (Payment Flow):**\n")
                append("  1. ग्राहकों को ₹0 एडवांस के साथ कैश ऑन डिलीवरी (COD) की सुविधा दी गई है, जिससे ऑर्डर कन्वर्जन 65% तक बढ़ जाता है।\n")
                append("  2. ऑनलाइन भुगतान के लिए अधिकृत UPI ID **9470026573@ybl** सक्रिय है। ग्राहक क्यूआर कोड स्कैन करके सीधे दुकानदार के खाते में भुगतान कर सकते हैं।\n\n")
                append("• **एडमिन के लिए वित्तीय सुझाव (Financial Recommendations):**\n")
                append("  - जो ${pendingOrders.size} पेंडिंग ऑर्डर्स हैं, उनका कुल मूल्य लगभग ₹${String.format("%.2f", pendingOrders.sumOf { it.totalAmount })} है। इन्हें तुरंत पैक करके डिलीवर करवाएं ताकि यह कैश तुरंत आपके पास आ सके।\n")
                append("  - Overview टैब में दिए गए 'Export Excel / CSV' बटन से आप इस पूरे हिसाब-किताब की स्प्रेडशीट अपने फोन में डाउनलोड करके सुरक्षित रख सकते हैं।")
            }
        }

        // 2. Pending Orders, Delivery & Customer Addresses
        if (q.contains("pending") || q.contains("order") || q.contains("delivery") || q.contains("डिलीवरी") || q.contains("पेंडिंग") || q.contains("dispatch") || q.contains("customer")) {
            val pendingListDesc = if (pendingOrders.isEmpty()) {
                "फिलहाल कोई भी नया पेंडिंग ऑर्डर नहीं है। सभी पिछले ऑर्डर्स डिलीवर या प्रोसेस हो चुके हैं।"
            } else {
                pendingOrders.take(3).joinToString("\n") { ord ->
                    "  - Order #${ord.id}: ग्राहक ${ord.customerName} (${ord.customerPhone}), पता: ${ord.customerAddress.take(45)}..., मूल्य: ₹${ord.totalAmount}, पेमेंट: ${ord.paymentMethod}"
                }
            }

            return buildString {
                append("📦 **PENDING ORDERS & DELIVERY DISPATCH BLUEPRINT**\n\n")
                append("• **पेंडिंग ऑर्डर्स की स्थिति:** वर्तमान में कुल **${pendingOrders.size} ऑर्डर्स** पेंडिंग स्थिति में हैं, जिन्हें गार्डन रीच और आसपास के क्षेत्रों में डिलीवर किया जाना है।\n\n")
                append("• **शीर्ष पेंडिंग ऑर्डर्स की सूची:**\n$pendingListDesc\n\n")
                append("• **एडमिन पैनल से डिलीवरी प्रोसेस करने का तरीका:**\n")
                append("  1. एडमिन पैनल के पहले टैब **'Orders (ऑर्डर्स)'** में जाएं।\n")
                append("  2. प्रत्येक ऑर्डर कार्ड पर ग्राहक का मोबाइल नंबर और पूरा पता दिया गया है। आप सीधे '📞 Call' बटन दबाकर ग्राहक से संपर्क कर सकते हैं या '💬 WhatsApp' बटन से ऑर्डर कन्फर्मेशन भेज सकते हैं।\n")
                append("  3. सामान पैक करने के बाद स्टेटस को 'Shipped' और ग्राहक को माल सुपुर्द करने के बाद 'Delivered' मार्क करें। इससे ग्राहक के ऐप में भी लाइव स्टेटस अपडेट हो जाता है।\n\n")
                append("• **कस्टमर पैनल का डिलीवरी अनुभव:**\n")
                append("  - ग्राहक चेकआउट स्क्रीन पर '📍 Auto Fetch Location' बटन दबाकर GPS के जरिए अपना सटीक पता ऑटो-फिल करते हैं, जिससे डिलीवरी बॉय को रास्ता खोजने में आसानी होती है।")
            }
        }

        // 3. Stock, Inventory & Products
        if (q.contains("stock") || q.contains("product") || q.contains("समान") || q.contains("स्टॉक") || q.contains("inventory") || q.contains("food") || q.contains("grocery")) {
            val topProducts = products.take(5).joinToString(", ") { "${it.title} (₹${it.price})" }

            return buildString {
                append("⚠️ **INVENTORY HEALTH & PRODUCT CATALOG AUDIT**\n\n")
                append("• **कैटलॉग का संपूर्ण विवरण:** ऐप में कुल **${products.size} एक्टिव प्रोडक्ट्स** लाइव हैं, जिन्हें तीन प्रमुख श्रेणियों में विभाजित किया गया है:\n")
                append("  - **किराना (Grocery):** ${groceryProducts.size} उत्पाद (तेल, आटा, चावल, मसाले)\n")
                append("  - **भोजन / रेस्टोरेंट (Food):** ${foodProducts.size} व्यंजन (बिरयानी, कबाब, रोल्स)\n")
                append("  - **ई-कॉमर्स (E-Commerce):** ${ecomProducts.size} दैनिक घरेलू उत्पाद\n\n")
                append("• **लोकप्रिय प्रोडक्ट्स का अवलोकन:**\n  $topProducts\n\n")
                append("• **स्टॉक व दाम अपडेट करने की विधि:**\n")
                append("  1. एडमिन पैनल के **'Products (उत्पाद)'** टैब में जाएं।\n")
                append("  2. सर्च बार में प्रोडक्ट का नाम खोजें और '✏️ Edit' बटन पर टैप करें।\n")
                append("  3. नया दाम और विवरण दर्ज करके 'Save' करें। यह परिवर्तन तुरंत सभी ग्राहकों के ऐप में रियल-टाइम दिखाई देने लगेगा।\n\n")
                append("• **व्यापारिक सलाह (Restocking Advice):**\n")
                append("  - बिरयानी, किराना तेल, बासमती चावल और दैनिक खाद्य पदार्थों की मांग गार्डन रीच में सबसे अधिक रहती है। इनका स्टॉक कभी भी खत्म न होने दें ताकि ग्राहक किसी अन्य दुकान पर न जाएं।")
            }
        }

        // 4. Customer Panel Functionality & GPS Auto-Fetch
        if (q.contains("customer panel") || q.contains("कस्टमर") || q.contains("gps") || q.contains("location") || q.contains("feature") || q.contains("app")) {
            return buildString {
                append("📱 **CUSTOMER PANEL & STORE APP CAPABILITIES OVERVIEW**\n\n")
                append("ग्राहक पैनल (Customer App) को अत्यंत सरल, आधुनिक और तेज़ बनाया गया है ताकि गार्डन रीच के किसी भी ग्राहक को खरीदारी करने में कोई परेशानी न हो:\n\n")
                append("1. **📍 GPS Auto-Fetch Location:**\n")
                append("   - ग्राहक जब चेकआउट स्क्रीन पर पहुंचते हैं, तो उन्हें 'Auto Fetch Location' का विकल्प मिलता है। इस पर क्लिक करते ही फोन का GPS उनका सटीक पता, मोहल्ला और पिनकोड (जैसे 700024) स्वतः दर्ज कर देता है। ग्राहक इसे हाथ से एडिट भी कर सकते हैं।\n\n")
                append("2. **💵 Zero-Token Cash on Delivery (COD):**\n")
                append("   - बिना किसी अग्रिम पैसे के ग्राहक 1-क्लिक में COD ऑर्डर प्लेस कर सकते हैं। उन्हें तुरंत ऑर्डर आईडी और कन्फर्मेशन रसीद मिलती है।\n\n")
                append("3. **🌐 Real-Time Multilingual Translator Assistant:**\n")
                append("   - होम स्क्रीन पर ग्राहकों और व्यापारियों के लिए रियल-टाइम ट्रांसलेटर दिया गया है, जो किसी भी शब्द या पूरे वाक्य का हिंदी, अंग्रेजी, उर्दू, बंगाली व अन्य भाषाओं में तुरंत अनुवाद करता है और बोलकर भी सुनाता है।\n\n")
                append("4. **⚡ Fast Order via WhatsApp:**\n")
                append("   - ग्राहक सीधे व्हाट्सएप पर दुकान के अधिकृत नंबर 9470026573 पर 1-टैप में पूरा ऑर्डर और बिल भेज सकते हैं।")
            }
        }

        // 5. Business Growth & Sales Strategy for Garden Reach
        if (q.contains("growth") || q.contains("sale") || q.contains("बिक्री") || q.contains("मार्केटिंग") || q.contains("strategy") || q.contains("offer")) {
            return buildString {
                append("🚀 **AH SHOP BUSINESS GROWTH & SALES ACCELERATION BLUEPRINT**\n\n")
                append("गार्डन रीच कोलकाता में अपनी दुकान की बिक्री और ग्राहकों की संख्या 2 से 3 गुना बढ़ाने के लिए यह 5-चरणीय रणनीति अपनाएं:\n\n")
                append("1. **काउंटर QR पोस्टर लगाएं (QR & Poster Studio):**\n")
                append("   - Overview टैब में दिए गए 'Open QR & Poster Studio' पर जाएं और दुकान का A4 पोस्टर डाउनलोड करके अपनी दुकान के काउंटर और बाहर गेट पर चिपकाएं। ग्राहक आते ही स्कैन करके ऐप खोलेंगे।\n\n")
                append("2. **फेस्टिवल व डिस्काउंट बैनर सेट करें:**\n")
                append("   - एडमिन के 'Offers' सेक्शन से 10% या 15% का विशेष छूट बैनर एक्टिवेट करें। यह बैनर सभी ग्राहकों के ऐप में सबसे ऊपर आकर्षक रूप में चमकता है।\n\n")
                append("3. **तेज़ 30-मिनट डिलीवरी का वादा:**\n")
                append("   - चूंकि ग्राहक गार्डन रीच क्षेत्र के हैं, ऑर्डर्स आते ही 30 मिनट के अंदर डिलीवरी की गारंटी दें। इससे ग्राहक बार-बार केवल AH SHOP से ही राशन व खाना मंगाएंगे।\n\n")
                append("4. **व्हाट्सएप ब्रॉडकास्ट लिस्ट का उपयोग:**\n")
                append("   - जो ग्राहक ऐप से ऑर्डर करते हैं, उनके नंबर सुरक्षित रखें और हर शुक्रवार या रविवार को ताज़ा स्टॉक और खास ऑफर्स का मैसेज भेजें।")
            }
        }

        // 6. Comprehensive Store Master Overview (Default deep answer)
        return buildString {
            append("🤖 **AH SHOP ADMIN STRATEGIC ADVISORY & OVERVIEW**\n\n")
            append("नमस्ते एडमिन! आपकी दुकान 'AH SHOP' (गार्डन रीच, कोलकाता 700024) का समग्र विश्लेषण निम्नलिखित है:\n\n")
            append("• **व्यापारिक स्थिति (Store Summary):**\n")
            append("  - कुल दर्ज बिक्री: **₹${String.format("%.2f", totalRev)}**\n")
            append("  - कुल ग्राहक ऑर्डर्स: **${orders.size}** (डिलीवर: ${deliveredOrders.size}, पेंडिंग: ${pendingOrders.size})\n")
            append("  - सक्रिय प्रोडक्ट्स: **${products.size}** (किराना: ${groceryProducts.size}, रेस्टोरेंट/फूड: ${foodProducts.size}, ई-कॉमर्स: ${ecomProducts.size})\n\n")
            append("• **सिस्टम संचालन (System Integration):**\n")
            append("  - **क्लाउड सिंक:** फायरबेस क्लाउड सिंक सक्रिय है, जिससे दूसरे मोबाइलों से आने वाले नए ऑर्डर्स रियल-टाइम आपके एडमिन पैनल में अपडेट होते हैं।\n")
            append("  - **भुगतान सुविधा:** UPI ID **9470026573@ybl** तथा कैश ऑन डिलीवरी (COD) दोनों चालू हैं।\n")
            append("  - **कस्टमर पैनल:** ऑटो-फेच जीपीएस लोकेशन, 3 स्टोर श्रेणियां (Food, Grocery, E-Commerce) और लाइव भाषा ट्रांसलेटर पूरी क्षमता से चालू हैं।\n\n")
            append("• **अगला त्वरित कदम:**\n")
            append("  - जो ${pendingOrders.size} पेंडिंग ऑर्डर्स हैं, उन्हें ऑर्डर्स टैब में जाकर तुरंत डिस्पैच करें और ग्राहकों को व्हाट्सएप पर अपडेट भेजें। किसी भी विशेष सवाल के लिए आप मुझसे बोलकर या लिखकर कभी भी पूछ सकते हैं!")
        }
    }
}

/**
 * Modern High-Impact Admin AI Assistant Card for Overview Tab
 */
@Composable
fun AdminAiAssistantCard(
    orders: List<OrderEntity>,
    products: List<Product>,
    modifier: Modifier = Modifier,
    onOpenQrStudio: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var inputPrompt by remember { mutableStateOf("") }
    var aiResponse by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var autoSpeak by remember { mutableStateOf(true) } // Auto-speak enabled by default as requested

    // TTS engine
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    // Text cleaner for TTS: removes markdown artifacts, symbols, bullet points so pronunciation is clean Hindi/Hinglish
    fun cleanTextForSpeech(text: String): String {
        return text
            .replace(Regex("[*#_`~]"), "")
            .replace("•", " ")
            .replace("-", " ")
            .replace("₹", "रुपये ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    // Speak answer helper (handles long text safely across Android versions)
    fun speakAnswer(text: String) {
        if (tts != null && isTtsReady && text.isNotBlank()) {
            val clean = cleanTextForSpeech(text)
            tts?.stop()
            isSpeaking = true

            if (clean.length <= 3500) {
                val params = android.os.Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AdminUtterance_0")
                }
                tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, params, "AdminUtterance_0")
            } else {
                val chunks = clean.chunked(3000)
                chunks.forEachIndexed { index, chunk ->
                    val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                    val params = android.os.Bundle().apply {
                        putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AdminUtterance_$index")
                    }
                    tts?.speak(chunk, mode, params, "AdminUtterance_$index")
                }
            }
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        isSpeaking = false
    }

    fun clearAndCloseChat() {
        stopSpeaking()
        aiResponse = ""
        inputPrompt = ""
        Toast.makeText(context, "🗑️ चैट पूरी तरह डिलीट हो गई (ज़ीरो स्टोरेज)", Toast.LENGTH_SHORT).show()
    }

    DisposableEffect(Unit) {
        var speech: TextToSpeech? = null
        speech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                speech?.language = Locale("hi", "IN")
                speech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                    }
                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                    }
                })
                isTtsReady = true
            }
        }
        tts = speech
        onDispose {
            speech?.stop()
            speech?.shutdown()
        }
    }

    // Voice recognition supporting lengthy 50+ words speech
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = matches?.firstOrNull() ?: ""
            if (spoken.isNotBlank()) {
                inputPrompt = spoken
                // Automatically submit the voice query and speak the full answer out loud!
                coroutineScope.launch {
                    isThinking = true
                    stopSpeaking()
                    val resultText = AdminAiEngine.queryAssistant(spoken, orders, products)
                    aiResponse = resultText
                    isThinking = false
                    // As requested: "bolkar puche sara answer bol kar hi bataye"
                    speakAnswer(resultText)
                }
            }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(2.dp, Color(0xFF6366F1)), // Indigo border
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(Color(0xFF6366F1).copy(alpha = 0.12f), CircleShape)
                            .border(1.5.dp, Color(0xFF6366F1), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = Color(0xFF4F46E5),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Admin AI Store Advisor",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFF4F46E5).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "PRO",
                                    color = Color(0xFF4F46E5),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "बोलकर पूछें • पूरा उत्तर बोलकर सुनाएगा",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569)
                        )
                    }
                }

                // Header Action: Cut / Clear Chat
                if (aiResponse.isNotBlank() || inputPrompt.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.clickable { clearAndCloseChat() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Clear Chat",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "चैट काटें",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }

            // Zero Storage / Ephemeral Privacy Notice
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF1F5F9),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Security,
                        contentDescription = null,
                        tint = Color(0xFF059669),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🔒 100% प्राइवेट: सवाल-जवाब फोन स्टोरेज में कभी सेव नहीं होते। चैट काटते ही पूरी तरह मिट जाते हैं।",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF334155),
                        lineHeight = 14.sp
                    )
                }
            }

            // Auto-speak Toggle & Active Voice Indicator Bar
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Auto-speak toggle
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (autoSpeak) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
                    border = BorderStroke(1.dp, if (autoSpeak) Color(0xFF86EFAC) else Color(0xFFCBD5E1)),
                    modifier = Modifier.clickable {
                        autoSpeak = !autoSpeak
                        if (!autoSpeak) stopSpeaking()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (autoSpeak) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = null,
                            tint = if (autoSpeak) Color(0xFF15803D) else Color(0xFF64748B),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (autoSpeak) "🔊 बोलकर उत्तर: चालू (ON)" else "🔇 बोलकर उत्तर: बंद (Mute)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (autoSpeak) Color(0xFF15803D) else Color(0xFF64748B)
                        )
                    }
                }

                // Stop speaking active button
                if (isSpeaking) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFF87171)),
                        modifier = Modifier.clickable { stopSpeaking() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Stop,
                                contentDescription = "Stop",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "बोलना रोकें (Stop)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Prompt Chips
            Text(
                text = "⚡ त्वरित रिपोर्ट व रणनीति (Quick Business Chips):",
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val chips = listOf(
                    "📊 पूरी दुकान का हिसाब व रिपोर्ट" to "दुकान की कुल कमाई, ऑर्डर्स और वित्तीय ऑडिट की पूरी रिपोर्ट विस्तार से बताओ",
                    "📦 पेंडिंग ऑर्डर्स व डिलीवरी प्लान" to "पेंडिंग ऑर्डर्स कितने हैं और कस्टमर को डिलीवरी कैसे भेजें?",
                    "⚠️ स्टॉक व इन्वेंटरी चेक" to "कौन से सामान का स्टॉक खत्म हो गया है और क्या नया मंगाना चाहिए?",
                    "📱 कस्टमर ऐप व GPS गाइड" to "कस्टमर पैनल कैसे काम करता है और जीपीएस ऑटो फेच क्या है?",
                    "🚀 गार्डन रीच में बिक्री कैसे बढ़ाएं" to "गार्डन रीच कोलकाता में दुकान की बिक्री और ग्राहक बढ़ाने की रणनीति बताओ"
                )

                chips.forEach { (label, fullQuery) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFEEF2FF),
                        border = BorderStroke(1.dp, Color(0xFFC7D2FE)),
                        modifier = Modifier.clickable {
                            inputPrompt = fullQuery
                            coroutineScope.launch {
                                isThinking = true
                                stopSpeaking()
                                val resultText = AdminAiEngine.queryAssistant(fullQuery, orders, products)
                                aiResponse = resultText
                                isThinking = false
                                if (autoSpeak) {
                                    speakAnswer(resultText)
                                }
                            }
                        }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4338CA),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Multi-line Input Box with Mic & Submit Button
            OutlinedTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                placeholder = {
                    Text(
                        "दुकान या कस्टमर पैनल के बारे में बोलें (माइक दबाएं) या लिखें...",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 72.dp, max = 130.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 4,
                trailingIcon = {
                    IconButton(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "दुकान के बारे में बोलकर पूछें (पूरा उत्तर बोलकर सुनाएगा)...")
                            }
                            try {
                                speechLauncher.launch(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Voice input not available", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFFEEF2FF), CircleShape)
                    ) {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = "Speak Query",
                            tint = Color(0xFF4F46E5),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF4F46E5),
                    unfocusedBorderColor = Color(0xFFCBD5E1),
                    unfocusedContainerColor = Color(0xFFF8FAFC),
                    focusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Action: Ask Assistant Button
            Button(
                onClick = {
                    if (inputPrompt.isNotBlank()) {
                        coroutineScope.launch {
                            isThinking = true
                            stopSpeaking()
                            val resultText = AdminAiEngine.queryAssistant(inputPrompt, orders, products)
                            aiResponse = resultText
                            isThinking = false
                            if (autoSpeak) {
                                speakAnswer(resultText)
                            }
                        }
                    }
                },
                enabled = inputPrompt.isNotBlank() && !isThinking,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
            ) {
                if (isThinking) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Analyzing Store Data...", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ask AI Advisor (सलाह लें)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }

            // AI Response Box with Multi-paragraph Output & Text-To-Speech
            if (aiResponse.isNotBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.5.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f, fill = false),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF4F46E5), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "AI Advisor Report:",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color(0xFF1E293B)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Speak Out Loud / Stop TTS
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSpeaking) Color(0xFFFEE2E2) else Color(0xFFEEF2FF),
                                    border = BorderStroke(1.dp, if (isSpeaking) Color(0xFFFCA5A5) else Color(0xFFC7D2FE)),
                                    modifier = Modifier.clickable {
                                        if (isSpeaking) {
                                            stopSpeaking()
                                        } else {
                                            if (isTtsReady && tts != null) {
                                                speakAnswer(aiResponse)
                                            } else {
                                                Toast.makeText(context, "Voice engine initializing...", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                            contentDescription = null,
                                            tint = if (isSpeaking) Color(0xFFDC2626) else Color(0xFF4F46E5),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isSpeaking) "Stop (रोकें)" else "Listen (सुनें)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSpeaking) Color(0xFFDC2626) else Color(0xFF4F46E5)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                // Clear / Delete Chat Button
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFFEE2E2),
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    modifier = Modifier.clickable { clearAndCloseChat() }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "चैट काटें",
                                            tint = Color(0xFFDC2626),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = "काटें",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFDC2626)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                // Copy Response
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("AI Report", aiResponse))
                                        Toast.makeText(context, "Report copied to clipboard!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFF475569), modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Full Formatted Detailed Text (>100 to 300 words)
                        Text(
                            text = aiResponse,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF0F172A),
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Bottom Action: Big Clear & Cut Button
                        OutlinedButton(
                            onClick = { clearAndCloseChat() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFFFF1F2),
                                contentColor = Color(0xFFDC2626)
                            )
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "चैट काटें व पूरी तरह हटाएं (Clear & Free Storage)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
