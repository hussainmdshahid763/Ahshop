package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.api.ChatMessage
import com.example.ui.viewmodel.ShopViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiHubScreen(
    viewModel: ShopViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    // Initialize TextToSpeech for Voice conversations
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    DisposableEffect(Unit) {
        val ttsInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Try Hindi first, then English India
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.ENGLISH
                }
            }
        }
        tts = ttsInstance
        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AH AI Voice Assistant",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = NordicMidnightIndigo
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    "Live Voice",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Garden Reach, Kolkata • बोलकर सामान व सहायता पूछें",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("ai_hub_back_button")) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = NordicMidnightIndigo
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NordicOffWhite)
        ) {
            LiveVoiceTab(viewModel, tts)
        }
    }
}

// -----------------------------------------------------------------------------------------
// LIVE VOICE CONVERSATIONS (gemini-3.1-flash-live-preview + TTS)
// -----------------------------------------------------------------------------------------
@Composable
fun LiveVoiceTab(viewModel: ShopViewModel, tts: TextToSpeech?) {
    val transcript by viewModel.liveVoiceTranscript.collectAsStateWithLifecycle()
    val response by viewModel.liveVoiceResponse.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLiveVoiceLoading.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Voice recognition launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenTextList = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = spokenTextList?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                viewModel.sendLiveVoiceQuery(spoken) { reply ->
                    tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "LiveVoiceUtterance")
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = AccentGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Live Voice Mode (gemini-3.1-flash-live-preview)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NordicMidnightIndigo
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "माइक बटन दबाएं और बोलें। AI तुरंत आवाज़ में उत्तर देगा।",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        // Center Voice Visualizer & Transcript
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Pulsing Mic Circle
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val pulseScale by infiniteTransition.animateFloat(
                initialValue = 1f,
                targetValue = if (isLoading) 1.25f else 1.05f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulseScale"
            )

            Box(
                modifier = Modifier
                    .size(110.dp)
                    .background(
                        NordicMidnightIndigo.copy(alpha = if (isLoading) 0.2f else 0.08f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "किराना सामान या रेसिपी बोलें...")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Voice recognition not available on this device", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .size((74 * pulseScale).dp)
                        .background(NordicMidnightIndigo, CircleShape)
                        .testTag("live_voice_mic_button")
                ) {
                    Icon(
                        if (isLoading) Icons.Default.Hearing else Icons.Default.Mic,
                        contentDescription = "Speak",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                if (isLoading) "AI सुन रहा है और उत्तर बना रहा है..." else "माइक दबाकर बोलें",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = NordicMidnightIndigo
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Last Spoken & Response
            if (transcript.isNotBlank()) {
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("आपने पूछा: \"$transcript\"", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E293B))
                        if (response.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    response,
                                    fontSize = 13.sp,
                                    color = Color(0xFF0F172A),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Spoken Prompts
        Column(modifier = Modifier.fillMaxWidth()) {
            Text("या इन पर टैप करके आवाज़ सुनें:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val q = "आज की सबसे ताज़ा सब्जियाँ क्या हैं?"
                        viewModel.sendLiveVoiceQuery(q) { r -> tts?.speak(r, TextToSpeech.QUEUE_FLUSH, null, "DealUtterance") }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("ताज़ा सब्ज़ी भाव", fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        val q = "गार्डन रीच में फ्री होम डिलीवरी कितने रुपये के ऑर्डर पर है?"
                        viewModel.sendLiveVoiceQuery(q) { r -> tts?.speak(r, TextToSpeech.QUEUE_FLUSH, null, "DeliveryUtterance") }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("डिलीवरी नियम", fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

