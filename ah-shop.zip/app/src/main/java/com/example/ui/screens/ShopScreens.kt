package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.CartItemEntity
import com.example.data.local.OrderEntity
import com.example.data.model.Product
import com.example.ui.components.ProductVisualDrawing
import com.example.ui.components.ProductImageView
import com.example.ui.components.TranslatorAssistantCard
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.ShopViewModel
import com.example.ui.viewmodel.SortBy
import com.example.util.AppLanguage
import com.example.util.LanguageManager
import com.example.util.QrCodeGenerator
import com.example.util.StoreConstants
import java.util.Locale

// Custom Theme colors
val NordicMidnightIndigo = Color(0xFF1E2E5D)
val AccentWarmSand = Color(0xFFD49E35)
val NordicOffWhite = Color(0xFFF1F5F9) // Slate-100 for eye-friendly contrast, never washed-out flat white
val CleanDark = Color(0xFF0F172A)
val AccentGreen = Color(0xFF15803D)
val TextBoldSlate = Color(0xFF0F172A)
val TextSubtitleBold = Color(0xFF1E293B)
val BorderSlate = Color(0xFFCBD5E1)

@Composable
fun LanguageSelectionDialog(
    currentLang: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Translate, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Choose Language (भाषा चुनें)",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = NordicMidnightIndigo
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLanguage.entries.forEach { lang ->
                    val isSelected = lang == currentLang
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) NordicMidnightIndigo.copy(alpha = 0.08f) else Color.White,
                        border = BorderStroke(1.5.dp, if (isSelected) NordicMidnightIndigo else Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectLanguage(lang)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = lang.flagEmoji, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = lang.nativeName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = NordicMidnightIndigo
                                    )
                                    Text(
                                        text = lang.displayName,
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close (बंद करें)", fontWeight = FontWeight.Bold, color = NordicMidnightIndigo)
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp)
    )
}

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainShopLayout(viewModel: ShopViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalCartCount = cartItems.sumOf { it.quantity }
    val currentLanguage by LanguageManager.currentLanguage.collectAsStateWithLifecycle()

    Scaffold(
        bottomBar = {
            if (shouldShowBottomBar(currentScreen)) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("app_navigation_bar")
                ) {
                    val isHome = currentScreen == Screen.Main || currentScreen is Screen.ProductDetail
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        selected = isHome,
                        onClick = { viewModel.navigateTo(Screen.Main) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NordicMidnightIndigo,
                            selectedTextColor = NordicMidnightIndigo,
                            indicatorColor = NordicMidnightIndigo.copy(alpha = 0.12f)
                        )
                    )

                    val isFavs = currentScreen == Screen.Favorites
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "Favorites") },
                        label = { Text("Favorites") },
                        selected = isFavs,
                        onClick = { viewModel.navigateTo(Screen.Favorites) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NordicMidnightIndigo,
                            selectedTextColor = NordicMidnightIndigo,
                            indicatorColor = NordicMidnightIndigo.copy(alpha = 0.12f)
                        )
                    )

                    val isCart = currentScreen == Screen.Cart || currentScreen == Screen.Checkout || currentScreen is Screen.OrderSuccess
                    NavigationBarItem(
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (totalCartCount > 0) {
                                        Badge(containerColor = AccentWarmSand) {
                                            Text(
                                                text = totalCartCount.toString(),
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                            }
                        },
                        label = { Text("Cart") },
                        selected = isCart,
                        onClick = { viewModel.navigateTo(Screen.Cart) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NordicMidnightIndigo,
                            selectedTextColor = NordicMidnightIndigo,
                            indicatorColor = NordicMidnightIndigo.copy(alpha = 0.12f)
                        )
                    )

                    val isOrders = currentScreen == Screen.Orders
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.History, contentDescription = "Orders") },
                        label = { Text("Orders") },
                        selected = isOrders,
                        onClick = { viewModel.navigateTo(Screen.Orders) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NordicMidnightIndigo,
                            selectedTextColor = NordicMidnightIndigo,
                            indicatorColor = NordicMidnightIndigo.copy(alpha = 0.12f)
                        )
                    )

                    val isProfile = currentScreen == Screen.Profile
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile") },
                        selected = isProfile,
                        onClick = { viewModel.navigateTo(Screen.Profile) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NordicMidnightIndigo,
                            selectedTextColor = NordicMidnightIndigo,
                            indicatorColor = NordicMidnightIndigo.copy(alpha = 0.12f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NordicOffWhite)
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    slideInHorizontally { width -> width } + fadeIn() with slideOutHorizontally { width -> -width } + fadeOut()
                },
                label = "ScreenTransition"
            ) { targetState ->
                when (targetState) {
                    is Screen.Main -> MainDashboardScreen(viewModel)
                    is Screen.ProductDetail -> ProductDetailScreen(viewModel, targetState.productId)
                    is Screen.Cart -> CartScreen(viewModel)
                    is Screen.Favorites -> FavoritesScreen(viewModel)
                    is Screen.Checkout -> CheckoutAndPaymentScreen(viewModel)
                    is Screen.Orders -> OrderHistoryScreen(viewModel)
                    is Screen.Profile -> ProfileScreen(viewModel)
                    is Screen.AiHub -> AiHubScreen(viewModel, onBack = { viewModel.navigateBack() })
                    is Screen.OrderSuccess -> OrderSuccessScreen(viewModel, targetState.orderNumber, targetState.totalAmount, targetState.itemsSummary, targetState.paymentMethod)
                    is Screen.AdminLogin -> AdminLoginScreen(viewModel)
                    is Screen.AdminDashboard -> AdminDashboardScreen(viewModel)
                }
            }
        }
    }
}

private fun shouldShowBottomBar(screen: Screen): Boolean {
    return when (screen) {
        is Screen.Checkout -> false
        is Screen.OrderSuccess -> false
        is Screen.AdminLogin -> false
        is Screen.AdminDashboard -> false
        is Screen.AiHub -> false
        else -> true
    }
}

// --- SCREEN 1: MAIN DASHBOARD ---

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainDashboardScreen(viewModel: ShopViewModel) {
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val activeCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val activeSort by viewModel.sortBy.collectAsStateWithLifecycle()
    val activePriceRange by viewModel.priceRange.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalCartCount = cartItems.sumOf { it.quantity }
    val cartSubtotal = cartItems.sumOf { it.price * it.quantity }

    var showTranslatorAssistant by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val currentOffer by viewModel.storeOffer.collectAsStateWithLifecycle()
    val activeSection by viewModel.selectedSection.collectAsStateWithLifecycle()

    val categories = when (activeSection) {
        "Food" -> listOf("All", "Biryani & Rice", "Rolls & Kebabs", "Chaat & Snacks", "Sweets & Desserts", "Beverages", "Mughlai")
        "E-Commerce" -> listOf("All", "Electronics & Mobile", "Fashion & Apparel", "Home & Kitchen", "Beauty & Personal Care", "Bags & Luggage")
        "All" -> listOf("All", "Vegetables", "Fruits", "Dairy", "Grains", "Biryani & Rice", "Electronics & Mobile", "Fashion & Apparel")
        else -> listOf("All", "Vegetables", "Fruits", "Dairy", "Grains", "Spices & Masala", "Snacks & Biscuits")
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // Welcome Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "AH SHOP",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = NordicMidnightIndigo,
                        letterSpacing = (-1).sp
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // AH SHOP AI Studio Icon Button
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AiHub) },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFFEDE9FE), CircleShape)
                            .testTag("home_ai_studio_button")
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "AH SHOP AI Studio & Assistant",
                            tint = Color(0xFF6366F1),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    // Direct WhatsApp Chat Icon Button
                    IconButton(
                        onClick = { StoreConstants.openWhatsApp(context) },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFF25D366), CircleShape)
                            .testTag("home_whatsapp_button")
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_whatsapp),
                            contentDescription = "Chat on WhatsApp (+91 8584016418)",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (viewModel.isAdminLoggedIn.value) {
                                viewModel.navigateTo(Screen.AdminDashboard)
                            } else {
                                viewModel.navigateTo(Screen.AdminLogin)
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .background(NordicMidnightIndigo.copy(alpha = 0.08f), CircleShape)
                            .testTag("home_admin_portal_button")
                    ) {
                        Icon(
                            Icons.Default.AdminPanelSettings,
                            contentDescription = "Store Admin Portal",
                            tint = NordicMidnightIndigo
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { showTranslatorAssistant = !showTranslatorAssistant },
                        modifier = Modifier
                            .size(38.dp)
                            .background(if (showTranslatorAssistant) NordicMidnightIndigo else Color.White, CircleShape)
                            .border(1.dp, if (showTranslatorAssistant) NordicMidnightIndigo else Color.LightGray.copy(alpha = 0.5f), CircleShape)
                            .testTag("translator_assistant_toggle_button")
                    ) {
                        Icon(
                            Icons.Default.Translate,
                            contentDescription = "Translator Assistant",
                            tint = if (showTranslatorAssistant) Color.White else NordicMidnightIndigo,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Search Bar (Streamlined, sleek & lightweight)
        item {
            TextField(
                value = query,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { 
                    Text(
                        "Search products, biryani, electronics...", 
                        fontWeight = FontWeight.Medium, 
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    ) 
                },
                leadingIcon = { 
                    Icon(
                        Icons.Default.Search, 
                        contentDescription = null, 
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    ) 
                },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF8FAFC),
                    unfocusedContainerColor = Color(0xFFF8FAFC),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextBoldSlate,
                    unfocusedTextColor = TextBoldSlate
                ),
                maxLines = 1,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .testTag("search_input_field")
            )
        }

        // Multilingual Translator Assistant (Replacing price filter)
        if (showTranslatorAssistant) {
            item {
                TranslatorAssistantCard(
                    onClose = { showTranslatorAssistant = false },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Horizontal visual Banner Carousel (Admin controlled - only shown if enabled)
        if (currentOffer.isEnabled) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clickable {
                            if (currentOffer.couponCode.isNotBlank()) {
                                viewModel.applyVoucherCode(currentOffer.couponCode)
                            }
                        }
                        .testTag("home_special_offer_banner"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NordicMidnightIndigo)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Box(
                                modifier = Modifier
                                    .background(AccentWarmSand, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = currentOffer.bannerTag.ifBlank { "SPECIAL OFFER" },
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = currentOffer.title,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 19.sp
                            )
                            if (currentOffer.couponCode.isNotBlank()) {
                                Text(
                                    text = "Coupon: ${currentOffer.couponCode} • Flat ₹${currentOffer.discountAmount.toInt()} OFF",
                                    color = AccentWarmSand,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(0.7f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalMall,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.size(90.dp)
                            )
                        }
                    }
                }
            }
        }

        // Primary Store Sections (Grocery, Food, E-Commerce)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Shop By Section / विभाग चुनें",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = NordicMidnightIndigo
                    )
                    Text(
                        text = "3 Main Stores",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val sections = listOf(
                        Triple("Grocery", "🛒 Grocery", "किराना स्टोर"),
                        Triple("Food", "🍽️ Food", "खाना & बिरयानी"),
                        Triple("E-Commerce", "🛍️ E-Commerce", "ऑनलाइन शॉपिंग"),
                        Triple("All", "🌟 All", "सब सामान")
                    )

                    sections.forEach { (secKey, secLabel, secHindi) ->
                        val isSelected = activeSection == secKey
                        val activeColor = when (secKey) {
                            "Food" -> Color(0xFFEA580C)
                            "E-Commerce" -> Color(0xFF4F46E5)
                            "All" -> Color(0xFF0D9488)
                            else -> NordicMidnightIndigo
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) activeColor else Color.White,
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) activeColor else BorderSlate
                            ),
                            shadowElevation = if (isSelected) 3.dp else 1.dp,
                            modifier = Modifier
                                .clickable {
                                    viewModel.selectedSection.value = secKey
                                    viewModel.selectedCategory.value = "All"
                                }
                                .testTag("section_pill_${secKey.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = secLabel,
                                    color = if (isSelected) Color.White else TextBoldSlate,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = secHindi,
                                    color = if (isSelected) Color.White.copy(alpha = 0.9f) else Color(0xFF64748B),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Categories Horizontal Scrollable List
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = activeCategory == category
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NordicMidnightIndigo else Color.White)
                            .border(
                                width = 1.5.dp,
                                color = if (isSelected) NordicMidnightIndigo else BorderSlate,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.selectedCategory.value = category }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .testTag("category_pill_${category.lowercase().replace(" ", "_")}")
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) Color.White else TextBoldSlate,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Product Grid count header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${products.size} Products Available",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )
                if (activeCategory != "All") {
                    Text(
                        text = "Category: $activeCategory",
                        fontSize = 12.sp,
                        color = AccentWarmSand,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Grid of e-commerce items
        if (products.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(64.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No products found",
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Try searching in English or Hindi (e.g., आलू, Onion, Dairy)",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            val chunks = products.chunked(2)
            items(chunks) { rowOfTwo ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    rowOfTwo.forEach { product ->
                        val productCartQty = cartItems.filter { it.productId == product.id }.sumOf { it.quantity }
                        Box(modifier = Modifier.weight(1f)) {
                            ProductItemCard(
                                product = product,
                                onClick = {
                                    viewModel.navigateTo(Screen.ProductDetail(product.id))
                                },
                                onFavoriteClick = {
                                    viewModel.toggleFavorite(product.id)
                                },
                                isFav = viewModel.favorites.collectAsStateWithLifecycle().value.any { it.productId == product.id },
                                cartQty = productCartQty,
                                onAddToCart = {
                                    viewModel.addOneToCart(product)
                                },
                                onRemoveFromCart = {
                                    viewModel.removeOneFromCart(product)
                                }
                            )
                        }
                    }
                    if (rowOfTwo.size == 1) {
                        Box(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(if (totalCartCount > 0) 90.dp else 16.dp)) }
    }

    // Floating Quick Cart Bar (Allows one-by-one shopping with instant checkout jump)
    AnimatedVisibility(
        visible = totalCartCount > 0,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NordicMidnightIndigo),
            elevation = CardDefaults.cardElevation(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.Cart) }
                .testTag("floating_quick_cart_bar")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(AccentWarmSand, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        val priceStr = if (cartSubtotal % 1.0 == 0.0) cartSubtotal.toInt().toString() else String.format(java.util.Locale.ENGLISH, "%.2f", cartSubtotal)
                        Text(
                            text = "$totalCartCount Items | ₹$priceStr",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "सामान कार्ट में जुड़ गया • Tap to View",
                            color = Color(0xFFCBD5E1),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color(0xFF25D366), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "View Cart",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    isFav: Boolean,
    cartQty: Int = 0,
    onAddToCart: () -> Unit = {},
    onRemoveFromCart: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, BorderSlate),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(Color(0xFFF8FAFC))
            ) {
                // Actual Product Image with Vector Canvas fallback
                ProductImageView(
                    product = product,
                    modifier = Modifier.fillMaxSize()
                )

                // Section badge overlay on top-left
                if (product.section.isNotBlank() && product.section != "Grocery") {
                    Surface(
                        color = if (product.section == "Food") Color(0xFFEA580C) else Color(0xFF4F46E5),
                        shape = RoundedCornerShape(bottomEnd = 8.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = if (product.section == "Food") "🍽️ Food" else "🛍️ E-Com",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Favorite round button overlay
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, BorderSlate, CircleShape)
                        .size(34.dp)
                ) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite Toggle",
                        tint = if (isFav) Color.Red else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                // Title
                Text(
                    text = product.title,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = TextBoldSlate
                )

                // Hindi Name
                if (product.hindiName.isNotBlank()) {
                    Text(
                        text = product.hindiName,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = Color(0xFFC2410C),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                // Ratings & Unit row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = AccentWarmSand, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(text = product.rating.toString(), fontSize = 11.sp, fontWeight = FontWeight.Black, color = TextBoldSlate)
                    }
                    if (product.unit.isNotBlank()) {
                        Text(
                            text = product.unit,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = AccentGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Price tag lines and Quick Add / Stepper
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        val displayPrice = if (product.price % 1.0 == 0.0) product.price.toInt().toString() else product.price.toString()
                        Text(
                            text = "₹$displayPrice",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = TextBoldSlate
                        )
                        if (product.originalPrice > product.price) {
                            val origPrice = if (product.originalPrice % 1.0 == 0.0) product.originalPrice.toInt().toString() else product.originalPrice.toString()
                            Text(
                                text = "₹$origPrice",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64748B),
                                textDecoration = TextDecoration.LineThrough
                            )
                        }
                    }

                    if (cartQty == 0) {
                        Button(
                            onClick = onAddToCart,
                            colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("quick_add_${product.id}")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("ADD", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color.White)
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(NordicMidnightIndigo, RoundedCornerShape(10.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clickable { onRemoveFromCart() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White, modifier = Modifier.size(15.dp))
                            }
                            Text(
                                text = cartQty.toString(),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clickable { onAddToCart() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 2: PRODUCT DETAIL ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(viewModel: ShopViewModel, productId: String) {
    val product = viewModel.getProductById(productId) ?: return

    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val isFav = favorites.any { it.productId == product.id }

    var selectedSize by remember { mutableStateOf(product.sizes.firstOrNull() ?: product.unit.ifBlank { "Standard" }) }
    var selectedColor by remember { mutableStateOf(product.colors.firstOrNull() ?: "Default") }
    var qtyCount by remember { mutableStateOf(1) }
    var showAddedNotification by remember { mutableStateOf(false) }

    val reviews = viewModel.getProductReviews(product.id)

    Column(modifier = Modifier.fillMaxSize()) {
        // Overlay Header
        TopAppBar(
            title = { Text("Product Details", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                IconButton(onClick = { viewModel.toggleFavorite(product.id) }) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Fav",
                        tint = if (isFav) Color.Red else NordicMidnightIndigo
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .background(Color.White)
        ) {
            // Detailed Product Drawing Canvas or Real Image
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(NordicOffWhite)
                        .padding(16.dp)
                ) {
                    ProductImageView(
                        product = product,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (product.section.isNotBlank()) {
                        Surface(
                            color = if (product.section == "Food") Color(0xFFEA580C) else if (product.section == "E-Commerce") Color(0xFF4F46E5) else NordicMidnightIndigo,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.align(Alignment.TopStart)
                        ) {
                            Text(
                                text = when (product.section) {
                                    "Food" -> "🍽️ Food Store / खाना"
                                    "E-Commerce" -> "🛍️ E-Commerce / शॉपिंग"
                                    else -> "🛒 Grocery Store / किराना"
                                },
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Specs
            item {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = product.category.uppercase(),
                            fontWeight = FontWeight.Bold,
                            color = AccentWarmSand,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                        if (product.subcategory.isNotBlank()) {
                            Text(
                                text = product.subcategory,
                                fontSize = 11.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.title,
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp,
                        color = NordicMidnightIndigo
                    )
                    if (product.hindiName.isNotBlank()) {
                        Text(
                            text = product.hindiName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.DarkGray
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Price & Rating specs in Rupees
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val dispPrice = if (product.price % 1.0 == 0.0) product.price.toInt().toString() else product.price.toString()
                            Text(
                                text = "₹$dispPrice",
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp,
                                color = NordicMidnightIndigo
                            )
                            if (product.unit.isNotBlank()) {
                                Text(
                                    text = " / ${product.unit}",
                                    fontSize = 14.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            if (product.originalPrice > product.price) {
                                Spacer(modifier = Modifier.width(8.dp))
                                val origP = if (product.originalPrice % 1.0 == 0.0) product.originalPrice.toInt().toString() else product.originalPrice.toString()
                                Text(
                                    text = "₹$origP",
                                    fontSize = 16.sp,
                                    textDecoration = TextDecoration.LineThrough,
                                    color = Color.LightGray
                                )
                            }
                        }

                        // Star badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(NordicOffWhite, RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = AccentWarmSand, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = product.rating.toString(), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "(${product.reviewsCount} reviews)", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Description text lines
                    Text(text = "Description", fontWeight = FontWeight.Bold, color = NordicMidnightIndigo, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = product.description,
                        color = Color.DarkGray,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Unit / Pack selector
                    if (product.sizes.isNotEmpty() && product.sizes.first() != "One Size") {
                        Text(text = "Select Pack / Quantity", fontWeight = FontWeight.Bold, color = NordicMidnightIndigo, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            product.sizes.forEach { sizeOption ->
                                val isSelected = selectedSize == sizeOption
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) NordicMidnightIndigo else NordicOffWhite)
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) Color.Transparent else Color.LightGray.copy(alpha = 0.5f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selectedSize = sizeOption }
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                        .testTag("size_option_$sizeOption")
                                ) {
                                    Text(
                                        text = sizeOption,
                                        color = if (isSelected) Color.White else Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Reviews Panel Accordion
                    Text(text = "Customer Feedback", fontWeight = FontWeight.Bold, color = NordicMidnightIndigo, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    reviews.forEach { r ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NordicOffWhite, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                                .padding(bottom = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = r.author, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NordicMidnightIndigo)
                                Text(text = r.date, fontSize = 10.sp, color = Color.Gray)
                            }
                            Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                repeat(5) { starIndex ->
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (starIndex < r.rating) AccentWarmSand else Color.LightGray,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                            Text(text = r.comment, fontSize = 12.sp, color = Color.DarkGray, lineHeight = 16.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // Floating Bottom Actions
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Quantity selectors
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(NordicOffWhite, RoundedCornerShape(14.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = { if (qtyCount > 1) qtyCount-- },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrement")
                    }
                    Text(
                        text = qtyCount.toString(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    IconButton(
                        onClick = { qtyCount++ },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increment")
                    }
                }

                val totalCartAdd = product.price * qtyCount
                val formattedTotal = if (totalCartAdd % 1.0 == 0.0) totalCartAdd.toInt().toString() else String.format("%.2f", totalCartAdd)

                if (!showAddedNotification) {
                    Button(
                        onClick = {
                            viewModel.addToCart(product, selectedSize, selectedColor, qtyCount)
                            showAddedNotification = true
                        },
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 16.dp)
                            .height(50.dp)
                            .testTag("add_to_cart_detail_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo)
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Add to Cart • ₹$formattedTotal", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showAddedNotification = false
                                viewModel.navigateBack()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("continue_shopping_button"),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.5.dp, NordicMidnightIndigo)
                        ) {
                            Text(text = "+ Keep Shopping", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NordicMidnightIndigo)
                        }
                        Button(
                            onClick = {
                                viewModel.navigateTo(Screen.Cart)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("view_cart_after_add_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                        ) {
                            Text(text = "View Cart →", fontWeight = FontWeight.Black, fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 3: INTERACTIVE CART ---

@Composable
fun CartScreen(viewModel: ShopViewModel) {
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val rawVoucher by viewModel.activeVoucher.collectAsStateWithLifecycle()
    val voucherErr by viewModel.voucherError.collectAsStateWithLifecycle()
    val currentOffer by viewModel.storeOffer.collectAsStateWithLifecycle()

    val subtotal = cartItems.sumOf { it.price * it.quantity }
    val discount = rawVoucher?.applyDiscount?.invoke(subtotal) ?: 0.0
    // Free delivery on orders over ₹499 or with SHIPFREE voucher
    val shipping = if (subtotal > 0.0 && subtotal < 499.0 && rawVoucher?.code != "SHIPFREE") 40.0 else 0.0
    val tax = 0.0 // Essential Groceries zero-rated tax in India
    val grandTotal = (subtotal - discount + shipping + tax).coerceAtLeast(0.0)

    var couponInput by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = "Shopping Cart",
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = NordicMidnightIndigo,
                modifier = Modifier.align(Alignment.CenterStart)
            )

            if (cartItems.isNotEmpty()) {
                Text(
                    text = "Clear All",
                    color = Color.Red,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .clickable { viewModel.clearCart() }
                )
            }
        }

        if (cartItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.RemoveShoppingCart,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = Color.LightGray
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Your shopping cart is empty", fontWeight = FontWeight.Bold, color = Color.Gray)
                Text(text = "Add fresh vegetables, fruits, or groceries!", fontSize = 12.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(Screen.Main) },
                    colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Explore Groceries")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                items(cartItems) { item ->
                    CartItemRow(item = item, viewModel = viewModel)
                }

                // Free shipping meter
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (subtotal >= 499.0) Color(0xFFE8F5E9) else Color(0xFFFFF8E1))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.LocalShipping,
                                contentDescription = null,
                                tint = if (subtotal >= 499.0) AccentGreen else AccentWarmSand,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (subtotal >= 499.0) "You unlocked FREE Home Delivery!" else "Add ₹${(499.0 - subtotal).toInt()} more for FREE Delivery",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (subtotal >= 499.0) AccentGreen else Color(0xFF8D6E63)
                            )
                        }
                    }
                }

                // Coupon box setup
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Text(text = "Discount Coupons", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NordicMidnightIndigo)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            if (currentOffer.isEnabled && currentOffer.couponCode.isNotBlank()) {
                                Text(
                                    "${currentOffer.couponCode} (₹${currentOffer.discountAmount.toInt()} off)",
                                    color = AccentWarmSand,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier
                                        .background(NordicOffWhite, RoundedCornerShape(6.dp))
                                        .clickable {
                                            couponInput = currentOffer.couponCode
                                            viewModel.applyVoucherCode(currentOffer.couponCode)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                "AHSHOP10 (10% off)",
                                color = AccentWarmSand,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .background(NordicOffWhite, RoundedCornerShape(6.dp))
                                    .clickable {
                                        couponInput = "AHSHOP10"
                                        viewModel.applyVoucherCode("AHSHOP10")
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                            Text(
                                "SHIPFREE (Free del)",
                                color = AccentWarmSand,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .background(NordicOffWhite, RoundedCornerShape(6.dp))
                                    .clickable {
                                        couponInput = "SHIPFREE"
                                        viewModel.applyVoucherCode("SHIPFREE")
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TextField(
                                value = couponInput,
                                onValueChange = { couponInput = it },
                                placeholder = { Text("Enter coupon code", fontSize = 12.sp) },
                                shape = RoundedCornerShape(10.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = NordicOffWhite,
                                    unfocusedContainerColor = NordicOffWhite,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                maxLines = 1,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("voucher_input_field")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    viewModel.applyVoucherCode(couponInput)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo)
                            ) {
                                Text("Apply")
                            }
                        }

                        // Code details responses
                        if (rawVoucher != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Applied: ${rawVoucher!!.code} (-₹${String.format("%.2f", discount)})",
                                    color = AccentGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Remove",
                                    color = Color.Red,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable {
                                        viewModel.removeVoucher()
                                        couponInput = ""
                                    }
                                )
                            }
                        } else if (voucherErr != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = voucherErr!!, color = Color.Red, fontSize = 11.sp)
                        }
                    }
                }

                // Pricing receipt invoice breakdown in Rupees
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Bill Details",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = NordicMidnightIndigo,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Item Total", color = Color.Gray, fontSize = 13.sp)
                            Text("₹${String.format("%.2f", subtotal)}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))

                        if (discount > 0.0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Coupon Savings", color = AccentGreen, fontSize = 13.sp)
                                Text("-₹${String.format("%.2f", discount)}", color = AccentGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Delivery Fee", color = Color.Gray, fontSize = 13.sp)
                            Text(
                                text = if (shipping == 0.0) "FREE" else "₹${String.format("%.2f", shipping)}",
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.sp,
                                color = if (shipping == 0.0) AccentGreen else Color.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("To Pay", fontWeight = FontWeight.Black, fontSize = 16.sp, color = NordicMidnightIndigo)
                            Text(
                                "₹${String.format("%.2f", grandTotal)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = NordicMidnightIndigo
                            )
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }

            // Checkout CTA
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(16.dp)
            ) {
                Button(
                    onClick = { viewModel.navigateTo(Screen.Checkout) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                        .height(52.dp)
                        .testTag("checkout_trigger_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo)
                ) {
                    Text(text = "Proceed to Checkout (₹${String.format("%.2f", grandTotal)})", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun CartItemRow(item: CartItemEntity, viewModel: ShopViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                ProductImageView(
                    imageUrl = item.imageUrl,
                    category = item.category,
                    imageIndex = item.imageIndex,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = NordicMidnightIndigo
                )
                Text(
                    text = if (item.selectedSize.isNotBlank()) item.selectedSize else item.category,
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                val itemPrice = if (item.price % 1.0 == 0.0) item.price.toInt().toString() else item.price.toString()
                Text(
                    text = "₹$itemPrice",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = NordicMidnightIndigo,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Quantity buttons steppers
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.background(NordicOffWhite, RoundedCornerShape(8.dp))
            ) {
                IconButton(
                    onClick = { viewModel.updateCartQty(item, isAddition = false) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                }
                Text(
                    text = item.quantity.toString(),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(
                    onClick = { viewModel.updateCartQty(item, isAddition = true) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = { viewModel.removeFromCart(item) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
            }
        }
    }
}

// --- SCREEN 4: FAVORITES SCREEN ---

@Composable
fun FavoritesScreen(viewModel: ShopViewModel) {
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val products = viewModel.filteredProducts.collectAsStateWithLifecycle().value

    val favList = products.filter { p -> favorites.any { f -> f.productId == p.id } }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(16.dp)
        ) {
            Text(
                text = "My Wishlist",
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = NordicMidnightIndigo
            )
        }

        if (favList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = Color.LightGray
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Your wishlist is empty", fontWeight = FontWeight.Bold, color = Color.Gray)
                Text(
                    text = "Save items to easily order them whenever you want",
                    fontSize = 12.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(10.dp)) }
                items(favList) { product ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(Screen.ProductDetail(product.id)) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                ProductImageView(product = product, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = product.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NordicMidnightIndigo)
                                if (product.hindiName.isNotBlank()) {
                                    Text(text = product.hindiName, fontSize = 12.sp, color = Color.Gray)
                                }
                                val pPrice = if (product.price % 1.0 == 0.0) product.price.toInt().toString() else product.price.toString()
                                Text(text = "₹$pPrice / ${product.unit}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AccentWarmSand)
                            }
                            IconButton(onClick = { viewModel.toggleFavorite(product.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.LightGray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 5: CHECKOUT SCREEN ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutAndPaymentScreen(viewModel: ShopViewModel) {
    val basket by viewModel.cartItems.collectAsStateWithLifecycle()
    val activeVoucher by viewModel.activeVoucher.collectAsStateWithLifecycle()

    val subtotal = basket.sumOf { it.price * it.quantity }
    val voucherDed = activeVoucher?.applyDiscount?.invoke(subtotal) ?: 0.0
    val shipping = if (subtotal > 0.0 && subtotal < 499.0 && activeVoucher?.code != "SHIPFREE") 40.0 else 0.0
    val tax = 0.0
    val grandTotal = (subtotal - voucherDed + shipping + tax).coerceAtLeast(0.0)

    val profileEntity by viewModel.profile.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var custName by remember { mutableStateOf("") }
    var custPhone by remember { mutableStateOf("") }
    var custAddress by remember { mutableStateOf("") }
    var custCityZip by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }
    var isLocating by remember { mutableStateOf(false) }
    var locationNotice by remember { mutableStateOf<String?>(null) }

    fun fetchCurrentLocation() {
        isLocating = true
        locationNotice = null
        try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (locationManager == null) {
                isLocating = false
                locationNotice = "Location service not available"
                return
            }
            val isGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            val isNet = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
            if (!isGps && !isNet) {
                isLocating = false
                locationNotice = "Please enable GPS / Location in device settings"
                return
            }

            fun populateAddress(lat: Double, lng: Double) {
                try {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    val list = geocoder.getFromLocation(lat, lng, 1)
                    if (!list.isNullOrEmpty()) {
                        val addr = list[0]
                        val fullLines = (0..addr.maxAddressLineIndex).mapNotNull { addr.getAddressLine(it) }.joinToString(", ")
                        if (fullLines.isNotBlank()) custAddress = fullLines
                        val city = addr.locality ?: addr.subAdminArea ?: ""
                        val pin = addr.postalCode ?: ""
                        val state = addr.adminArea ?: ""
                        val cZip = listOf(city, state, pin).filter { it.isNotBlank() }.joinToString(", ")
                        if (cZip.isNotBlank()) custCityZip = cZip
                        locationNotice = "Location auto-filled! You can also edit it manually."
                    } else {
                        custAddress = "Location: ${String.format(Locale.ENGLISH, "%.4f", lat)}, ${String.format(Locale.ENGLISH, "%.4f", lng)}"
                        locationNotice = "Coordinates detected. Please verify details."
                    }
                } catch (e: Exception) {
                    custAddress = "Location: ${String.format(Locale.ENGLISH, "%.4f", lat)}, ${String.format(Locale.ENGLISH, "%.4f", lng)}"
                    locationNotice = "Coordinates detected. Please verify details."
                }
                isLocating = false
            }

            var loc: Location? = null
            val fineOk = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarseOk = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fineOk || coarseOk) {
                if (isGps) loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if (loc == null && isNet) loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }

            if (loc != null) {
                populateAddress(loc.latitude, loc.longitude)
            } else if (fineOk || coarseOk) {
                val provider = if (isGps) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
                locationManager.requestSingleUpdate(
                    provider,
                    object : LocationListener {
                        override fun onLocationChanged(l: Location) {
                            populateAddress(l.latitude, l.longitude)
                        }
                        override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {
                            isLocating = false
                            locationNotice = "GPS was disabled"
                        }
                    },
                    Looper.getMainLooper()
                )
            } else {
                isLocating = false
                locationNotice = "Location permission needed"
            }
        } catch (e: Exception) {
            isLocating = false
            locationNotice = "Could not fetch location"
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == true || perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            fetchCurrentLocation()
        } else {
            locationNotice = "Location permission required to auto-fill address"
        }
    }

    val grandTotalStr = remember(grandTotal) {
        if (grandTotal % 1.0 == 0.0) grandTotal.toInt().toString() else String.format(java.util.Locale.ENGLISH, "%.2f", grandTotal)
    }

    // Pre-populate if customer has saved their personal details on this phone previously (never admin's address)
    LaunchedEffect(profileEntity) {
        val p = profileEntity
        if (p != null) {
            val isNotAdmin = p.name != "Shahid Hussain" && 
                             p.name != "Store Admin" && 
                             !p.phone.contains("8584016418") && 
                             !p.addressLine.contains("F-134/1")
            if (isNotAdmin) {
                if (custName.isBlank() && p.name.isNotBlank()) custName = p.name
                if (custPhone.isBlank() && p.phone.isNotBlank()) custPhone = p.phone
                if (custAddress.isBlank() && p.addressLine.isNotBlank()) custAddress = p.addressLine
                if (custCityZip.isBlank() && p.city.isNotBlank()) custCityZip = "${p.city} - ${p.postalCode}"
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("Checkout & Delivery", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("ऑर्डर व डिलीवरी विवरण", fontSize = 12.sp, color = Color.Gray)
                }
            },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Validation error banner if any
            if (validationError != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        border = BorderStroke(1.dp, Color(0xFFEF9A9A)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFC62828))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = validationError!!,
                                color = Color(0xFFC62828),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Part 1: Customer Delivery Details (Explicit Input - Never admin defaults)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "1. Delivery Details (डिलीवरी पता)",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = NordicMidnightIndigo
                                )
                                Text(
                                    text = "अपना नाम व सामान मंगाने का पता दर्ज करें",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Customer Name
                        OutlinedTextField(
                            value = custName,
                            onValueChange = {
                                custName = it
                                validationError = null
                            },
                            label = { Text("Full Name (आपका पूरा नाम)*", fontWeight = FontWeight.Bold) },
                            placeholder = { Text("e.g. Rahul Sharma / मोहम्मद इमरान") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = NordicMidnightIndigo) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_customer_name_input"),
                            shape = RoundedCornerShape(12.dp),
                            isError = validationError != null && custName.isBlank()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Customer Phone
                        OutlinedTextField(
                            value = custPhone,
                            onValueChange = {
                                custPhone = it.filter { char -> char.isDigit() || char == '+' || char == ' ' }
                                validationError = null
                            },
                            label = { Text("Mobile Number (मोबाइल नंबर)*", fontWeight = FontWeight.Bold) },
                            placeholder = { Text("10-अंकीय मोबाइल नंबर (e.g. 9876543210)") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = NordicMidnightIndigo) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_customer_phone_input"),
                            shape = RoundedCornerShape(12.dp),
                            isError = validationError != null && custPhone.trim().length < 10
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Auto-Fetch GPS Location Button
                        OutlinedButton(
                            onClick = {
                                val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                if (fine || coarse) {
                                    fetchCurrentLocation()
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                    )
                                }
                            },
                            enabled = !isLocating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                                .testTag("checkout_auto_fetch_location_button"),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1D4ED8)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            if (isLocating) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFF1D4ED8))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Fetching current GPS location...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF1D4ED8))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("📍 Auto Fetch Location (करंट लोकेशन से भरें)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (locationNotice != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = locationNotice!!,
                                fontSize = 11.sp,
                                color = if (locationNotice!!.contains("auto-filled", ignoreCase = true)) Color(0xFF15803D) else Color(0xFFB91C1C),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Delivery Address (Clean input for customer; location map arrow reserved for Admin)
                        OutlinedTextField(
                            value = custAddress,
                            onValueChange = {
                                custAddress = it
                                validationError = null
                            },
                            label = { Text("Complete Delivery Address (पूरा पता)*", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                            placeholder = { Text("मकान/फ्लैट नं., गली, सड़क, लैंडमार्क", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(20.dp)) },
                            minLines = 2,
                            maxLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_customer_address_input"),
                            shape = RoundedCornerShape(10.dp),
                            isError = validationError != null && custAddress.isBlank()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // City & Pincode
                        OutlinedTextField(
                            value = custCityZip,
                            onValueChange = { custCityZip = it },
                            label = { Text("Area / City & Pincode (क्षेत्र व पिनकोड)", fontSize = 13.sp) },
                            placeholder = { Text("Garden Reach, Kolkata - 700024", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(20.dp)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("checkout_customer_city_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }

            // Part 2: Payment Preference (Cash on Delivery)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = NordicMidnightIndigo, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2. Payment Method (भुगतान का प्रकार)",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = NordicMidnightIndigo
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Super Slim In-App Cash on Delivery card
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, AccentGreen.copy(alpha = 0.7f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    tint = AccentGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Cash on Delivery (COD)",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = NordicMidnightIndigo
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Surface(
                                    color = AccentGreen,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "Pay ₹$grandTotalStr on Arrival",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Part 3: Items rundown summary
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "3. Order Breakdown (बिल का विवरण)", fontWeight = FontWeight.Black, fontSize = 14.sp, color = NordicMidnightIndigo)
                        Spacer(modifier = Modifier.height(10.dp))
                        basket.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.quantity}x ${item.title}",
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                    color = Color.DarkGray
                                )
                                Text(text = "₹${String.format("%.2f", item.price * item.quantity)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray.copy(alpha = 0.4f))

                        if (voucherDed > 0.0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Coupon Discount", color = AccentGreen, fontSize = 12.sp)
                                Text("-₹${String.format("%.2f", voucherDed)}", color = AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Delivery Charges", color = Color.Gray, fontSize = 12.sp)
                            Text(
                                text = if (shipping == 0.0) "FREE" else "₹${String.format("%.2f", shipping)}",
                                color = if (shipping == 0.0) AccentGreen else Color.DarkGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Grand Total Due (कुल राशि)", fontWeight = FontWeight.Black, fontSize = 14.sp, color = NordicMidnightIndigo)
                            Text("₹${String.format("%.2f", grandTotal)}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = NordicMidnightIndigo)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }

        // Place Order Floating Bar (Sleek, lightweight & formatted)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            color = Color.White,
            shadowElevation = 4.dp,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // WhatsApp Fast Order Button
                Button(
                    onClick = {
                        val name = custName.trim()
                        val phone = custPhone.trim()
                        val addr = custAddress.trim()

                        if (name.isBlank()) {
                            validationError = "⚠️ कृपया अपना पूरा नाम दर्ज करें!"
                            return@Button
                        }
                        if (phone.length < 10) {
                            validationError = "⚠️ कृपया सही 10-अंकीय मोबाइल नंबर दर्ज करें!"
                            return@Button
                        }
                        if (addr.isBlank()) {
                            validationError = "⚠️ कृपया डिलीवरी के लिए पूरा पता दर्ज करें!"
                            return@Button
                        }

                        validationError = null
                        val fullAddress = if (custCityZip.isNotBlank()) "$addr, ${custCityZip.trim()}" else "$addr, Garden Reach, Kolkata - 700024"
                        val orderNo = "AH-${kotlin.random.Random.nextInt(100000, 999999)}"

                        // Send directly to WhatsApp with 100% English formatting & UPI QR links
                        StoreConstants.sendOrderToWhatsApp(
                            context = context,
                            orderId = orderNo,
                            customerName = name,
                            customerPhone = phone,
                            customerAddress = fullAddress,
                            items = basket,
                            grandTotal = grandTotal,
                            voucherCode = if (voucherDed > 0.0) "COUPON-APPLIED" else null,
                            paymentType = "WhatsApp Order (UPI / COD)"
                        )

                        // Save in database & cloud sync
                        viewModel.executeCheckout(
                            customerName = name,
                            customerPhone = phone,
                            customerAddress = fullAddress,
                            paymentMethod = "WhatsApp Order"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("place_order_whatsapp_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp),
                        contentDescription = "WhatsApp",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "⚡ Fast Order on WhatsApp",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }

                // In-App Confirm Order Button (Pure Cash on Delivery)
                Button(
                    onClick = {
                        val name = custName.trim()
                        val phone = custPhone.trim()
                        val addr = custAddress.trim()

                        if (name.isBlank()) {
                            validationError = "⚠️ कृपया अपना पूरा नाम दर्ज करें!"
                            return@Button
                        }
                        if (phone.length < 10) {
                            validationError = "⚠️ कृपया सही 10-अंकीय मोबाइल नंबर दर्ज करें!"
                            return@Button
                        }
                        if (addr.isBlank()) {
                            validationError = "⚠️ कृपया डिलीवरी के लिए पूरा पता दर्ज करें!"
                            return@Button
                        }

                        validationError = null
                        val fullAddress = if (custCityZip.isNotBlank()) "$addr, ${custCityZip.trim()}" else "$addr, Garden Reach, Kolkata - 700024"

                        viewModel.executeCheckout(
                            customerName = name,
                            customerPhone = phone,
                            customerAddress = fullAddress,
                            paymentMethod = "Cash on Delivery"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("place_order_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "✓ Place Order - Cash on Delivery (₹$grandTotalStr)",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// --- SCREEN 6: ORDER HISTORY ---

@Composable
fun OrderHistoryScreen(viewModel: ShopViewModel) {
    // Shows only orders placed from this mobile device or matching this user's profile phone
    val orderList by viewModel.myOrders.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .border(BorderStroke(1.dp, Color(0xFFF1F5F9)))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "My Orders",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = NordicMidnightIndigo
                    )
                    Text(
                        text = "Orders placed from this phone (${orderList.size})",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        if (orderList.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.History,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "No orders found on this device", fontWeight = FontWeight.Bold, color = Color(0xFF475569), fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "Orders placed from this phone will appear here.", fontSize = 12.sp, color = Color(0xFF94A3B8))
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(6.dp)) }

                items(orderList) { order ->
                    OrderHistoryItemCard(order)
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun OrderHistoryItemCard(order: OrderEntity) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = order.orderNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NordicMidnightIndigo)
                Box(
                    modifier = Modifier
                        .background(AccentGreen.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = order.status.uppercase(),
                        color = AccentGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(3.dp))
            val sdf = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault())
            val dateStr = sdf.format(java.util.Date(order.timestamp))
            Text(text = "Placed: $dateStr", fontSize = 11.sp, color = Color(0xFF64748B))

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Items:",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B)
            )
            Text(
                text = order.itemsSummary,
                fontSize = 12.sp,
                color = TextBoldSlate,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (order.customerAddress.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = order.customerAddress,
                        fontSize = 11.sp,
                        color = Color(0xFF475569),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Payment: ${order.paymentMethod}", fontSize = 11.sp, color = AccentGreen, fontWeight = FontWeight.SemiBold)
                Text(text = "Total: ₹${String.format("%.2f", order.totalAmount)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NordicMidnightIndigo)
            }
        }
    }
}

// --- SCREEN 7: PROFILE SETTINGS ---

@Composable
fun ProfileScreen(viewModel: ShopViewModel) {
    val rawProfile by viewModel.profile.collectAsStateWithLifecycle()

    var profileName by remember { mutableStateOf("") }
    var profileEmail by remember { mutableStateOf("") }
    var profilePhone by remember { mutableStateOf("") }
    var profileAddress by remember { mutableStateOf("") }
    var profileCity by remember { mutableStateOf("") }
    var profileState by remember { mutableStateOf("") }
    var profilePostalCode by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(rawProfile) {
        rawProfile?.let {
            profileName = it.name
            profileEmail = it.email
            profilePhone = it.phone
            profileAddress = it.addressLine
            profileCity = it.city
            profileState = it.state
            profilePostalCode = it.postalCode
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "My Profile & Delivery Details",
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = NordicMidnightIndigo
            )
            Text(
                text = "Manage your delivery address and store contact support",
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )
        }

        // Part B: Inputs Edit Form
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Delivery Address & Contact", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NordicMidnightIndigo)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = profileName,
                        onValueChange = { profileName = it },
                        label = { Text("Customer Name") },
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = profileEmail,
                        onValueChange = { profileEmail = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = profilePhone,
                        onValueChange = { profilePhone = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = profileAddress,
                        onValueChange = { profileAddress = it },
                        label = { Text("Street Address / Colony") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = profileCity,
                            onValueChange = { profileCity = it },
                            label = { Text("City") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = profileState,
                            onValueChange = { profileState = it },
                            label = { Text("State") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = profilePostalCode,
                            onValueChange = { profilePostalCode = it },
                            label = { Text("PIN Code") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.updateProfile(
                                name = profileName,
                                email = profileEmail,
                                phone = profilePhone,
                                address = profileAddress,
                                city = profileCity,
                                state = profileState,
                                code = profilePostalCode
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NordicMidnightIndigo),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("profile_save_button")
                    ) {
                        Text("Save Delivery Details")
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

// --- SCREEN 8: ORDER SUCCESS ---

@Composable
fun OrderSuccessScreen(
    viewModel: ShopViewModel,
    orderNumber: String,
    totalAmount: Double,
    summary: String,
    paymentMethod: String = "Cash on Delivery"
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Success",
            tint = AccentGreen,
            modifier = Modifier.size(90.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Order Placed Successfully!",
            fontWeight = FontWeight.Black,
            fontSize = 24.sp,
            color = NordicMidnightIndigo
        )
        Text(
            text = "Your fresh grocery order is confirmed and will be delivered shortly.",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NordicOffWhite)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "AH SHOP ORDER RECEIPT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray, letterSpacing = 0.5.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Order ID", fontSize = 12.sp, color = Color.DarkGray)
                    Text(orderNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NordicMidnightIndigo)
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Status", fontSize = 12.sp, color = Color.DarkGray)
                    Text("PENDING DISPATCH", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AccentGreen)
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Payment Mode", fontSize = 12.sp, color = Color.DarkGray)
                    Text(paymentMethod, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AccentGreen)
                }
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "Items ordered:", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Text(text = summary, fontSize = 11.sp, color = Color.DarkGray, maxLines = 3, overflow = TextOverflow.Ellipsis)

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Due", fontWeight = FontWeight.Black, fontSize = 13.sp, color = NordicMidnightIndigo)
                    Text("₹${String.format("%.2f", totalAmount)}", fontWeight = FontWeight.Black, fontSize = 15.sp, color = NordicMidnightIndigo)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        val context = LocalContext.current
        Button(
            onClick = {
                val orderMsg = "🛒 *New AH SHOP Order Confirmation*\n\n" +
                        "Order ID: #$orderNumber\n" +
                        "Items: $summary\n" +
                        "Total Amount: ₹${String.format(java.util.Locale.ENGLISH, "%.2f", totalAmount)}\n" +
                        "Payment Mode: $paymentMethod\n\n" +
                        "Please deliver my order. Thank you!"
                StoreConstants.openWhatsApp(context, orderMsg)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .width(260.dp)
                .height(48.dp)
                .testTag("order_success_whatsapp_button")
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_whatsapp),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Send Order on WhatsApp", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = { viewModel.navigateTo(Screen.Main) },
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.5.dp, NordicMidnightIndigo),
            modifier = Modifier.width(260.dp).height(46.dp).testTag("routing_success_button")
        ) {
            Text("Back to Store (दुकान पर लौटें)", fontWeight = FontWeight.Bold, color = NordicMidnightIndigo)
        }
    }
}
