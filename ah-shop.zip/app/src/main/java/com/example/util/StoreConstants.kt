package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object StoreConstants {
    const val STORE_NAME = "AH SHOP"
    const val STORE_TAGLINE = "Fresh Grocery & Daily Essentials"
    const val PHONE_NUMBER = "+91 8584016418"
    const val CLEAN_PHONE_NUMBER = "918584016418"
    const val STORE_ADDRESS = "H-10, Gulam abbas lane, P.O: & PS: Garden reach, kolkata-700024"
    const val STORE_EMAIL = "hussainmdshahid763@gmail.com"
    const val STORE_UPI_ID = "9470026573@ybl"
    const val APP_DOWNLOAD_URL = "https://wa.me/918584016418?text=Hello%20AH%20SHOP%2C%20please%20send%20me%20the%20AH%20SHOP%20Android%20App%20(APK)%20download%20file."

    /**
     * Directly launches WhatsApp chat with +91 8584016418.
     * Tries official WhatsApp client, falls back to web redirect (wa.me) smoothly.
     */
    fun openWhatsApp(
        context: Context,
        message: String = "Hello AH SHOP! I need assistance with grocery ordering / enquiry."
    ) {
        try {
            val encodedMsg = java.net.URLEncoder.encode(message, "UTF-8")
            val directUri = Uri.parse("https://api.whatsapp.com/send?phone=$CLEAN_PHONE_NUMBER&text=$encodedMsg")
            val intent = Intent(Intent.ACTION_VIEW, directUri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$CLEAN_PHONE_NUMBER?text=$encodedMsg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Formats customer cart/order in 100% English and sends it directly to Store WhatsApp (+91 8584016418).
     * Includes QR Code links, UPI payment options (Advance Token ₹50, Full, Without Advance COD),
     * Google Maps navigation URL, and clear instructions to share payment screenshot.
     */
    fun sendOrderToWhatsApp(
        context: Context,
        orderId: String? = null,
        customerName: String,
        customerPhone: String,
        customerAddress: String,
        items: List<com.example.data.local.CartItemEntity>,
        grandTotal: Double,
        deliveryFee: Double = 0.0,
        voucherCode: String? = null,
        paymentType: String = "Cash on Delivery (COD)"
    ) {
        val grandTotalStr = if (grandTotal % 1.0 == 0.0) grandTotal.toInt().toString() else String.format(java.util.Locale.ENGLISH, "%.2f", grandTotal)
        val remainingBalance = (grandTotal - 50.0).coerceAtLeast(0.0)
        val remainingBalanceStr = if (remainingBalance % 1.0 == 0.0) remainingBalance.toInt().toString() else String.format(java.util.Locale.ENGLISH, "%.2f", remainingBalance)

        val fullUpiUri = "upi://pay?pa=$STORE_UPI_ID&pn=AH%20SHOP&am=$grandTotalStr&cu=INR"
        val advanceUpiUri = "upi://pay?pa=$STORE_UPI_ID&pn=AH%20SHOP&am=50.00&cu=INR"

        val fullQrCodeUrl = try {
            "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" + java.net.URLEncoder.encode(fullUpiUri, "UTF-8")
        } catch (_: Exception) { "" }

        val advanceQrCodeUrl = try {
            "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" + java.net.URLEncoder.encode(advanceUpiUri, "UTF-8")
        } catch (_: Exception) { "" }

        val sb = java.lang.StringBuilder()
        sb.append("⚡ *AH SHOP - ORDER CONFIRMATION*\n")
        sb.append("📍 *Store:* $STORE_ADDRESS\n")
        sb.append("📞 *Store Contact:* $PHONE_NUMBER\n")
        if (!orderId.isNullOrBlank()) {
            sb.append("🔖 *Order ID:* #$orderId\n")
        }
        sb.append("------------------------------------\n")
        sb.append("👤 *Customer Name:* $customerName\n")
        sb.append("📱 *Mobile Number:* $customerPhone\n")
        sb.append("🏠 *Delivery Address:* $customerAddress\n")

        // Direct Google Maps location arrow link for store & delivery person
        try {
            val mapAddress = if (!customerAddress.contains("Kolkata", ignoreCase = true)) {
                "$customerAddress, Garden Reach, Kolkata"
            } else {
                customerAddress
            }
            val mapLink = "https://www.google.com/maps/search/?api=1&query=" + java.net.URLEncoder.encode(mapAddress, "UTF-8")
            sb.append("🗺️ *Location Map (Google Maps Link):*\n$mapLink\n")
        } catch (_: Exception) { }

        sb.append("------------------------------------\n")
        sb.append("🛒 *ORDERED ITEMS:*\n")
        items.forEachIndexed { index, item ->
            val size = if (item.selectedSize.isNotBlank()) " (${item.selectedSize})" else ""
            val totalItemPrice = item.price * item.quantity
            val priceStr = if (totalItemPrice % 1.0 == 0.0) totalItemPrice.toInt().toString() else String.format(java.util.Locale.ENGLISH, "%.2f", totalItemPrice)
            sb.append("${index + 1}. ${item.title}$size - *${item.quantity}x* (₹$priceStr)\n")
        }
        sb.append("------------------------------------\n")
        sb.append("📦 *Total Quantity:* ${items.sumOf { it.quantity }} items\n")
        if (deliveryFee > 0.0) {
            sb.append("🚚 *Delivery Fee:* ₹${String.format(java.util.Locale.ENGLISH, "%.2f", deliveryFee)}\n")
        } else {
            sb.append("🚚 *Delivery:* FREE Delivery\n")
        }
        if (!voucherCode.isNullOrBlank()) {
            sb.append("🎟️ *Coupon Applied:* $voucherCode\n")
        }
        sb.append("💰 *Grand Total:* ₹$grandTotalStr\n")
        sb.append("------------------------------------\n")
        sb.append("💳 *STORE PAYMENT UPI & QR CODE:*\n")
        sb.append("📲 *UPI ID:* $STORE_UPI_ID\n")
        if (fullQrCodeUrl.isNotBlank()) {
            sb.append("🖼️ *QR Code (Scan to Pay):*\n$fullQrCodeUrl\n")
        }
        sb.append("🔗 *Direct UPI Pay Link:*\n$fullUpiUri\n")
        sb.append("👉 *Please make payment on this UPI / QR Code (कृपया इस पर पेमेंट करें)*\n")
        sb.append("------------------------------------\n")
        sb.append("Please confirm my order and arrange delivery. Thank you!")

        openWhatsApp(context, sb.toString())
    }

    /**
     * Launches phone dialer for store contact number +91 8584016418.
     */
    fun callStore(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$PHONE_NUMBER")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Call error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
