package com.example.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
) {
    ENGLISH("en", "English", "English", "🇬🇧"),
    HINDI("hi", "Hindi", "हिंदी", "🇮🇳"),
    BENGALI("bn", "Bengali", "বাংলা", "🇮🇳"),
    URDU("ur", "Urdu", "اردو", "🇮🇳"),
    BHOJPURI("bho", "Bhojpuri", "भोजपुरी", "🇮🇳")
}

object LanguageManager {
    private const val PREFS_NAME = "ah_shop_language_prefs"
    private const val KEY_LANG = "selected_app_language"

    private var prefs: SharedPreferences? = null
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs?.edit()?.putString(KEY_LANG, AppLanguage.ENGLISH.code)?.apply()
            _currentLanguage.value = AppLanguage.ENGLISH
        }
    }

    fun setLanguage(context: Context, language: AppLanguage) {
        if (prefs == null) init(context)
        prefs?.edit()?.putString(KEY_LANG, language.code)?.apply()
        _currentLanguage.value = language
    }

    // Dynamic localized strings dictionary
    fun getTagline(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Fresh Groceries & Daily Essentials"
        AppLanguage.HINDI -> "ताज़ा फल, सब्ज़ियाँ व किराना का सामान"
        AppLanguage.BENGALI -> "তাজা মুদি ও দৈনন্দিন প্রয়োজনীয় সামগ্রী"
        AppLanguage.URDU -> "تازہ پھل، سبزیاں اور روزمرہ کا راشن"
        AppLanguage.BHOJPURI -> "ताज़ा फल, साग-सब्जी अउर किराना सामान"
    }

    fun getSearchPlaceholder(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Search groceries, veggies, staples..."
        AppLanguage.HINDI -> "फल, सब्ज़ी, किराना व दैनिक सामान खोजें..."
        AppLanguage.BENGALI -> "ফল, শাকসবজি, মুদি ও নিত্যপ্রয়োজনীয় জিনিস খুঁজুন..."
        AppLanguage.URDU -> "پھل، سبزیاں، راشن اور روزمرہ سامان تلاش کریں..."
        AppLanguage.BHOJPURI -> "सब्जी, फल अउर किराना के सामान खोजीं..."
    }

    fun getNavHome(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Home"
        AppLanguage.HINDI -> "होम"
        AppLanguage.BENGALI -> "হোম"
        AppLanguage.URDU -> "ہوم"
        AppLanguage.BHOJPURI -> "घर (होम)"
    }

    fun getNavCategories(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Categories"
        AppLanguage.HINDI -> "श्रेणियां"
        AppLanguage.BENGALI -> "বিভাগ"
        AppLanguage.URDU -> "کیٹیگریز"
        AppLanguage.BHOJPURI -> "श्रेणी"
    }

    fun getNavCart(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Cart"
        AppLanguage.HINDI -> "कार्ट"
        AppLanguage.BENGALI -> "কার্ট"
        AppLanguage.URDU -> "ٹوکری"
        AppLanguage.BHOJPURI -> "झोरा"
    }

    fun getNavOrders(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "My Orders"
        AppLanguage.HINDI -> "ऑर्डर्स"
        AppLanguage.BENGALI -> "অর্ডার"
        AppLanguage.URDU -> "میرے آرڈرز"
        AppLanguage.BHOJPURI -> "आर्डर"
    }

    fun getNavProfile(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Profile"
        AppLanguage.HINDI -> "प्रोफाइल"
        AppLanguage.BENGALI -> "প্রোফাইল"
        AppLanguage.URDU -> "پروفائل"
        AppLanguage.BHOJPURI -> "प्रोफाइल"
    }

    fun getFastOrderText(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "⚡ Fast Order on WhatsApp"
        AppLanguage.HINDI -> "⚡ व्हाट्सएप फास्ट ऑर्डर (Fast Order)"
        AppLanguage.BENGALI -> "⚡ হোয়াটসঅ্যাপে ফাস্ট অর্ডার (Fast Order)"
        AppLanguage.URDU -> "⚡ واٹس ایپ پر فاسٹ آرڈر (Fast Order)"
        AppLanguage.BHOJPURI -> "⚡ व्हाट्सएप से तुरंत आर्डर (Fast Order)"
    }

    fun getConfirmCodText(lang: AppLanguage, total: String): String = when (lang) {
        AppLanguage.ENGLISH -> "Confirm COD Order (₹$total)"
        AppLanguage.HINDI -> "COD ऑर्डर कन्फर्म करें (₹$total)"
        AppLanguage.BENGALI -> "ক্যাশ অন ডেলিভারি অর্ডার নিশ্চিত করুন (₹$total)"
        AppLanguage.URDU -> "سی او ڈی آرڈر کنفرم کریں (₹$total)"
        AppLanguage.BHOJPURI -> "डिलीवरी पर पेमेंट आर्डर पक्का करीं (₹$total)"
    }

    fun getPaymentMethodLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Choose Payment Preference (सुविधा अनुसार भुगतान चुनें)"
        AppLanguage.HINDI -> "भुगतान का विकल्प चुनें (Payment Mode)"
        AppLanguage.BENGALI -> "পেমেন্টের বিকল্প বেছে নিন (Payment Mode)"
        AppLanguage.URDU -> "ادائیگی کا طریقہ منتخب کریں (Payment Mode)"
        AppLanguage.BHOJPURI -> "भुगतान के तरीका चुनीं (Payment Mode)"
    }

    fun getFullPaymentTitle(lang: AppLanguage, amount: String): String = when (lang) {
        AppLanguage.ENGLISH -> "Full Payment (₹$amount via UPI QR)"
        AppLanguage.HINDI -> "पूर्ण ऑनलाइन भुगतान (₹$amount UPI QR द्वारा)"
        AppLanguage.BENGALI -> "সম্পূর্ণ পেমেন্ট (₹$amount UPI QR দিয়ে)"
        AppLanguage.URDU -> "مکمل آن لائن ادائیگی (₹$amount بذریعہ UPI)"
        AppLanguage.BHOJPURI -> "पूरा ऑनलाइन भुगतान (₹$amount UPI से)"
    }

    fun getAdvanceTokenTitle(lang: AppLanguage, advanceAmt: Int = 50): String = when (lang) {
        AppLanguage.ENGLISH -> "Advance Token ₹$advanceAmt (Balance on Delivery)"
        AppLanguage.HINDI -> "टोकन एडवांस ₹$advanceAmt (बाकी डिलीवरी पर)"
        AppLanguage.BENGALI -> "টোকেন অগ্রিম ₹$advanceAmt (বাকি টাকা ডেলিভারিতে)"
        AppLanguage.URDU -> "ٹوکن ایڈوانس ₹$advanceAmt (باقی رقم ڈلیوری پر)"
        AppLanguage.BHOJPURI -> "बयाना एडवांस ₹$advanceAmt (बाकी डिलीवरी पर)"
    }

    fun getWithoutPaymentTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Without Advance / Pay on Delivery (COD)"
        AppLanguage.HINDI -> "बिना एडवांस / सामान मिलने पर भुगतान (COD)"
        AppLanguage.BENGALI -> "অগ্রিম ছাড়া / ডেলিভারিতে ক্যাশ (COD)"
        AppLanguage.URDU -> "بغیر ایڈوانس / سامان ملنے پر ادائیگی (COD)"
        AppLanguage.BHOJPURI -> "बिना एडवांस / डिलीवरी पर नकद रुपिया"
    }

    fun getLanguageDialogTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Select App Language"
        AppLanguage.HINDI -> "ऐप की भाषा चुनें"
        AppLanguage.BENGALI -> "অ্যাপের ভাষা নির্বাচন করুন"
        AppLanguage.URDU -> "ایپ کی زبان منتخب کریں"
        AppLanguage.BHOJPURI -> "भाषा चुनीं"
    }
}
