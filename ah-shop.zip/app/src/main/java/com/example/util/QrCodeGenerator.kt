package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object QrCodePreferences {
    private const val PREFS = "ah_shop_qr_prefs"
    private const val KEY_CUSTOM_URL = "custom_app_url"

    fun getSavedUrl(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getString(KEY_CUSTOM_URL, StoreConstants.APP_DOWNLOAD_URL) ?: StoreConstants.APP_DOWNLOAD_URL
    }

    fun saveUrl(context: Context, url: String) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.edit().putString(KEY_CUSTOM_URL, url).apply()
    }
}

object QrCodeGenerator {

    const val DEFAULT_WHATSAPP_URL = "https://wa.me/918584016418?text=Hello%20AH%20SHOP"
    const val DEFAULT_UPI_URL = "upi://pay?pa=9470026573@ybl&pn=AH%20SHOP&cu=INR"
    const val DEFAULT_APP_URL = StoreConstants.APP_DOWNLOAD_URL

    /**
     * Generates a high-quality, standard-compliant Bitmap representing the QR code for given string content.
     * Uses standard quiet zone margin (4 modules) and ErrorCorrectionLevel.M so mobile phone cameras
     * and scanners (Google Lens, Paytm, PhonePe, Camera) can decode it instantly without failure.
     */
    fun generateQrBitmap(
        content: String,
        width: Int = 600,
        height: Int = 600,
        foregroundColor: Int = Color.BLACK, // Pure Black for maximum contrast
        backgroundColor: Int = Color.WHITE
    ): Bitmap? {
        return try {
            val hints = hashMapOf<EncodeHintType, Any>(
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.MARGIN to 4 // Standard 4-module quiet zone is required by QR specs
            )
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, width, height, hints)
            val w = bitMatrix.width
            val h = bitMatrix.height
            val pixels = IntArray(w * h)

            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) foregroundColor else backgroundColor
                }
            }

            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, w, 0, 0, w, h)
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Creates a high-resolution printable store poster Bitmap (e.g. for display at shop counter or printing flyers).
     */
    fun generatePrintablePoster(
        appUrl: String,
        qrBitmap: Bitmap
    ): Bitmap {
        val posterWidth = 800
        val posterHeight = 1100
        val poster = Bitmap.createBitmap(posterWidth, posterHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(poster)

        // Background
        val bgPaint = Paint().apply { color = Color.parseColor("#F8FAFC") }
        canvas.drawRect(0f, 0f, posterWidth.toFloat(), posterHeight.toFloat(), bgPaint)

        // Outer Border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        canvas.drawRoundRect(RectF(16f, 16f, posterWidth - 16f, posterHeight - 16f), 24f, 24f, borderPaint)

        // Header Banner Background
        val headerBgPaint = Paint().apply { color = Color.parseColor("#0F172A") }
        canvas.drawRoundRect(RectF(32f, 32f, posterWidth - 32f, 180f), 20f, 20f, headerBgPaint)

        // Store Title
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 52f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("AH SHOP", posterWidth / 2f, 96f, titlePaint)

        // Store Subtitle
        val subTitlePaint = Paint().apply {
            color = Color.parseColor("#FBBF24") // Warm Sand Gold
            textSize = 24f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Grocery & Daily Essentials Store", posterWidth / 2f, 136f, subTitlePaint)

        // Hindi Callout
        val hindiCalloutPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 30f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("घर बैठे शुद्ध व ताज़ा राशन मंगवाएं", posterWidth / 2f, 230f, hindiCalloutPaint)

        val engCalloutPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 20f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("SCAN QR CODE TO DOWNLOAD APP & ORDER", posterWidth / 2f, 264f, engCalloutPaint)

        // White Card behind QR Code
        val qrCardBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            setShadowLayer(12f, 0f, 6f, Color.parseColor("#33000000"))
        }
        val qrCardBorder = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        val qrBox = RectF(140f, 300f, posterWidth - 140f, 820f)
        canvas.drawRoundRect(qrBox, 24f, 24f, qrCardBg)
        canvas.drawRoundRect(qrBox, 24f, 24f, qrCardBorder)

        // Draw the QR Bitmap with crisp sharp modules (no blur)
        val scaledQr = Bitmap.createScaledBitmap(qrBitmap, 460, 460, false)
        canvas.drawBitmap(scaledQr, (posterWidth - 460) / 2f, 330f, null)

        // Below QR text
        val scanHintPaint = Paint().apply {
            color = Color.parseColor("#15803D") // Forest Green
            textSize = 22f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("★ Fast Delivery • Best Prices • 100% Quality Guarantee ★", posterWidth / 2f, 865f, scanHintPaint)

        // Link text
        val linkPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 18f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val displayUrl = if (appUrl.length > 55) appUrl.take(52) + "..." else appUrl
        canvas.drawText("Direct Link: $displayUrl", posterWidth / 2f, 905f, linkPaint)

        // Footer Support Banner
        val footerPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 19f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("AH SHOP Contact & WhatsApp: +91 8584016418", posterWidth / 2f, 955f, footerPaint)

        val addressPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("H-10, Gulam abbas lane, Garden reach, Kolkata-700024", posterWidth / 2f, 985f, addressPaint)

        val thankYouPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Thank you for shopping with us!  (धन्यवाद)", posterWidth / 2f, 1015f, thankYouPaint)

        return poster
    }

    /**
     * Shares the QR code image via Android Intent (WhatsApp, Instagram, Telegram, Email, etc.).
     */
    fun shareQrImage(
        context: Context,
        bitmap: Bitmap,
        appUrl: String,
        isPoster: Boolean = false
    ) {
        try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val fileName = if (isPoster) "AH_SHOP_Store_Poster.png" else "AH_SHOP_Download_QR.png"
            val imageFile = File(exportDir, fileName)

            FileOutputStream(imageFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }

            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                imageFile
            )

            val shareMessage = buildString {
                append("🛒 *AH SHOP - Fresh Grocery & Daily Essentials*\n\n")
                append("📍 Store Address: H-10, Gulam abbas lane, P.O: & PS: Garden reach, Kolkata-700024\n")
                append("📞 WhatsApp & Support: +91 8584016418\n\n")
                append("Scan this QR code or click the link below to open/download our app:\n")
                append("👉 $appUrl\n\n")
                append("✨ Pure Quality • Wholesale Rates • Fast Home Delivery\n")
                append("Order now! (घर बैठे ताज़ा राशन मंगवाएं)")
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "AH SHOP - Download App QR Code")
                putExtra(Intent.EXTRA_TEXT, shareMessage)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, "Share QR Code with Customers")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Share error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Saves the QR code or Poster to the device's Pictures / Gallery so the shopkeeper can print it or print banners.
     */
    fun saveImageToGallery(context: Context, bitmap: Bitmap, fileName: String): Boolean {
        return try {
            val fos: OutputStream?
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "$fileName.png")
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + File.separator + "AH_SHOP")
                }
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                fos = imageUri?.let { resolver.openOutputStream(it) }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + File.separator + "AH_SHOP"
                val file = File(imagesDir).apply { mkdirs() }
                val image = File(file, "$fileName.png")
                fos = FileOutputStream(image)
            }

            fos?.use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
                it.flush()
            }

            Toast.makeText(context, "Saved to Pictures! (प्रिंट करने के लिए गैलरी में सेव हो गया)", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback: save to cache and share
            Toast.makeText(context, "Could not save to gallery directly, sharing image instead...", Toast.LENGTH_SHORT).show()
            shareQrImage(context, bitmap, DEFAULT_APP_URL, false)
            false
        }
    }
}
