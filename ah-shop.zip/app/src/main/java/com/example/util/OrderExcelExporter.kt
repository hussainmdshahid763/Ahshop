package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.OrderEntity
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OrderExcelExporter {

    private val dateFormat = SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.ENGLISH)
    private val fileTimestampFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH)

    /**
     * Escapes CSV cells to properly handle commas, quotes, and newlines.
     */
    private fun escapeCsvCell(value: String): String {
        val cleanValue = value.replace("\r", " ").replace("\n", " ")
        return if (cleanValue.contains(",") || cleanValue.contains("\"") || cleanValue.contains(";")) {
            "\"" + cleanValue.replace("\"", "\"\"") + "\""
        } else {
            cleanValue
        }
    }

    /**
     * Generates standard CSV formatted string with UTF-8 BOM (\uFEFF)
     * so that Microsoft Excel and Google Sheets correctly render Hindi characters and symbols.
     */
    fun generateCsv(orders: List<OrderEntity>): String {
        val sb = StringBuilder()
        // UTF-8 Byte Order Mark for Excel
        sb.append("\uFEFF")

        // Header Row
        val headers = listOf(
            "Order Number",
            "Date & Time",
            "Customer Name",
            "Customer Mobile",
            "Delivery Address",
            "Ordered Items Summary",
            "Total Quantity",
            "Total Amount (INR)",
            "Payment Mode",
            "Order Status"
        )
        sb.append(headers.joinToString(",") { escapeCsvCell(it) })
        sb.append("\r\n")

        // Data Rows
        for (order in orders) {
            val dateStr = try {
                dateFormat.format(Date(order.timestamp))
            } catch (e: Exception) {
                order.timestamp.toString()
            }

            val amountStr = if (order.totalAmount % 1.0 == 0.0) {
                order.totalAmount.toInt().toString()
            } else {
                String.format(Locale.ENGLISH, "%.2f", order.totalAmount)
            }

            val row = listOf(
                order.orderNumber.ifBlank { "ORD-${order.id}" },
                dateStr,
                order.customerName.ifBlank { "Customer" },
                order.customerPhone.ifBlank { "N/A" },
                order.customerAddress.ifBlank { "Store Pickup" },
                order.itemsSummary.ifBlank { "Grocery Items" },
                order.itemsCount.toString(),
                amountStr,
                order.paymentMethod.ifBlank { "Cash on Delivery" },
                order.status.ifBlank { "Pending" }
            )
            sb.append(row.joinToString(",") { escapeCsvCell(it) })
            sb.append("\r\n")
        }

        return sb.toString()
    }

    /**
     * Writes CSV data to a cache file and triggers Android Intent to open in Excel or share via WhatsApp/Gmail.
     */
    fun exportAndShare(context: Context, orders: List<OrderEntity>): Boolean {
        if (orders.isEmpty()) {
            Toast.makeText(context, "No orders available to export! (निर्यात करने के लिए कोई ऑर्डर नहीं है)", Toast.LENGTH_SHORT).show()
            return false
        }

        try {
            val csvContent = generateCsv(orders)
            val fileName = "AH_SHOP_Orders_${fileTimestampFormat.format(Date())}.csv"
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val csvFile = File(exportDir, fileName)

            FileOutputStream(csvFile).use { fos ->
                OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                    writer.write(csvContent)
                    writer.flush()
                }
            }

            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                csvFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, "AH SHOP - Orders Report (${orders.size} Orders)")
                putExtra(Intent.EXTRA_TEXT, "AH SHOP Order Records Exported to Excel/CSV (${orders.size} total orders).")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "Open in Excel or Share via WhatsApp / Email")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

            Toast.makeText(context, "Excel sheet ready! (${orders.size} orders exported)", Toast.LENGTH_SHORT).show()
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Export error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            return false
        }
    }

    /**
     * Copies all CSV rows directly to clipboard so user can paste into Google Sheets, WhatsApp or Notes.
     */
    fun copyToClipboard(context: Context, orders: List<OrderEntity>) {
        if (orders.isEmpty()) {
            Toast.makeText(context, "No orders to copy!", Toast.LENGTH_SHORT).show()
            return
        }
        val csv = generateCsv(orders)
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("AH SHOP Orders CSV", csv)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied ${orders.size} orders to clipboard! (क्लिपबोर्ड में कॉपी हो गया)", Toast.LENGTH_SHORT).show()
    }
}
