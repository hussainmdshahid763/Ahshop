package com.example

import com.example.data.local.OrderEntity
import com.example.data.repository.GroceryCatalog
import com.example.util.OrderExcelExporter
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testStrictAdminAuthentication() {
        val expectedEmail = "hussainmdshahid763@gmail.com"
        val expectedPass = "wH0192014et!V"

        // Auth logic matching ShopViewModel
        val checkCorrect = { u: String, p: String ->
            u.trim().lowercase() == expectedEmail && p.trim() == expectedPass
        }

        // Must succeed for exact credentials
        assertTrue(checkCorrect("hussainmdshahid763@gmail.com", "wH0192014et!V"))
        assertTrue(checkCorrect("  HUSSAINMDSHAHID763@GMAIL.COM  ", "wH0192014et!V"))

        // Must FAIL for old/demo credentials
        assertFalse(checkCorrect("admin", "admin123"))
        assertFalse(checkCorrect("admin", "1234"))
        assertFalse(checkCorrect("shahid", "1234"))
        assertFalse(checkCorrect("hussainmdshahid763@gmail.com", "wrongpass"))
        assertFalse(checkCorrect("wrong@gmail.com", "wH0192014et!V"))
        assertFalse(checkCorrect("", ""))
    }

    @Test
    fun testGroceryCatalogItemsIntegrity() {
        val items = GroceryCatalog.items
        assertTrue("Catalog must not be empty", items.isNotEmpty())

        // Check required products exist with valid Rupee pricing and Hindi names
        val potato = items.find { it.title.equals("Potato", ignoreCase = true) }
        assertNotNull("Potato must exist in catalog", potato)
        assertEquals("आलू", potato?.hindiName)
        assertEquals(32.0, potato?.price ?: 0.0, 0.01)

        val onion = items.find { it.title.equals("Onion", ignoreCase = true) }
        assertNotNull("Onion must exist in catalog", onion)
        assertEquals("प्याज़", onion?.hindiName)
        assertEquals(50.0, onion?.price ?: 0.0, 0.01)

        val tomato = items.find { it.title.equals("Tomato", ignoreCase = true) }
        assertNotNull("Tomato must exist in catalog", tomato)
        assertEquals("टमाटर", tomato?.hindiName)
        assertEquals(28.0, tomato?.price ?: 0.0, 0.01)

        // Ensure all products have positive prices and valid units
        items.forEach { p ->
            assertTrue("Product ${p.title} must have price > 0", p.price > 0)
            assertTrue("Product ${p.title} must have valid unit", p.unit.isNotBlank())
            assertTrue("Product ${p.title} must have valid category", p.category.isNotBlank())
        }
    }

    @Test
    fun testOrderExcelExportCsvGeneration() {
        val sampleOrders = listOf(
            OrderEntity(
                id = 1,
                orderNumber = "ORD-101",
                timestamp = System.currentTimeMillis(),
                totalAmount = 540.0,
                itemsCount = 3,
                status = "Delivered",
                itemsSummary = "आलू 2 KG, प्याज़ 1 KG, टमाटर 1 KG",
                customerName = "Shahid Hussain",
                customerPhone = "9876543210",
                customerAddress = "Near Main Market, Ward 5",
                paymentMethod = "Cash on Delivery"
            ),
            OrderEntity(
                id = 2,
                orderNumber = "ORD-102",
                timestamp = System.currentTimeMillis(),
                totalAmount = 280.0,
                itemsCount = 2,
                status = "Pending",
                itemsSummary = "चावल 5 KG, दाल 1 KG",
                customerName = "Ramesh Kumar",
                customerPhone = "9123456780",
                customerAddress = "Station Road, Shop 12",
                paymentMethod = "UPI Online"
            )
        )

        val csv = OrderExcelExporter.generateCsv(sampleOrders)

        // Verify UTF-8 BOM for Microsoft Excel
        assertTrue("CSV must start with UTF-8 BOM", csv.startsWith("\uFEFF"))

        // Verify Header columns
        assertTrue(csv.contains("Order Number"))
        assertTrue(csv.contains("Date & Time"))
        assertTrue(csv.contains("Customer Name"))
        assertTrue(csv.contains("Customer Mobile"))
        assertTrue(csv.contains("Delivery Address"))
        assertTrue(csv.contains("Ordered Items Summary"))
        assertTrue(csv.contains("Total Quantity"))
        assertTrue(csv.contains("Total Amount (INR)"))
        assertTrue(csv.contains("Payment Mode"))
        assertTrue(csv.contains("Order Status"))

        // Verify Data Rows
        assertTrue(csv.contains("ORD-101"))
        assertTrue(csv.contains("Shahid Hussain"))
        assertTrue(csv.contains("9876543210"))
        assertTrue(csv.contains("540"))
        assertTrue(csv.contains("Delivered"))

        assertTrue(csv.contains("ORD-102"))
        assertTrue(csv.contains("Ramesh Kumar"))
        assertTrue(csv.contains("UPI Online"))
        assertTrue(csv.contains("Pending"))
    }

    @Test
    fun testZxingQrCodeGeneration() {
        val testUrl = com.example.util.QrCodeGenerator.DEFAULT_APP_URL
        assertTrue("URL must not be blank", testUrl.isNotBlank())
        assertTrue("URL must be HTTPS", testUrl.startsWith("https://"))

        // Test pure ZXing matrix generation
        val writer = com.google.zxing.qrcode.QRCodeWriter()
        val hints = hashMapOf<com.google.zxing.EncodeHintType, Any>(
            com.google.zxing.EncodeHintType.CHARACTER_SET to "UTF-8",
            com.google.zxing.EncodeHintType.ERROR_CORRECTION to com.google.zxing.qrcode.decoder.ErrorCorrectionLevel.H,
            com.google.zxing.EncodeHintType.MARGIN to 1
        )
        val matrix = writer.encode(testUrl, com.google.zxing.BarcodeFormat.QR_CODE, 256, 256, hints)
        assertNotNull("BitMatrix should be created", matrix)
        assertEquals(256, matrix.width)
        assertEquals(256, matrix.height)

        // Count dark and light modules to ensure matrix is not blank
        var darkCount = 0
        var lightCount = 0
        for (y in 0 until matrix.height) {
            for (x in 0 until matrix.width) {
                if (matrix.get(x, y)) darkCount++ else lightCount++
            }
        }
        assertTrue("QR code must have dark modules", darkCount > 100)
        assertTrue("QR code must have light modules", lightCount > 100)
    }
}

